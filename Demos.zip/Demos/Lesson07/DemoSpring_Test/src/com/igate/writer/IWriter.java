package com.igate.writer;

public interface IWriter {
	public int writer(int i);
}
