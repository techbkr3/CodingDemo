package com.igate.trust.exception;

public class TrustException extends Exception{

	public TrustException()
	{
		
	}
	public TrustException(String msg)
	{
		super(msg);
	}

}
