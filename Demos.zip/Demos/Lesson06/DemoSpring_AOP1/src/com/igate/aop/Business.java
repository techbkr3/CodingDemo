package com.igate.aop;


public interface Business {
    void doBusiness();
}
