package com.igate.spel;

import java.util.ArrayList;

public class CityList {
	
	private ArrayList<City> cityList;

	public ArrayList<City> getCityList() {
		return cityList;
	}

	public void setCityList(ArrayList<City> cityList) {
		this.cityList = cityList;
	}
	
	

}
