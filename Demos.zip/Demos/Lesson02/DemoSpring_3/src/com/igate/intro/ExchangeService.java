package com.igate.intro;

public interface ExchangeService {

	public double getExchangeRate();
}
