package com.igate.anno;
public interface CurrencyConverter {
	public double dollarsToRupees(double dollars);
}