package com.igate.trainingapp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.igate.trainingapp.dto.Sessions;
import com.igate.trainingapp.exception.TrainingAppException;
import com.igate.trainingapp.service.ITrainingService;

@Controller
public class TrainingController {
	
	@Autowired
	ITrainingService service;
	
	/**
	 * @author balmurug
	 * RequestMapping URL Parameter: "home"
	 * Method Name:showSessionList
	 * Methods Invoked : getSessionList
	 * Return sessions.jsp
	 */
	
	@RequestMapping("/home")
	public ModelAndView showSessionList()
	{
	List<Sessions> sessionList;
	try {
		sessionList = service.getSessionList();
		return new ModelAndView("sessions","sessionList",sessionList);
	} catch (DataAccessException | TrainingAppException e) {
		// TODO Auto-generated catch block
		return new ModelAndView("error","msg","Sorry, unable to update");
	}
	}
	
	/**
	 * @author balmurug
	 * RequestMapping URL Parameter: "update"
	 * Method Name: updateSessionList
	 * Methods Invoked : getSessionDetails
	 * Return update.jsp
	 */
	
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public String updateSessionList(@RequestParam("id") int id,Map<String,Object> model,Model models)
	{	
		Sessions sessionDetails;
		try {
			sessionDetails = service.getSessionDetails(id);
			List<String> sessionModeList  = new ArrayList<String>();
			sessionModeList.add("ILT");
			sessionModeList.add("VC");
			sessionModeList.add("WBT");
			model.put("sessionModeList", sessionModeList);
			model.put("sessionDetails", sessionDetails);		
			return "update";
		} catch (DataAccessException | TrainingAppException e) {
			// TODO Auto-generated catch block
			models.addAttribute("msg",e.getMessage());
			return "error";
		}
		
		
	}
	
	/**
	 * @author balmurug
	 * RequestMapping URL Parameter: "updateSession"
	 * Method Name: updateSessionDetails
	 * Methods Invoked : updateSessionDetails
	 * Return update.jsp
	 */
	
	@RequestMapping(value="/updateSession",method=RequestMethod.POST)
	public ModelAndView updateSessionDetails(@Valid @ModelAttribute("sessionDetails") Sessions session, BindingResult res)
	{	
		if(res.hasErrors())
		{
			List<String> sessionModeList  = new ArrayList<String>();
			sessionModeList.add("ILT");
			sessionModeList.add("VC");
			sessionModeList.add("WBT");
			return new ModelAndView("update","sessionModeList", sessionModeList);
			
		}
				
			int result;
			try {
				result = service.updateSessionDetails(session);
				if(result==1)
				{
					List<Sessions> sessionList = service.getSessionList();
					return new ModelAndView("sessions","sessionList",sessionList);
				}
				else
				{
					return new ModelAndView("error","msg","Sorry, unable to update");
				}
			} catch (DataAccessException | TrainingAppException e) {
				// TODO Auto-generated catch block
				return new ModelAndView("error","msg","Sorry, unable to update");
			}
									
		
	}
	
	

}
