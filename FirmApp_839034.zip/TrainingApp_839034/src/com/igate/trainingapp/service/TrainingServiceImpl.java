package com.igate.trainingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.trainingapp.dao.ITrainingDAO;
import com.igate.trainingapp.dto.Sessions;
import com.igate.trainingapp.exception.TrainingAppException;

@Service
public class TrainingServiceImpl implements ITrainingService {
	
	@Autowired
	ITrainingDAO dao;

	/**
	 * @author balmurug
	 * Method Name:  getSessionList()
	 * Return Type : List<Sessions>
	 * Layer: Service
	 **/
	
	@Override
	public List<Sessions> getSessionList() throws TrainingAppException {
		// TODO Auto-generated method stub
		return dao.getSessionList();
	}

	/**
	 * @author balmurug
	 * Method Name:  getSessionList()
	 * Return Type : List<Sessions>
	 * Layer: Service
	 **/
	
	@Override
	public Sessions getSessionDetails(int id) throws TrainingAppException {
		// TODO Auto-generated method stub
		return dao.getSessionDetails(id);
	}
	
	/**
	 * @author balmurug
	 * Method Name:  getSessionList()
	 * Return Type : List<Sessions>
	 * Layer: Service
	 **/

	@Override
	public int updateSessionDetails(Sessions session) throws TrainingAppException {
		// TODO Auto-generated method stub
		return dao.updateSessionDetails(session);
	}

}
