package com.igate.trainingapp.service;

import java.util.List;

import com.igate.trainingapp.dto.Sessions;
import com.igate.trainingapp.exception.TrainingAppException;

public interface ITrainingService {

	public List<Sessions> getSessionList() throws TrainingAppException;

	public Sessions getSessionDetails(int id) throws TrainingAppException;

	public int updateSessionDetails(Sessions session) throws TrainingAppException;

}

