package com.igate.trainingapp.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.igate.trainingapp.dto.Sessions;
import com.igate.trainingapp.exception.TrainingAppException;

@Repository
public class TrainingDAOImpl extends JdbcDaoSupport implements ITrainingDAO {

	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	public void initialize()
	{
		setDataSource(dataSource);
	}
	
	/**
	 * @author balmurug
	 * Method Name:  getSessionList()
	 * Return Type : List<Sessions>
	 * Layer: DAO
	 **/
	
	@Override
	public List<Sessions> getSessionList()  throws TrainingAppException{
		// TODO Auto-generated method stub
		String sessionListQuery = "SELECT * FROM ScheduledSessions";
		List<Sessions> sessionList = (List<Sessions>) getJdbcTemplate().query(sessionListQuery, new SessionRowMapper());
		return sessionList;
	}

	/**
	 * @author balmurug
	 * Method Name:  getSessionDetails()
	 * Return Type : Sessions
	 * Layer: DAO
	 **/
	
	@Override
	public Sessions getSessionDetails(int id)  throws TrainingAppException{
		// TODO Auto-generated method stub
		String sessionDetailsListQuery = "SELECT * FROM ScheduledSessions WHERE ID ="+id;
		List<Sessions> sessionList = (List<Sessions>) getJdbcTemplate().query(sessionDetailsListQuery, new SessionRowMapper());
		return sessionList.get(0);
	}
	
	/**
	 * @author balmurug
	 * Method Name:  updateSessionDetails()
	 * Return Type : int
	 * Layer: DAO
	 **/

	@Override
	public int updateSessionDetails(Sessions session)  throws TrainingAppException{
		// TODO Auto-generated method stub		
		String updateSessionDetailsQuery = "UPDATE ScheduledSessions SET DURATION=?,FACULTY=?,MODE1=? WHERE ID="+session.getSessionId();
		Object[] params = {session.getSessionDuration(),session.getSessionFaculty(),session.getSessionMode()};
		int result = getJdbcTemplate().update(updateSessionDetailsQuery,params);
		return result;
	}

}
