package com.igate.trainingapp.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.trainingapp.dto.Sessions;

public class SessionRowMapper implements RowMapper<Sessions> {

	@Override
	public Sessions mapRow(ResultSet rs, int count) throws SQLException {
		// TODO Auto-generated method stub
		Sessions session = new Sessions();
		session.setSessionId(rs.getString("id"));
		session.setSessionName(rs.getString("name"));
		session.setSessionDuration(rs.getString("duration"));
		session.setSessionFaculty(rs.getString("faculty"));
		session.setSessionMode(rs.getString("mode1"));
		return session;
	}

}
