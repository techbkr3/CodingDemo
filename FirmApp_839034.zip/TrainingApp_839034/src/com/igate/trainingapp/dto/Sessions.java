package com.igate.trainingapp.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class Sessions {
	@NotEmpty(message = "ID field is required")
	private String sessionId;
	@NotEmpty(message = "Name field is required")
	private String sessionName;
	@NotEmpty(message = "Duration field is required")
	@Pattern(regexp = "^[0-9]$", message = "Duration greater than 0 and less than 10")
	private String sessionDuration;
	@NotEmpty(message = "Faculty name is required")
	@Pattern(regexp = "^[a-zA-Z ]+$", message = "Faculty name supports Alphabets only")
	private String sessionFaculty;
	@NotEmpty
	private String sessionMode;

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public String getSessionDuration() {
		return sessionDuration;
	}

	public void setSessionDuration(String sessionDuration) {
		this.sessionDuration = sessionDuration;
	}

	public String getSessionFaculty() {
		return sessionFaculty;
	}

	public void setSessionFaculty(String sessionFaculty) {
		this.sessionFaculty = sessionFaculty;
	}

	public String getSessionMode() {
		return sessionMode;
	}

	public void setSessionMode(String sessionMode) {
		this.sessionMode = sessionMode;
	}

	@Override
	public String toString() {
		return "Sessions [sessionId=" + sessionId + ", sessionName="
				+ sessionName + ", sessionDuration=" + sessionDuration
				+ ", sessionFaculty=" + sessionFaculty + ", sessionMode="
				+ sessionMode + "]";
	}

}
