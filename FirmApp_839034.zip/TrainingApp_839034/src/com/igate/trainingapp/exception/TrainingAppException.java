package com.igate.trainingapp.exception;

public class TrainingAppException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TrainingAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainingAppException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
