/* 
Registration Page Validation Modules
*/
function fnameValid(value)
{
if(value.match(/\d/))
{
value = value.replace(/\d/g,'');
document.getElementById("f").value = value;
}
}

function mnameValid(value)
{
if(value.match(/\d/))
{
value = value.replace(/\d/g,'');
document.getElementById("m").value = value;
}
}

function lnameValid(value)
{
if(value.match(/\d/))
{
value = value.replace(/\d/g,'');
document.getElementById("l").value = value;
}
}

function bnameValid(value)
{
if(value.match(/\d/))
{
value = value.replace(/\d/g,'');
document.getElementById("b").value = value;
}
}

function mobileValid(value)
{
if(value.match(/\D/))
{
value = value.replace(/\D/g,'');
document.getElementById("m").value = value;
}
}