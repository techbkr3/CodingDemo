package com.igate.firmapp.exception;

public class FirmException extends Exception{

	/**
	 * bade bade desho mein aisi choti choti baatein hoti hi rehti hain, Senorita!!!
	 */
	private static final long serialVersionUID = -2160165703119681372L;

	public FirmException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FirmException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
