package com.igate.firmapp.controller;

import java.io.IOException;
import java.util.Random;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.firmapp.dto.FirmApp;
import com.igate.firmapp.exception.FirmException;
import com.igate.firmapp.service.IRegisterService;
import com.igate.firmapp.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String perform = request.getParameter("perform");
		IRegisterService service = new RegisterServiceImpl();
		
		/**
		 * App name: FirmApp
		 * Version : 1.0
		 * Module : Register
		 */
		
		
		if (perform.equals("register")) {
			String firstname = request.getParameter("firstname");
			String middlename = request.getParameter("middlename");
			String lastname = request.getParameter("lastname");
			String name = firstname + " " + middlename + " " + lastname;
			String businessname = request.getParameter("businessname");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");
			String isActive = "N";
			FirmApp fObj = new FirmApp(name, businessname, email, mobile,
					isActive);

			try {
				service.registerFirm(fObj);
			} catch (FirmException e) {
				// TODO Auto-generated catch block
				e.getMessage();
			}
			Random r = new Random();
			int actCode = r.nextInt(1000) + 10000;
			;
			HttpSession sess = request.getSession();
			sess.setAttribute("actcode", actCode);
			sess.setAttribute("mail", email);
			request.getRequestDispatcher("success.jsp").forward(request,
					response);

		}
		
		/**
		 * App name: FirmApp
		 * Version : 1.0
		 * Module : Activation
		 */

		if (perform.equals("activate")) {
			String activationEmail = request.getParameter("activationEmail");
			String activationCode = request.getParameter("activationCode");
			HttpSession sess = request.getSession(false);
			String sessionMail = (String) sess.getAttribute("mail");
			Integer sessionActCode = (Integer) sess.getAttribute("actcode");
			FirmApp fObj = new FirmApp();
			String isActive = "Y";
			if (Integer.parseInt(activationCode) == sessionActCode
					&& activationEmail.equalsIgnoreCase(sessionMail)) {
				fObj.setEmailId(activationEmail);
				fObj.setIsActive(isActive);
				try {
					service.activateFirm(fObj);
					request.getRequestDispatcher("activated.jsp").forward(
							request, response);
				} catch (FirmException e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}

			} else {
				request.getRequestDispatcher("error.jsp").forward(request,
						response);
			}
		}

	}

}
