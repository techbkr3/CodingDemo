package com.igate.firmapp.db;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.igate.firmapp.exception.FirmException;

public class DBConnection implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6864851801951886476L;
	static DataSource ds;

	public static Connection getConnection() throws FirmException {
		Connection conn = null;
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/jdbc/TrackDS");
			conn = ds.getConnection();
			if (conn != null) {
				System.out.println("DB Connection Successful");
			}

		}

		catch (SQLException e) {
			throw new FirmException("SQL Error:" + e.getMessage());
		} catch (NamingException e) {
			throw new FirmException("Naming Exception Occured" + e.getMessage());
		}
		return conn;
	}

}
