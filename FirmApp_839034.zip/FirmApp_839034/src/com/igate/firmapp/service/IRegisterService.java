package com.igate.firmapp.service;

import com.igate.firmapp.dto.FirmApp;
import com.igate.firmapp.exception.FirmException;

public interface IRegisterService {

	public void registerFirm(FirmApp fObj) throws FirmException;

	public void activateFirm(FirmApp fObj) throws FirmException;

}
