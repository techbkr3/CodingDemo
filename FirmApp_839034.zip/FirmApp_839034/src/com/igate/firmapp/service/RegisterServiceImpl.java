package com.igate.firmapp.service;

import com.igate.firmapp.dao.IRegisterDAO;
import com.igate.firmapp.dao.RegisterDAOImpl;
import com.igate.firmapp.dto.FirmApp;
import com.igate.firmapp.exception.FirmException;

public class RegisterServiceImpl implements IRegisterService {

	IRegisterDAO dao = new RegisterDAOImpl();

	@Override
	public void registerFirm(FirmApp fObj) throws FirmException {
		// TODO Auto-generated method stub
		dao.registerFirm(fObj);
	}

	@Override
	public void activateFirm(FirmApp fObj) throws FirmException {
		// TODO Auto-generated method stub
		dao.activateFirm(fObj);

	}

}
