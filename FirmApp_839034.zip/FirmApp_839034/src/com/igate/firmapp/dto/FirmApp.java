package com.igate.firmapp.dto;

public class FirmApp {

	private int firmId;
	private String ownerName;
	private String businessName;
	private String emailId;
	private String mobileNo;
	private String isActive;

	public int getFirmId() {
		return firmId;
	}

	public void setFirmId(int firmId) {
		this.firmId = firmId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "FirmApp [firmId=" + firmId + ", ownerName=" + ownerName
				+ ", businessName=" + businessName + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", isActive=" + isActive + "]";
	}

	public FirmApp(int firmId, String ownerName, String businessName,
			String emailId, String mobileNo, String isActive) {
		super();
		this.firmId = firmId;
		this.ownerName = ownerName;
		this.businessName = businessName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.isActive = isActive;
	}

	public FirmApp() {
		super();
	}

	public FirmApp(String firstname, String businessname2, String email,
			String mobile, String isActive2) {
		super();
		this.ownerName = firstname;
		this.businessName = businessname2;
		this.emailId = email;
		this.mobileNo = mobile;
		this.isActive = isActive2;
	}

}
