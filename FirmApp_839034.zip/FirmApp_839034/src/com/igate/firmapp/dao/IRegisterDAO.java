package com.igate.firmapp.dao;

import com.igate.firmapp.dto.FirmApp;
import com.igate.firmapp.exception.FirmException;

public interface IRegisterDAO {

	public void registerFirm(FirmApp fObj) throws FirmException;

	public void activateFirm(FirmApp fObj) throws FirmException;

}
