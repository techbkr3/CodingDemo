package com.igate.firmapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.igate.firmapp.db.DBConnection;
import com.igate.firmapp.dto.FirmApp;
import com.igate.firmapp.exception.FirmException;

public class RegisterDAOImpl implements IRegisterDAO {

	Connection con = null;
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
	Statement st = null;
	ResultSet rs = null;
	int firmId;
		
	/**
	 * App name: FirmApp
	 * Version : 1.0
	 * Module : Register
	 */
	
	@Override
	public void registerFirm(FirmApp fObj) throws FirmException {
		// TODO Auto-generated method stub

		con = DBConnection.getConnection();
		String registerQuery = "INSERT INTO FIRMS_MASTER (FIRM_ID,OWNER_NAME,BUSINESS_NAME,EMAIL,MOBILE_NO,ISACTIVE) VALUES (?,?,?,?,?,?)";
		String firmIdQuery = "SELECT FIRMSId_Seq.NEXTVAL FROM DUMMY";
		try {

			st = con.createStatement();

			rs = st.executeQuery(firmIdQuery);

			if (rs.next()) {
				firmId = rs.getInt(1);
			}
			pst = con.prepareStatement(registerQuery);
			pst.setInt(1, firmId);
			pst.setString(2, fObj.getOwnerName());
			pst.setString(3, fObj.getBusinessName());
			pst.setString(4, fObj.getEmailId());
			pst.setString(5, fObj.getMobileNo());
			pst.setString(6, fObj.getIsActive());
			int result = pst.executeUpdate();
			System.out.println(result);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FirmException(e.getMessage());

		}

	}

	/**
	 * App name: FirmApp
	 * Version : 1.0
	 * Module : Register
	 */
	
	@Override
	public void activateFirm(FirmApp fObj) throws FirmException {
		// TODO Auto-generated method stub
		con = DBConnection.getConnection();
		String updateStatusQuery = "UPDATE FIRMS_MASTER SET ISACTIVE = ? WHERE EMAIL = ?";
		try {
			pst1 = con.prepareStatement(updateStatusQuery);
			pst1.setString(1, fObj.getIsActive());
			pst1.setString(2, fObj.getEmailId());
			int result = pst1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new FirmException(e.getMessage());
		}
	}

}
