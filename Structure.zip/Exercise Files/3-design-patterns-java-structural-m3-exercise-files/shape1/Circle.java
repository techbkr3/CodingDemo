package com.pluralsight.bridge.shape1;

public abstract class Circle extends Shape {

}
