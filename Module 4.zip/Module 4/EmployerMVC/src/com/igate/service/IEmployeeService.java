package com.igate.service;

import java.util.ArrayList;

import com.igate.dto.Employee;

public interface IEmployeeService {

	public int addEmployee(Employee eDetails);

	public ArrayList<Employee> getEmployees();

}
