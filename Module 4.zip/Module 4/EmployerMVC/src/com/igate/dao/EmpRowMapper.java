package com.igate.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.dto.Employee;

public class EmpRowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet res, int count) throws SQLException {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.seteName(res.getString(1));
		emp.seteMail(res.getString(2));
		emp.seteDate(res.getString(3));
		emp.seteSalary(res.getString(4));
		return emp;
	}

}
