package com.igate.dao;

import java.sql.Date;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.igate.dto.Employee;

@Repository("dao")
public class EmployeeDAOImpl extends JdbcDaoSupport implements IEmployeeDAO {
	
	@Autowired
	private DataSource ds;
	
	@PostConstruct
	public void initialize()
	{
		setDataSource(ds);
	}

	@Override
	public int addEmployee(Employee eDetails) {
	String query = "INSERT INTO mvcemployee values (?,?,?,?)";
	Date sqlDate = Date.valueOf(eDetails.geteDate());
	System.out.println(sqlDate);
	Object params[] = {eDetails.geteName(),eDetails.geteMail(),sqlDate,eDetails.geteSalary()};
	int result = getJdbcTemplate().update(query,params);
		return result;
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		String fetchSql="select * from mvcemployee";
		ArrayList<Employee> details=(ArrayList<Employee>) getJdbcTemplate().query(fetchSql,new EmpRowMapper());		
		return details;
	}

}
