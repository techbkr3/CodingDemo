package com.igate.dao;

import java.util.ArrayList;

import com.igate.dto.Employee;

public interface IEmployeeDAO {

	public int addEmployee(Employee eDetails);

	public ArrayList<Employee> getEmployees();

}
