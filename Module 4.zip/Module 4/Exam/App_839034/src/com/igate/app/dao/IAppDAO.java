package com.igate.app.dao;

public interface IAppDAO {

}
