package com.igate.employee.dao;

import java.util.ArrayList;

import com.igate.employee.dto.Employee;

public interface IEmployeeDao {
	public int insertEmp(Employee emp);
	
	public ArrayList<Employee> getEmployees();

}
