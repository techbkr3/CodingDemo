package com.igate.myaop;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
	public static void main(String[] args) {
		ApplicationContext ap=new ClassPathXmlApplicationContext("spring.xml");
		MyService ss=ap.getBean("ser",MyService.class);
		System.out.println(ss.getTran().getName());
	}
	
	
}
