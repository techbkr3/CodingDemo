package com.igate.myaop;

public class MyService {
	
	private Triangle tran;
	private Circle cir;
	public Triangle getTran() {
		return tran;
	}
	public void setTran(Triangle tran) {
		this.tran = tran;
	}
	public Circle getCir() {
		return cir;
	}
	public void setCir(Circle cir) {
		this.cir = cir;
	}
	
	
}
