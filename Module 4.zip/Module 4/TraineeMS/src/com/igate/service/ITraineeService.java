package com.igate.service;

public interface ITraineeService {

}
