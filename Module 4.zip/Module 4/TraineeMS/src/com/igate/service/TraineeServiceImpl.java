package com.igate.service;

public class TraineeServiceImpl implements ITraineeService {

}
