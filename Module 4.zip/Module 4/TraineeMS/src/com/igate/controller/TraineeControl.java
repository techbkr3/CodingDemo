package com.igate.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TraineeControl {
	
	@RequestMapping("login")
	public void login (@RequestParam("tUsername")String tUsername,@RequestParam("tPassword")String tPassword,Model model)
	{
		
	}

}
