package com.igate.dto;

public class Trainee {
	
	String tUsername;
	String tPassword;
	int tId;
	String tName;
	String tDomain;
	String tLocation;
	

}
