package com.igate.five.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.igate.five")
@PropertySource("classpath:/user.properties")
public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ap = SpringApplication.run(TestMain.class, args);
		
		Employee emp = (Employee) ap.getBean("emp");
		emp.setEmpName("Hello");
		System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpPass());

	}

}
