package com.igate.mvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.mvc.dto.Library;

public class LibraryRowMapper implements RowMapper<Library> {

	

	@Override
	public Library mapRow(ResultSet res, int count) throws SQLException {
		// TODO Auto-generated method stub
		Library lib = new Library();
		lib.setBookId(res.getInt(1));
		lib.setBookName(res.getString(2));
		lib.setDuration(res.getInt(3));
		lib.setAuthor(res.getString(4));
		lib.setType(res.getString(5));
		return lib;
	}

}
