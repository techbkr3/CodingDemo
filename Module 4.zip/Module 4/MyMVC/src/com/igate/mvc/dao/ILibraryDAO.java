package com.igate.mvc.dao;

import java.util.List;

import com.igate.mvc.dto.Library;

public interface ILibraryDAO {

	public List<Library> getBooks();

	public Library getBookDetails(String id);

	public int updateBookDetails(Library obj);

	public int deleteBookDetails(int bookId);

}
