package com.igate.mvc.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

public class User {
	@NotEmpty(message = "Enter Your username")
	@Pattern(regexp = "^[a-zA-Z]+$",message="Enter only character")
	private String userName;
	@NotEmpty(message = "Enter Your password")
	private String userPass;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPass() {
		return userPass;
	}
	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", userPass=" + userPass + "]";
	}
	
}
