package com.igate.mvc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.igate.mvc.dto.Library;
import com.igate.mvc.service.ILibraryService;

@Controller
public class MyLogin {
	
	@Autowired
	ILibraryService service;
	
	@RequestMapping(value="/show",method=RequestMethod.GET)
	public ModelAndView getAll()
	{
		List<Library> list = service.getBooks();
		return new ModelAndView("list","myList",list);
		
	}
	
	@RequestMapping(value="/edit",method=RequestMethod.GET)
	public String getData(@RequestParam("id") String id,Map<String,Object> model)
	{
		Library myLib = service.getBookDetails(id);
		List<String> myType = new ArrayList<String>();
		myType.add("hard");
		myType.add("soft");
		model.put("myType",myType);
		model.put("my",myLib);
		return "register";
	}
	
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView updateData(@ModelAttribute("my") Library obj)
	{
		int result = service.updateBookDetails(obj);
		if(result==1)
		{
			List<Library> objlist = service.getBooks();
		return new ModelAndView("list","myList",objlist);
		}
		return null;
		
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deleteData(@RequestParam("id") int id)
	{
	System.out.println(id);	
	int result = service.deleteBookDetails(id);

		if(result==1)
		{
			List<Library> objlist = service.getBooks();
		return new ModelAndView("list","myList",objlist);
		}
		return null;
	}

}