package com.igate.training.service;

import java.util.ArrayList;

import com.igate.training.dto.Book;

public interface IBookService {
	
	public int addBook(Book book);

	public ArrayList<Book> getAllDetails();
	

}
