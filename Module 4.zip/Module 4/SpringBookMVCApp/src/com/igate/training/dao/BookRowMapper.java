package com.igate.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.training.dto.Book;

public class BookRowMapper implements RowMapper<Book> {

	@Override
	public Book mapRow(ResultSet res, int num) throws SQLException {
		// TODO Auto-generated method stub
		Book bk = new Book();
		bk.setBookName(res.getString(1));
		bk.setBookPrice(res.getString(2));
		bk.setBokCategory(res.getString(3));
		return bk;
	}

}
