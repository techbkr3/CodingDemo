package com.igate.training.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.training.dto.Book;
import com.igate.training.service.IBookService;

@Controller
public class BookController {
	
	@Autowired
	IBookService service;
	
	ArrayList<String> category = new ArrayList<>();
	
	@RequestMapping("displayForm")
	public String showForm(Model model)
	{
		category.add("Education");
		category.add("Fiction");
		category.add("Fashion");
		category.add("Comic");
		category.add("Thriller");
		
		model.addAttribute("category", category);
		model.addAttribute("book", new Book()); //pass empty book object to hold the values
		return "book";
	}
	
	@RequestMapping(value="processBook",method=RequestMethod.POST)
	public String processDetails(@ModelAttribute("book") Book obj,Model model)
	{
		try{
			int result = service.addBook(obj);
			if(result!=0)
			{
				model.addAttribute("details", obj);
				return "success";
			}
			else
			{
				model.addAttribute("details", "Book details not inserted");
				return "failure";
			}
		}
		catch(DataAccessException e){
			model.addAttribute("details",e.getMessage());
			return "error";
		}
		
	}
	
	@RequestMapping("ShowAll")
	public String displayAllBooks(Model model)
	{
		ArrayList<Book> bookDetails = service.getAllDetails();
		try{
		if(bookDetails!=null)
		{
			model.addAttribute("bookDetails", bookDetails);
			return "showAll";
		}
		else
		{
			model.addAttribute("bookDetails", "Book details not sufficient");
			return "failure";
		}
	}
	catch(DataAccessException e){
		model.addAttribute("bookDetails",e.getMessage());
		return "error";
	}
	}

}
