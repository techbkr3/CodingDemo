package com.igate.jdbc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.jdbc.dao.ConnectionDB;
import com.igate.jdbc.dto.Employee;

@Component("ser")
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	ConnectionDB conn;

	@Override
	public int addDate(Employee emp) {
		// TODO Auto-generated method stub
		return conn.addDate(emp);
	}

	@Override
	public List<Employee> getDate() {
		// TODO Auto-generated method stub
		return conn.getDate();
	}
	
	

}
