package com.igate.jdbc.service;

import java.util.List;

import com.igate.jdbc.dto.Employee;

public interface IEmployeeService {
	
	public int addDate(Employee emp);
	public List<Employee> getDate();

}
