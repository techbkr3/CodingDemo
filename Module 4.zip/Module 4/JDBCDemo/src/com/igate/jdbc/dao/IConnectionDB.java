package com.igate.jdbc.dao;

import java.util.List;

import com.igate.jdbc.dto.Employee;

public interface IConnectionDB{
	
	public int addDate(Employee emp);
	public List<Employee> getDate();

}
