package com.igate.jdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.jdbc.dto.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet res, int num) throws SQLException {
		// TODO Auto-generated method stub
		Employee emp = new Employee();
		emp.setEmpId(res.getInt(1));
		emp.setEmpName(res.getString(2));
		emp.setEmpSalary(res.getDouble(3));
		return emp;
	}

}
