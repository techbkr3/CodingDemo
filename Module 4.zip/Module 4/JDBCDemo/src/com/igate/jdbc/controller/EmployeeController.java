package com.igate.jdbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.igate.jdbc.dto.Employee;
import com.igate.jdbc.service.EmployeeServiceImpl;

@Component("cont")
public class EmployeeController {
	@Autowired
	Employee empo;
	@Autowired
	EmployeeServiceImpl ser;

	public EmployeeServiceImpl getSer() {
		return ser;
	}

	public void setSer(EmployeeServiceImpl ser) {
		this.ser = ser;
	}

	public int addDataEmployee(int id, String name, double salary) {
		
		empo.setEmpId(id);
		empo.setEmpName(name);
		empo.setEmpSalary(salary);		
		return ser.addDate(empo);
	}
	
	public List<Employee> getDate()
	{
		return ser.getDate();
	}

}
