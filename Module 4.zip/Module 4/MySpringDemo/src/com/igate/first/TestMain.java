package com.igate.first;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ac = new ClassPathXmlApplicationContext("spring.xml");

		Shape sp = (Shape) ac.getBean("tran");

		sp.draw();

	}

}