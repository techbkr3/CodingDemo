package com.igate.first;

public interface Shape {
	
	public void draw();

}
