package com.igate.first;

import java.util.List;

public class Triangle implements Shape {
	
	
	List<Point> point;
	
	
	
	
	
	/*String type;
	String name;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Triangle(String my,String value)
	{
		System.out.println(my);
	}*/
	
	/*Point p1;
	Point p2;
	Point p3;
	
	public Point getP1() {
		return p1;
	}

	public void setP1(Point p1) {
		this.p1 = p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP2(Point p2) {
		this.p2 = p2;
	}

	public Point getP3() {
		return p3;
	}

	public void setP3(Point p3) {
		this.p3 = p3;
	}
*/
	public List<Point> getPoint() {
		return point;
	}

	public void setPoint(List<Point> point) {
		this.point = point;
	}

	@Override
	public void draw() {
		 
		/*System.out.println("X Value is "+p1.getX()+"\n Y Value is"+getP1().getY());
		System.out.println("X Value is "+p2.getX()+"\n Y Value is"+p2.getY());
		System.out.println("X Value is "+p3.getX()+"\n Y Value is"+p3.getY());*/
		
		for(Point p:point)
		{
			System.out.println("X Value is "+p.getX());
			System.out.println("Y Value is "+p.getY());
		}
	
	}

}
