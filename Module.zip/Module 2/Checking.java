import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;


public class Checking {
	
	public static void main(String[] args) {
		
	/*	boolean b = new Boolean("true");
		boolean c = new Boolean("false");
		
		System.out.println(b==c);
		System.out.println(new Boolean("true")==new Boolean("true"));*/
		
/*		String str = "Hello";
		String str1 = "Hello WOrld";
		String str2 = "Hello WOrld";
		String st3 = str;
		System.out.println(str.hashCode());
		System.out.println(str1.hashCode());
		System.out.println(st3.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str==str1);*/
		
		/*String a = new String("A");
		String b = new String("B");
		String c = b;
		
		System.out.println(b.hashCode());
		System.out.println(c.hashCode());
		
		Checking d = new Checking();*/
		
		/*Integer a = new Integer(5);
		int b = 5;*/
		
		/* */
		
		//Chapter 16 - pg.no. 12/13/14
		
		List<String> l = new ArrayList(Arrays.asList("one","two"));
		Stream<String> sl = l.stream();
		l.add("three");
		l.add("three");
		System.out.println(sl.count());

	}
	
	
	

}
