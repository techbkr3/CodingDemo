
abstract class check1 {

	
	public static void print() {
		System.out.println("Print");
		
	}
	
}

public class check extends check1
{
	int ad;
	
	
	
	public check() {
		super();
	}



	public static void main(String[] args) {
		
	print();
	}
}