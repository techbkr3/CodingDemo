import java.util.InputMismatchException;
import java.util.Scanner;

public class HelloWorld {
	
	int age;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public static void main(String[] args) throws InputMismatchException {
		System.out.println("Hello World!");
		System.out.println("Enter your age:");
		
		try{
		Scanner s = new Scanner(System.in);

			int ageHW = s.nextInt(); 
			HelloWorld hw = new HelloWorld();
			hw.setAge(ageHW);
			int h = hw.getAge();
			System.out.println(h);
		}
		catch (Exception e){
			System.out.println(e);
			
		}
		
	}

}