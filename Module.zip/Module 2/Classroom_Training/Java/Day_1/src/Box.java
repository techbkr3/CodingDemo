class Box{
	//instance variables.... can be accessed by creating an on object
	protected long width ;
	long height ;
	long depth ;
	static int count;
	
	//instance method
		void volume(){
			System.out.println("Volume is:" + height*width*depth);
		}
		
		static String print()
		{
			return "I am example of static";
		}
		
		
	
}

//POJO - play old java object