
public class TestStatic {
	
	static int num_of_days;
	
	static{
		
		num_of_days = 9;
		System.out.println("Core Java with JAXB is for 9 Days");
	}
	static{
		
		System.out.println("I'm second static block");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			test();
	TestStatic ts = new TestStatic();
	ts.show();
 
	}
	//static members can only access static members
	//non static members can access both.
	static void test()
	{	test1();
		System.out.println("I'm tested for static");
	}
	static void test1()
	{
		System.out.println("I'm tested for static");
	}
	
	public void show()
	{
		test();
		System.out.println("I'm show");
	}

}
