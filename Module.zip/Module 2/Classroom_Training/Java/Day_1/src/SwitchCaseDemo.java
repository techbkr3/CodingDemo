
public class SwitchCaseDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//cases with string is from JDK version 7 onwards
		String state = args[0];
		switch(state)
		{
		case"TamilNadu":System.out.println("Capital is MADRAS"); break;
		case"KARNATAKA":System.out.println("Capital is Bangalore"); break;
		default: System.out.println("You're from Prakriti"); break;
		}
		
		
		
	}

}
