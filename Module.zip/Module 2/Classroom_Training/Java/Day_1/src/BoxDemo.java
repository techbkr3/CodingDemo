public class BoxDemo {


	public static void main(String[] args) {
		//make an object
		Box obj = new Box();
		Box obj1 = new Box();
		obj.width = 999999;
		obj.height = 9999;
		obj.depth = 9999;
		obj.volume();
		obj1.volume();
		Box.count = 99;
		System.out.println(Box.count);
		String result = Box.print();
		System.out.println(result);
		System.out.println(obj1.count);
		final int ahaan= 10;
		System.out.println(ahaan);
		
	}

}
