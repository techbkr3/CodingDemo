import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;


public class MCollections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set<Location> locs = new HashSet<>();
		locs.add(new Location("Pune","MH",5600));
		locs.add(new Location("Mumbai","MH",3600));
		locs.add(new Location("Noida","UP",50600));
		Location obj = new Location("Noida","UP",50600);
		Locations data = new Locations();
		data.setLocs(locs);
		try {
			JAXBContext con = JAXBContext.newInstance(Locations.class);
			Marshaller m = con.createMarshaller();
			FileWriter fw = new FileWriter(new File("locs.xml"));
			m.marshal(data, fw);
			System.out.println("Marshalling Successful");
		} catch (JAXBException | IOException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
	}

}
