import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Locations {

	private Set<Location> locs;
	
	@XmlElement
	public Set<Location> getLocs()
	{
		return locs;
	}
	
	public void setLocs(Set<Location> locs)
	{
		this.locs = locs;
	}
	
	
}
