import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;


public class EUnmarshalling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try
		{
			JAXBContext con = JAXBContext.newInstance(Employee.class);
			Unmarshaller m = con.createUnmarshaller();
			File file = new File("emp.xml");
			Employee obj = (Employee) m.unmarshal(file);
			System.out.println(obj.getEmpId());
			System.out.println(obj.getEmpName());
			System.out.println(obj.getJoinDate());
			System.out.println(obj.getLevel());
			System.out.println(obj.getRole());
		}
		catch(JAXBException e)
		{
			System.err.println(e.getMessage());
		}

	}

}
