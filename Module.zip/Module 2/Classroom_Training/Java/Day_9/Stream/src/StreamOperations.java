import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class StreamOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		InterviewRepository rep = new InterviewRepository();
		List<Candidate> repo= InterviewRepository.getCandidateList();
//		System.out.println(repo);
		
	/*	Iterator<Candidate> it = repo.iterator();
		while(it.hasNext())
		{
			System.out.println(repo);
		}*/
		/*
		for(Candidate c : repo)
		{
			System.out.println(c);
		}*/
/*		System.out.println("Candidates from pune city");
		
		repo.stream().filter(c->c.getCity().equals("Pune")).forEach(System.out::println);
		
		System.out.println("Freshers");
		repo.stream().filter(n->n.getYearsOfExperience()==0).forEach(System.out::println);;
		
		System.out.println("Highest Experience");
		Integer max = repo.stream()
				.map(candid->candid.getYearsOfExperience())
				.max(Integer::compare).get();
		System.out.println("Highest Exp: "+max);
		
		Comparator<Candidate> nComp = (c1,c2) -> {return c1.getName().compareTo(c2.getName());};
		
		System.out.println("Sorting");
		repo.stream().sorted(nComp).forEach(System.out::println);*/
		
		System.out.println("Grouping");
		repo.stream().collect(Collectors.groupingBy(Candidate::getTechnicalExpertise));
		
		Map<String,List<Candidate>> data = repo.stream().collect(Collectors.groupingBy(Candidate::getTechnicalExpertise));
		
		for(String key:data.keySet())
		{
			System.out.println(key+"\t"+data.get(key).size());
		}
		
		Integer i = new Integer(12);
		int i2 = 12;
		System.out.println(i==i2);
		
		String s1 = "Hello";
		String s2 = s1;
		System.out.println(s1==s2);
		
		Double d = new Double(55);
		double d1= 55;
		
		System.out.println(d==d1);

		
		
	}

}