package Lambda;

public class FinderImpl implements MaxFinder{

	@Override
	public int max(int n1, int n2) {
		// TODO Auto-generated method stub
		return (n1 > n2 ? n1 : n2);
	}
	
	

}
