package Lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;

public class TestFI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MaxFinder f = new FinderImpl();
		
		int max = f.max(20, 10);
		System.out.println(max);
		
//		Using Lambda Exp
		
		MaxFinder fin = (n1,n2) -> n1>n2?n1:n2;
		
		System.out.println(fin.max(30, 40));
		
		List<Integer> data = new ArrayList<>();
		data.add(34);
		data.add(54);
		data.add(100);
		data.add(0);
		data.add(14);
		data.add(9);

		Comparator<Integer> comp = (Integer i1, Integer i2) ->
		{	int r;
			return r = i1.compareTo(i2);
		};
		
		Collections.sort(data,comp);
		System.out.println(data);
		for(Integer d:data)
		{
			System.out.println(d);
		}
		
		
		
	}

}
