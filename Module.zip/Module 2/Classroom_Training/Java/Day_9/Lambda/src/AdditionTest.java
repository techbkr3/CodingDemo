import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class AdditionTest {
	
	int expected,first,second;
	
	static Addition obj;
	
	@Parameters
	public static Collection<Integer[]>testData()
	{
		System.out.println("I'm called first");
		Integer[][] numbers = new Integer[][] {{3,1,2},{3,1,2},{3,1,2},{3,1,2}};
		List<Integer[]> data = Arrays.asList(numbers);
		return data;
		
	}
	
	public AdditionTest(int expected,int first,int second) {
		super();
		this.expected = expected;
		this.first = first;
		this.second = second;
		System.out.println(expected+"\t"+first+"\t"+second);
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		obj = new Addition();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		obj = null;
	}

	@Test
	public void test() {
		assertEquals(expected, obj.add(first,second));
	}

}
