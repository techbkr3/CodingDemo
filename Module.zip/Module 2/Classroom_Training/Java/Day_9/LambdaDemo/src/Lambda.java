import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//accept
		Consumer<String> consumer = (str) -> System.out.println(str);
		consumer.accept("Adi Dev");

		//get
		Supplier<String> supplier = () -> "Hello From Supplier";
		consumer.accept(supplier.get());
		
		//test
		Predicate<Integer> predicate = (num1) -> num1%2==0;
		System.out.println(predicate.test(24));
		System.out.println(predicate.test(1));
		System.out.println(predicate.test(3));
		
		//apply
		BiFunction<Integer,Integer,Integer> maxFn = (x,y)->x>y?x:y;
		int maxV = maxFn.apply(14,25);
		System.out.println(maxV);
	}

}