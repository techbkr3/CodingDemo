import java.util.function.BiFunction;


public class PowerLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BiFunction<Integer, Integer, Integer> pow = (x,y) -> (int) Math.pow(x, y);
		System.out.println(pow.apply(2, 3));

	}

}
