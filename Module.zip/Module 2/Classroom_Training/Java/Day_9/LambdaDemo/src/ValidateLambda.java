import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.function.BiPredicate;
import java.util.function.Supplier;


public class ValidateLambda {

	public static void main(String[] args) {
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Enter Username");
			String username = br.readLine();
			System.out.println("Enter password");
			String password = br.readLine();
			BiPredicate<String, String> valid = (u,p) -> 
			{
				if(u.equalsIgnoreCase(username)&&p.equalsIgnoreCase(password))
				{
					return true;
				}
				else
					return false;
			};
			
			boolean res = valid.test(username,password);
			System.out.println(res);
			
			Class c1 = new Class();
			
			
			Supplier<Class> s = Class::new; //instance creation = Method reference
			Class c = s.get(); 
			c.setName("Kathy");
			c.setAge(15);
			System.out.println(c.getAge());
			System.out.println(c.getName());
			
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
}
