package dao;

import java.util.ArrayList;

import dto.Employee;
import exception.InvalidEmp;

public interface IEmployeeSearch {
	
	public Employee getEmpbyID(int empid) throws InvalidEmp;

	public ArrayList<Employee> getEmpbyDept(String empdept) throws InvalidEmp;

}
