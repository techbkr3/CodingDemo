package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import util.DBUtility;
import dto.Employee;
import exception.InvalidEmp;



public class EmployeeSearch implements IEmployeeSearch {
	
	static Logger log = Logger.getLogger(EmployeeSearch.class);

	@Override
	public Employee getEmpbyID(int empid) throws InvalidEmp {
		PropertyConfigurator.configure("log4j.properties");
		String sql ="select * from emp where empno=?";
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		Employee obj = null;
		try{
			con = DBUtility.obtainConnection();
			log.info("Connection Successful");
			ps = con.prepareStatement(sql);
			ps.setInt(1, empid);
			rs = ps.executeQuery();
			log.info("Query Execution");
			if(rs.next())
			{
				log.info("ResultSet Display");
				obj = new Employee();
				obj.setEmpName(rs.getString("ENAME"));
				obj.setEmpNum(rs.getInt("EMPNO"));
				obj.setJob(rs.getString("JOB"));
				obj.setMgrId(rs.getInt("MGR"));
				obj.setHireDate(rs.getDate("HIREDATE").toLocalDate());
				obj.setEmpSal(rs.getFloat("SAL"));
				float com = rs.getFloat("COMM");
				if(com>0)
				{
					obj.setComm(com);
				}
				
			}
		}
		catch(SQLException e)
		{
			log.error("Error in DB Operation");
			throw new InvalidEmp("Error in DB Operation");
		}
		finally
		{
			try {
				log.info("Releasing Connection");
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				log.error("Error in DB Operation");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return obj;
	}

	@Override
	public ArrayList<Employee> getEmpbyDept(String empdept) throws InvalidEmp {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		String sql ="select * from emp,dept where emp.deptno=dept.deptno and dname=?";
		Connection con;
		PreparedStatement ps;
		ResultSet rs;
		ArrayList<Employee> obj = new ArrayList<Employee>();;
		try{
			
			con = DBUtility.obtainConnection();
			log.info("Connection Successful for DEPT NAME MODULE");
			ps = con.prepareStatement(sql);
			ps.setString(1, empdept);
			
			rs = ps.executeQuery();
			log.info("Query Executed");
			int k=1;
			
			while(rs.next())
			{
				log.debug("Iteration Started "+k);
				Employee e = new Employee();
				e.setEmpName(rs.getString("ENAME"));
				e.setEmpNum(rs.getInt("EMPNO"));
				e.setJob(rs.getString("JOB"));
				e.setMgrId(rs.getInt("MGR"));
				e.setHireDate(rs.getDate("HIREDATE").toLocalDate());
				e.setEmpSal(rs.getFloat("SAL"));
				float com = rs.getFloat("COMM");
				if(com>0)
				{
					e.setComm(com);
				}
				obj.add(e);
				k++;
				
			}
		}
		catch(SQLException e)
		{	log.error("Error in Fetch BY Dept");
			throw new InvalidEmp("Error in DB Operation");
		}
		finally
		{
			try {
				log.info("Connection closed");
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return obj;
	}

}
