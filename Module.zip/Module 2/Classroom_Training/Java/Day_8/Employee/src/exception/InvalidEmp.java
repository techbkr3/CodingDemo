package exception;

public class InvalidEmp extends Exception{
	
	public InvalidEmp(String msg)
	{
		super(msg);
	}

}