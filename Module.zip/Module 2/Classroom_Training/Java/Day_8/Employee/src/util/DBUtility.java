package util;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class DBUtility {
	
	static String driverName;
	static String url;
	static String userName;
	static String password;
	static Connection connection;
	
	static{
		Properties prop = new Properties();
		try{
			FileInputStream fis = new FileInputStream("jdbc.properties");
			prop.load(fis);
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
		driverName = prop.getProperty("db.drivername");
//		System.out.println(driverName);
		url = prop.getProperty("db.url");
//		System.out.println(url);
		userName = prop.getProperty("db.username");
		password = prop.getProperty("db.password");
	}
	
	public static Connection obtainConnection() throws SQLException
	{
		connection = DriverManager.getConnection(url,userName,password);
		return connection;
	}
	
	public static void releaseConnection() throws SQLException
	{
		if(connection!=null)
			connection.close();
	}

}