package service;

import java.util.ArrayList;

import dao.EmployeeSearch;
import dao.IEmployeeSearch;
import dto.Employee;
import exception.InvalidEmp;

public class EmpService implements ISEmpService{
	
	IEmployeeSearch io =  new EmployeeSearch();

	@Override
	public Employee getEmpbyID(int empid) throws InvalidEmp {
		// TODO Auto-generated method stub
		return io.getEmpbyID(empid);
	}

	@Override
	public ArrayList<Employee> getEmpbyDept(String empdept) throws InvalidEmp {
		// TODO Auto-generated method stub
		return io.getEmpbyDept(empdept);
	}

}
