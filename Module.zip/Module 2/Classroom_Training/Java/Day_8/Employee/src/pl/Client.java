package pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import service.EmpService;
import service.ISEmpService;
import dao.EmployeeSearch;
import dao.IEmployeeSearch;
import dto.Employee;
import exception.InvalidEmp;

public class Client {

	public static void main(String[] args) throws InvalidEmp {
		// TODO Auto-generated method stub
		ISEmpService io =  new EmpService();
		int choice=0;
		
		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Option");
			choice = Integer.parseInt(br.readLine());
			switch(choice)
			{
			case 1:System.out.println("Emter Emp id to search");
			int empid = Integer.parseInt(br.readLine());
				try {
					Employee obj = io.getEmpbyID(empid);
					System.out.println(obj);
				} catch (InvalidEmp e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			break;			
			case 2:System.out.println("Enter dept name to search");
			String empdept = br.readLine();
				ArrayList<Employee> obj = io.getEmpbyDept(empdept);
				for(Employee e:obj)
				{
					System.out.println(e);
				}
				break;
			case 3:System.exit(0);
				break;
				default:System.out.println("Invalid Selection");
				break;
		}
		}
		catch (IOException e)
		{
			
		}

	}

}
