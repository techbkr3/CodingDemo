import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Log4JPropertyFile {
	
	static Logger log = Logger.getLogger(Log4JPropertyFile.class);
	
	Object x;
	
	
	public void do_some(int a,float b)
	{
		log.info("Do something"+a+""+b);
		log.debug("Operation performed successfuly");
		
		if(x==null)
		{
			log.error("value of x is null");
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		Log4JPropertyFile ll = new Log4JPropertyFile();
		ll.do_some(5,(float)5.5);

	}

}
