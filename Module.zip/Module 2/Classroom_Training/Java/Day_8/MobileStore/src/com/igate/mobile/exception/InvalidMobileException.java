package com.igate.mobile.exception;

public class InvalidMobileException extends Exception {
	
	public  InvalidMobileException(String msg)
	{
		super(msg);
	}

}
