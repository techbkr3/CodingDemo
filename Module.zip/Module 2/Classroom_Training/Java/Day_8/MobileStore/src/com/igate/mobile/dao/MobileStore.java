package com.igate.mobile.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.igate.mobile.dto.MStore;
import com.igate.mobile.exception.InvalidMobileException;
import com.igate.mobile.util.DBUtility;

public class MobileStore implements IMobileStore {

	@Override
	public ArrayList<MStore> getModels() throws InvalidMobileException {
		ArrayList<MStore> details = new ArrayList<>();
		String displayQ = "select * from mobilesj";
		Connection con;
		Statement st;
		ResultSet rs;
		try {
			con = DBUtility.obtainConnection();
			st = con.createStatement();
			rs = st.executeQuery(displayQ);
			MStore m = null;
			while(rs.next())
			{
				m = new MStore();
				m.setMobileId(rs.getInt("mobileid"));
				m.setMobileName(rs.getString("name"));
				m.setMobilePrice(rs.getInt("price"));
				m.setMobileQty(rs.getInt("quantity"));
				details.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidMobileException("Problem in displaying results");
		}
		
		return details;
	}

	@Override
	public int deletePhoneModel(int delPhone) throws InvalidMobileException {
		String deleteQ = "delete from mobilesj where mobileid = ?";
		Connection con;
		PreparedStatement pst;
		
		try {
			con=DBUtility.obtainConnection();
			pst = con.prepareStatement(deleteQ);
			pst.setInt(1, delPhone);
			int rows = pst.executeUpdate();
			
			if(rows>0)
			{
				return 1;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidMobileException("Problem in deleting phone model");
		}
		
		
		return 0;
	}

	@Override
	public ArrayList<MStore> searchPhoneModel(int sRange, int eRange) throws InvalidMobileException {
		// TODO Auto-generated method stub
		ArrayList<MStore> details = new ArrayList<>();
		String searchQ = "select * from mobilesj where price > ? and price < ?";
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try {
			con = DBUtility.obtainConnection();
			pst = con.prepareStatement(searchQ);
			pst.setInt(1, sRange);
			pst.setInt(2, eRange);
			rs = pst.executeQuery();
			MStore m = null;
			while(rs.next())
			{
				m = new MStore();
				m.setMobileId(rs.getInt("mobileid"));
				m.setMobileName(rs.getString("name"));
				m.setMobilePrice(rs.getInt("price"));
				m.setMobileQty(rs.getInt("quantity"));
				details.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidMobileException("Problem in search results");
		}
		
		return details;
	}

	@Override
	public int buyMobile(String cName, String cMail, Long cPhone, int cMobile) throws InvalidMobileException {
		String seq = "select purseq.nextval from dual";
		String selQ = "select QUANTITY from mobilesj where mobileid=?";
		String insertQ = "insert into purchases values(?,?,?,?,?,?)";
		String updateQ = "update mobilesj set QUANTITY=QUANTITY-? where mobileid=?";
		
		int pId =0;
		Connection con = null;
		Statement st= null;
		PreparedStatement pst1= null;
		PreparedStatement pst2= null;
		PreparedStatement pst3= null;
		ResultSet rs= null;
		ResultSet rs1= null;
		
		try {
			LocalDate jdate = LocalDate.now();
			Date sdate = Date.valueOf(jdate);			
			con = DBUtility.obtainConnection();
			st = con.createStatement();			
			rs = st.executeQuery(seq);
			rs.next();
			pId = rs.getInt(1);
			pst1 = con.prepareStatement(selQ);
			pst1.setInt(1, cMobile);
			rs1 = pst1.executeQuery();
			int availableQty=0;
			if(rs1.next())
			{
				availableQty = rs1.getInt(1);
			}	
			else
			{
				System.out.println("Product Unavailable");
			}
			
			if(availableQty>0)
			{
				pst2= con.prepareStatement(insertQ);
				pst2.setInt(1, pId);
				pst2.setString(2, cName);
				pst2.setString(3, cMail);
				pst2.setLong(4, cPhone);
				pst2.setDate(5, sdate);
				pst2.setInt(6,cMobile);
				int rows1 = pst2.executeUpdate();
				
				pst3 = con.prepareStatement(updateQ);
				pst3.setInt(1, 1);
				pst3.setInt(2, cMobile);
				int rows2 = pst3.executeUpdate();
				
				if(rows1 != 0 && rows2 != 0)
				{
					return pId;
				}
			}
			else
			{
				throw new InvalidMobileException("Stock Unavailable");
			}
					
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new InvalidMobileException("Error "+e.getMessage());
		}
		
		finally{
			try {
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new InvalidMobileException("Closing connection error");
			}
		}
		
		return 0;
	}

}
