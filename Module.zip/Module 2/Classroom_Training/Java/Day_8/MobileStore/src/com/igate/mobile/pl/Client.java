package com.igate.mobile.pl;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import java.util.regex.Pattern;

import com.igate.mobile.dao.MobileStore;
import com.igate.mobile.dto.MStore;
import com.igate.mobile.exception.InvalidMobileException;
import com.igate.mobile.service.ISMobileStore;
import com.igate.mobile.service.SMobileStore;

public class Client {

	public static void main(String[] args) throws InvalidMobileException {
		// TODO Auto-generated method stub

		System.out.println("*******************Menu*******************");
		System.out
				.println("1.Insert the customer and purchase details into database");
		System.out.println("2.Display the available mobile models");
		System.out.println("3.Delete a mobile model from the store");
		System.out.println("4.Search available models based on price range");
		System.out.println("5.Exit");
		System.out.println("******************************************");
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		ISMobileStore is = new SMobileStore();
		MStore ms = new MStore();
		try {
			choice = sc.nextInt();
		} catch (InputMismatchException e) {
			System.out.println("Try with proper inputs");
		}

		switch (choice) {
		case 1: {
			String cName = null;
			String cMail = null;
			String cMobiles = null;
			Long cPhone = null;
			String phonePattern = "^[7-9][0-9]{9}$";
			String namePattern = "^[A-Z][a-z]{5,20}$";
			String mailPattern = "^([A-Za-z]+)(\\.|_)([A-Za-z]+)@([a-z]+)\\.([a-z]{2,3})$";
			try {
				System.out.println("Enter Customer Name");
				cName = sc.next();
				boolean np = Pattern.matches(namePattern, cName);
				while (!np) {

					System.out.println("Enter Customer Name");
					cName = sc.next();
					np = Pattern.matches(namePattern, cName);

				}
				System.out.println("Enter E-Mail ID:");
				cMail = sc.next();
				boolean mp = Pattern.matches(mailPattern, cMail);
				while (!mp) {
					System.out.println("Enter E-Mail ID:");
					cMail = sc.next();
					mp = Pattern.matches(mailPattern, cMail);
				}
				System.out.println("Enter Phone Number");
				cMobiles = sc.next();
				boolean nup = Pattern.matches(phonePattern, cMobiles);
				while (!nup) {
					System.out.println("Enter Phone Number");
					cMobiles = sc.next();
					nup = Pattern.matches(phonePattern, cMobiles);
				}
				while (nup) {
					cPhone = Long.parseLong(cMobiles);
					break;
				}
				System.out.println("Enter the mobile id you want to purchase");
				int cMobile = sc.nextInt();
				int rows = is.buyMobile(cName, cMail, cPhone, cMobile);
				if (rows == 0) {
					System.out.println("You could not purchase product");
				} else {
					System.out.println("Purchase Successful");
				}

			} catch (InputMismatchException | NumberFormatException e) {
				System.out.println("Invalid Inputs");
			}

			break;
		}
		case 2:
			ArrayList<MStore> mobiles = is.displayModels();
			if (mobiles.isEmpty()) {
				System.out.println("No records to display");
			} else {
				for (MStore al : mobiles) {
					System.out.println(al);
				}
			}

			break;
		case 3:

			try {
				System.out.println("Enter the mobile model to delete");
				int delPhone = sc.nextInt();
				int result = is.deletePhoneModel(delPhone);
				if (result > 0) {
					System.out.println(result + " rows deleted");
				} else {
					System.out.println("Model not exist");
				}
			} catch (InputMismatchException e) {
				System.out.println("Try giving the correct model number");
			}
			break;
		case 4:
			try {
				System.out.println("Enter the starting price range");
				int sRange = sc.nextInt();
				System.out.println("Enter the ending price range");
				int eRange = sc.nextInt();

				ArrayList<MStore> mobile = is.searchPhoneModel(sRange, eRange);
				if (mobile.isEmpty()) {
					System.out.println("No records to display");
				} else {
					for (MStore al : mobile) {
						System.out.println(al);
					}
				}
			} catch (InputMismatchException e) {
				System.out.println("Try giving the correct range");
			}
			break;
		case 5:
			System.out.println("Thank you, Visit Again");
			System.exit(0);
		default: {
			System.out.println("Invalid Selection");
			break;
		}
		}
	}

}