package com.igate.training.demos;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate currentDate = LocalDate.now();
		System.out.println(currentDate);
		
		LocalDate indDay = LocalDate.of(1947, Month.AUGUST, 15);
		System.out.println(indDay);
		
		System.out.println(currentDate.plusDays(100));
		System.out.println(currentDate.minusMonths(100));
		System.out.println(currentDate.lengthOfMonth());
		System.out.println(currentDate.withDayOfMonth(31));
		
		Period diff = indDay.until(currentDate);
		
		System.out.println(diff);
		System.out.println(diff.getDays());
		System.out.println(diff.getMonths());
		System.out.println(diff.getYears());
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
/*		System.out.println("1st Date:");
		String fDate = sc.next();
		System.out.println("2nd Date:");
		String sDate = sc.next();
		
		LocalDate d1 = LocalDate.parse(fDate,format);
		LocalDate d2 = LocalDate.parse(sDate,format);
		Period diffN = d1.until(d2);

		System.out.println(diffN);
		
		
		
//		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//		Scanner sc = new Scanner(System.in);
		System.out.println("Purchase Date:");
		String pDate = sc.next();
		System.out.println("Expiry Years:");
		int years = sc.nextInt();
		System.out.println("Expiry Months:");
		int mon = sc.nextInt();
		
		LocalDate d11 = LocalDate.parse(pDate,format);
		
		d11 = d11.plusYears(years);
		d11 = d11.plusMonths(mon);
		
		System.out.println(d11);*/
		
		
		ZonedDateTime ctim = ZonedDateTime.now(ZoneId.of("America/New_York"));
		
		System.out.println(ctim);
		

		
		
	}

}
