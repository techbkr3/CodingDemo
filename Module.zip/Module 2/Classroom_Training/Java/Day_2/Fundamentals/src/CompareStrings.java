
public class CompareStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1 = "Hello World";
		String s2 = "No Hello World";
		String s3 = "Hello World";
		
		String h1 = new String("Hello World");
		String h2 = new String("No Hello World");		
		String h3 = new String("Hello World");		
		
		if(s1==s2)
			System.out.println("Same Object Comparision Passed");
		else
			System.out.println("Same Object Comparision Failed");
		if(s1==s3)
			System.out.println("Same Object Comparision Passed");
		else
			System.out.println("Same Object Comparision Failed");
		
		if(h1.equals(h2))
			System.out.println("Same Object Comparision Passed");
		else
			System.out.println("Same Object Comparision Failed");
		if(h1.equals(h3))
			System.out.println("Same Object Comparision Passed");
		else
			System.out.println("Same Object Comparision Failed");
		
		

	}

}
