
public class builderdemo {

	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder("Converts the character (Unicode code point) argument to lowercase using case mapping information from the UnicodeData file.");
		System.out.println("Length is "+sb.length());
		System.out.println("Capacity is "+sb.capacity());
		
		sb.append(new Object());
		sb.append(true);
		sb.append(12);
		
		System.out.println("After Appending"+sb);
		
		System.out.println("Inserting at a postition "+sb.insert(34, "Hello"));
		System.out.println(sb.reverse());

	}

}
