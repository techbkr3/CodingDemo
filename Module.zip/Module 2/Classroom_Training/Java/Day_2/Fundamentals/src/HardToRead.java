class Bob extends Object{
	
	int shoezie;
	
	String address;
	
	public Bob(int shoezie, String address) {
		super();
		this.shoezie = shoezie;
		this.address = address;
	}
	
	@Override
	public String toString()
	{
		//String representation of object
		return shoezie + address;
	}
	
}
public class HardToRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bob b = new Bob(12," Pune");
		System.out.println(b.toString());
		
	}

}
