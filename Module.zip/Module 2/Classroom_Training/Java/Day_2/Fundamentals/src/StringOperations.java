
public class StringOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer str = new StringBuffer("ANT");
		
		StringBuffer revst = str.reverse();
		
		for(int i=0;i<revst.length();i++)
		{
			revst.charAt(i);
			revst.charAt(i+1);
		}
		
		
	}

}
