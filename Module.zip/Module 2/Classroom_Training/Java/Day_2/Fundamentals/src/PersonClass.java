
public class PersonClass {


	private String firstName;
	private String lastName;
	private char gender;
	private int age;
	private double weight;
	private long phone;
			
	public PersonClass() {
	}
	

	@Override
	public String toString() {
		return "PersonClass [firstName=" + firstName + ", lastName=" + lastName
				+ ", gender=" + gender + ", age=" + age + ", weight=" + weight
				+ ", phone=" + phone + "]";
	}




	public PersonClass(String firstName, String lastName, char gender, int age,
			double weight, long phone) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
		this.phone = phone;
	}




	public String getFirstName() {
		return firstName;
	}




	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}




	public String getLastName() {
		return lastName;
	}




	public void setLastName(String lastName) {
		this.lastName = lastName;
	}




	public char getGender() {
		return gender;
	}




	public void setGender(char gender) {
		this.gender = gender;
	}




	public int getAge() {
		return age;
	}




	public void setAge(int age) {
		this.age = age;
	}




	public double getWeight() {
		return weight;
	}




	public void setWeight(double weight) {
		this.weight = weight;
	}




	public long getPhone() {
		return phone;
	}




	public void setPhone(long phone) {
		this.phone = phone;
	}




	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
