
public class Name {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person obj = new Person();
		obj.setfName(args[0]);
		obj.setlName(args[1]);
		obj.setAge(Integer.parseInt(args[2]));
		obj.setGender(args[3].charAt(0));
		obj.setWeight(Float.parseFloat(args[4]));
		
		
		System.out.println(obj.getfName());
		System.out.println(obj.getlName());
		System.out.println(obj.getAge());
		System.out.println(obj.getGender());
		System.out.println(obj.getWeight());
		System.out.println();
		System.out.println();
		System.out.println();

	}

}
