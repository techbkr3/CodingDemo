public class WrapperDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Integer iobj = new Integer("10");
		// auto boxing (primitive to object)
		System.out.println("Object now \t" + iobj.intValue());
		// auto unboxing
		int ip = iobj.intValue();
		System.out.println("Primitive now \t" + ip);

		Long lobj = new Long("111111111111111");
		System.out.println(lobj.longValue());
		int ip1 = lobj.intValue();
		System.out.println(ip1);

		Boolean bobj = new Boolean("ahaan");
		boolean bp = bobj.booleanValue();
		
		}

}
