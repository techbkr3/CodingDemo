class X{
	int i;

	public X(int i) {
		this.i = i;
	}
	
	@Override
	public void finalize()
	{
		System.out.println("I'm calling during GC to do closure activity");
	}
	
}
public class GCDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long start = System.currentTimeMillis();
		for(int c=0;c<10000;c++){
			new X(c);
		}
		long end = System.currentTimeMillis();
		System.out.println(start);
		System.out.println(end);
		long tt = (end-start);
		System.out.println(tt);
		
		//Request for GC
		System.gc();

	}

}
