import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 */

/**
 * @author balmurug
 *
 */
public class GreetTest {
	Greeting obj;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		obj = new Greeting();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		obj=null;
	}

	@Test
	public void test() {
		System.out.println(obj.greet());
		assertEquals("Good Morning!!!",obj.greet());
	}

}
