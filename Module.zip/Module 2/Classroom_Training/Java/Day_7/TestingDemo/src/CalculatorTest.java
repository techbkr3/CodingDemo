import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;


public class CalculatorTest {
	static Calculator obj;
	@BeforeClass
	public static void create()
	{
		obj = new Calculator();
	}
	@AfterClass
	public static void destroy()
	{
		obj=null;
	}
	@Test
	public void testAdd() {
	assertEquals(4, obj.add(2, 2));
	}
	
	@Test
	public void testSub() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter sub first digit");
		int first = sc.nextInt();
		System.out.println("Enter second digit");
		int second = sc.nextInt();
		assertEquals(10, obj.sub(first, second));
		}
	@Test
	public void testMul() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter mul first digit");
		int first = sc.nextInt();
		System.out.println("Enter second digit");
		int second = sc.nextInt();
		assertEquals(10, obj.mul(first, second));
	}
	@Test(expected=ArithmeticException.class)
	public void testDiv() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter div first digit");
		int first = sc.nextInt();
		System.out.println("Enter second digit");
		int second = sc.nextInt();
		assertEquals(0, obj.div(first, second));
	}
	

}
