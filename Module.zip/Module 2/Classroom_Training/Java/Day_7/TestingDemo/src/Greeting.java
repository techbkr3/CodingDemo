
public class Greeting {
	
	String greet()
	{
		return "Good Morning!!!";
	}

}
