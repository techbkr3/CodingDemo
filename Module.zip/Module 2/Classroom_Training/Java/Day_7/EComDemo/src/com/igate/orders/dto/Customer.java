package com.igate.orders.dto;

public class Customer {
	
	private String cName;
	private String cAdd;
	private Long cPhone;
	
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcAdd() {
		return cAdd;
	}
	public void setcAdd(String cAdd) {
		this.cAdd = cAdd;
	}
	public Long getcPhone() {
		return cPhone;
	}
	public void setcPhone(Long cPhone2) {
		this.cPhone = cPhone2;
	}

}
