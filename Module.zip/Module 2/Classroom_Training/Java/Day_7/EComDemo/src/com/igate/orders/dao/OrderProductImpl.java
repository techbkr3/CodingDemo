package com.igate.orders.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.igate.orders.dto.Customer;
import com.igate.orders.dto.Product;
import com.igate.orders.exception.InvalidCategoryException;
import com.igate.orders.util.DBUtility;

public class OrderProductImpl implements IOrderProduct {
	
	static{
		PropertyConfigurator.configure("log4j.properties");
	}
	
	static Logger logger = Logger.getLogger(OrderProductImpl.class);

	@Override
	public ArrayList<Product> getProductDetails(String category)
			throws InvalidCategoryException {	
		
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM PRODUCTS,CATEGORY WHERE CATEGORY.CID=PRODUCTS.CID AND CNAME = ?";
		ArrayList<Product> details = new ArrayList<>();
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		logger.info("Fetching the product details");
		try {
			con = DBUtility.obtainConnection();
			pst = con.prepareStatement(sql);
			pst.setString(1, category);

			rs = pst.executeQuery();

			while (rs.next()) {
				Product p = new Product();
				p.setPid(rs.getInt("pid"));
				p.setPname(rs.getString("pname"));
				p.setPprice(rs.getFloat("pprice"));
				p.setPqty(rs.getInt("pqty"));
				p.setCategory(category);

				details.add(p);
			}

		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			logger.error("Error has occured");
			throw new InvalidCategoryException("DB Error" + e.getMessage());
		}
		
		finally{
			try {
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("Error has occured while closing collection");
				throw new InvalidCategoryException("Closing connection error");
			}
		}

		return details;
	}

	@Override
	public int orderProduct(Customer obj, int qty, String pname)
			throws InvalidCategoryException {
		String seQ = "SELECT oseq.nextval from dual";
		String selQ = "SELECT pid,pqty from products where pname = ?";
		String insQ = "INSERT INTO custorder values(?,?,?,?)";
		String updQ = "UPDATE products set pqty = pqty-? where pid =?";
		int orderId = 0;
		Statement st1 = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		Connection con = null;
		ResultSet rs = null;
		ResultSet selrs = null;
		
		logger.info("Ordering products");
		try 
		{
			con = DBUtility.obtainConnection();
			st1 = con.createStatement();
			rs = st1.executeQuery(seQ);
			rs.next();
			orderId = rs.getInt(1);			
			pst1 = con.prepareStatement(selQ);
			pst1.setString(1,pname);
			selrs = pst1.executeQuery();
			int count = 0;
			if(selrs.next())
			{
				count = rs.getInt(1);
			}
			else
			{
				System.out.println("Product Unavailable");
			}
			
			if(count>0)
			{
				int pid = selrs.getInt("pid");
				int qaty = selrs.getInt("pqty");
				if(qty<=qaty)
				{
					pst2= con.prepareStatement(insQ);
					pst2.setInt(1, orderId);
					pst2.setString(2, obj.getcName());
					pst2.setString(3, obj.getcAdd());
					pst2.setLong(4, obj.getcPhone());
					int rows1 = pst2.executeUpdate();
					
					pst3 = con.prepareStatement(updQ);
					pst3.setInt(1, qty);
					pst3.setInt(2, pid);
					int rows2 = pst3.executeUpdate();
					
					if(rows1 != 0 && rows2 != 0)
					{
						return orderId;
					}
					
				}
				else
				{
					System.out.println("Stock Unavailable");
				}
				
			}
			
			
			
		}
		
		catch (SQLException e) {
			throw new InvalidCategoryException("Cat error");
		}
		
		finally{
			try {
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new InvalidCategoryException("Closing connection error");
			}
		}

		return 0;
	}

}
