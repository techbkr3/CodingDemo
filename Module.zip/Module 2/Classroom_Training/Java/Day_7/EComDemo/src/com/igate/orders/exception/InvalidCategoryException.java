package com.igate.orders.exception;

public class InvalidCategoryException extends Exception {
	
	public InvalidCategoryException(String msg)
	{
		super(msg);
	}

}
