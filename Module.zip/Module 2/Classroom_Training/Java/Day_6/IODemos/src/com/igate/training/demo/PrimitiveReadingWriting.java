package com.igate.training.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class PrimitiveReadingWriting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileOutputStream fos = new FileOutputStream("primitive.dat");
			DataOutputStream dos = new DataOutputStream(fos);  //Write primitives
			FileInputStream fis = new FileInputStream("primitive.dat");
			DataInputStream dis = new DataInputStream(fis);  //read primitives					
			)
		{
			dos.writeInt(99);
			dos.writeUTF("Moorthy");
			dos.writeFloat(34.56f);
			dos.writeLong(9042235465l);
			dos.writeBoolean(true);
			
			int i = dis.readInt();
			String s = dis.readUTF();
			float f = dis.readFloat();
			long l = dis.readLong();
			boolean b = dis.readBoolean();
			
			System.out.println(i);
			System.out.println(s);
			System.out.println(f);
			System.out.println(l);
			System.out.println(b);
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		
		//Serializable interface is a marker interface (marker means absolutely has no methods) Its an indication to a JVM that this object will be returned to a file
	}

}
