package com.igate.training.demo;

import java.nio.file.Path;
import java.nio.file.Paths;

public class PathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Path javaHome = Paths.get("D:/Exam/Module 1/Module 1");
		System.out.println(javaHome.getNameCount());
		System.out.println(javaHome.getRoot());
		System.out.println(javaHome.getName(0));
		System.out.println(javaHome.getFileName());
		System.out.println(javaHome.getParent());
		System.out.println(javaHome.getClass());
		
		int a = 50;
	}

}
