package com.igate.training.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.igate.training.demo.bean.Student;

public class SerializationDemo {

	public static void main(String[] args) {
		//Serializable interface is a marker interface (marker means absolutely has no methods) Its an indication to a JVM that this object will be returned to a file
		//During the process of deserialization, the constructor of the class not called
		//if my base class is serializible, child class is automatically serializable
		//if my base class is not serialized, child class can be serializable
		Student obj = new Student(101,"ABC",98.76f,"Pune");
		
		try
		(FileOutputStream fos = new FileOutputStream("student.txt");
		 ObjectOutputStream oos = new ObjectOutputStream(fos);
		 FileInputStream fis = new FileInputStream("student.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		)
		{
			oos.writeObject(obj); //writing object as a stream of bytes
			Student s =  (Student) ois.readObject();
			System.out.println(s);
		}
		catch(IOException | ClassNotFoundException e)
		{
			System.out.println(e.getMessage());
		}
	}

}
