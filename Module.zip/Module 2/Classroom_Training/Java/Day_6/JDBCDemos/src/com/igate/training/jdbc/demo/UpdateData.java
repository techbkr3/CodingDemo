package com.igate.training.jdbc.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Enter Marks to update:");
			float marks =  Float.parseFloat(br.readLine());
			System.out.println("Enter the minimum criteria");
			float min = Float.parseFloat(br.readLine());
			Connection con = DBUtility.obtainConnection();
			String sql = "update student set student_marks=student_marks+? where student_marks > ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setFloat(1, marks);
			ps.setFloat(2, min);
			
			int rows = ps.executeUpdate();
			if(rows!=0){
				System.out.println(rows+" Records Updated");
			}
			else{
				System.out.println(rows+" Records Updated");
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
