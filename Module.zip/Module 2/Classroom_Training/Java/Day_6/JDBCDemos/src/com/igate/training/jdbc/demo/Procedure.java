package com.igate.training.jdbc.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

public class Procedure {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try{
			Connection con = DBUtility.obtainConnection();
			String sql = "{call change(?,?)}";
			CallableStatement cst = con.prepareCall(sql);
			cst.setInt(1,1005);
			cst.setFloat(2,10);
			cst.registerOutParameter(1, Types.INTEGER);
			boolean res = cst.execute();
			System.out.println(res);
			
			int studId = cst.getInt(1);
			System.out.println(studId);
		}
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
		}

	}

}
