package com.igate.training.jdbc.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.omg.CORBA.portable.ValueBase;

public class InsertData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Enter Student Name:");
			String name = br.readLine();
			System.out.println("Enter Student Marks:");
			float marks = Float.parseFloat(br.readLine());
			System.out.println("Enter Student DOB: in (dd/mm/yyyy)");			
			String dob = br.readLine();
			DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate birthdate = LocalDate.parse(dob,format);
			Connection con = DBUtility.obtainConnection();
			String sql = "INSERT INTO STUDENT VALUES(STUDSEQ.nextVal,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
		
			
			//converting local date to sql date
			Date birthday = Date.valueOf(birthdate);
			
			System.out.println(birthday);
			ps.setString(1, name);
			ps.setFloat(2, marks);
			ps.setDate(3, birthday);
			int rows = ps.executeUpdate();
			if(rows!=0){
				System.out.println(rows+" Records Inserted");
			}
			else{
				System.out.println(rows+" Records Inserted");
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
