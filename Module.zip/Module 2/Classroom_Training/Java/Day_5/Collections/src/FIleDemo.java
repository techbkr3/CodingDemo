import java.io.File;
import java.io.IOException;


public class FIleDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
//		String fname = args[0];
		File f = new File("Ahaan");
		System.out.println("File Name"+f.getName());
		System.out.println("File Path"+f.getAbsolutePath());
		File dir1 = new File("Dir");
		dir1.mkdir();
		File f1 = new File(dir1,"a.pdf");
		f1.createNewFile();
		File f2 = new File(dir1,"a.html");
		f2.createNewFile();
		
		String files[] = dir1.list();
		for(String file:files)
		{
			System.out.println(file);
	}
		
	}

}
