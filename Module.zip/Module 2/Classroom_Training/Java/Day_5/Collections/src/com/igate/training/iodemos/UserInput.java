package com.igate.training.iodemos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UserInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// try with resources.. auto closable interface that close the stream
		// after use automatically
		try (InputStreamReader isr = new InputStreamReader(System.in);
				BufferedReader br = new BufferedReader(isr);) {
			System.out.println("Enter Company Name");
			String company = br.readLine();
			System.out.println("Enter Salary");
			float salary = Float.parseFloat(br.readLine());
			System.out.println(company + "\t" + salary);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

}
