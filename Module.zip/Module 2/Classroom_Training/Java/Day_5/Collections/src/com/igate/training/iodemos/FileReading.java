package com.igate.training.iodemos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class FileReading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try(FileReader fr = new FileReader("D:\\Java\\Day_5\\Collections\\src\\read.txt");
			BufferedReader br = new BufferedReader(fr);
			LineNumberReader lr = new LineNumberReader(br);)
		{
			String str;
			while((str = lr.readLine())!=null)
			{
				System.out.println(lr.getLineNumber()+"\t"+str); //reading till end of file
			}
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
