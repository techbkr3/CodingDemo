package com.igate.beans;

public class Customer implements Comparable<Customer> {
	
	private int cid;
	private String cname;
	private int cage;
	private String caddress;
	
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", cage=" + cage
				+ ", caddress=" + caddress + "]";
	}

	public Customer(int cid, String cname, int cage, String caddress) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cage = cage;
		this.caddress = caddress;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public int getCage() {
		return cage;
	}

	public void setCage(int cage) {
		this.cage = cage;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	@Override
	public int compareTo(Customer c1) {
		// TODO Auto-generated method stub
		return this.cname.compareTo(c1.cname);
	}
	
	

}
