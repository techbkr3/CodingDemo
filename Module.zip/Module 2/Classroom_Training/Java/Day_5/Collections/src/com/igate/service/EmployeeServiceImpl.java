package com.igate.service;

import java.util.HashMap;
import java.util.Scanner;

import com.igate.beans.Employee;

public class EmployeeServiceImpl {
	
	HashMap<Integer,Employee> empData = new HashMap<Integer,Employee>();
	
	public void addEmployeeDetails()
	{
		/*
		 * 1.to add the menu in phone directory
		 * 2. to search by name
		 * Scanner sc =
*/	}
	public boolean deleteEmployee()
	{
		return false;
		
	}

}
