package com.igate.training.collections;

import java.util.Comparator;

import com.igate.beans.Customer;

public class AgeSorting implements Comparator<Customer>
{


	@Override
	public int compare(Customer c1,Customer c2) {
		// TODO Auto-generated method stub
		return c2.getCage()-c1.getCage();
	}

}
