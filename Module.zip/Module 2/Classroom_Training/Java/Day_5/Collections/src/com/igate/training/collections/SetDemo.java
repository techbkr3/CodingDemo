package com.igate.training.collections;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> data1 = new ArrayList<>();
		data1.add("ABC");
		data1.add("XYZ");
		data1.add("Z");
		
		Set<Object> data = new LinkedHashSet<>(); //insertion order
		data.add(20);
		data.add("Capgemini");
		data.add(true);
		data.add(20);
		Object o = new Object();
		data.add(o.toString());
		
		boolean result = data.remove(new String());
		System.out.println(result);
		System.out.println(data);
		System.out.println(data.size());
		
		data.addAll(data1);//unique elements 
		System.out.println(data);
		System.out.println(data.size());

		TreeSet<String> data2 = new TreeSet<>(); //elements have to be mutually comparable
		data2.add("A");
		data2.add("%");
		data2.add("b");
		data2.add("Z");
		
		System.out.println(data2);
		
	}

}