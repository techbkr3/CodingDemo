package com.igate.training.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class BasicSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] arr = {"ONE","TWO","THREE","FOUR","FIVE"};
		
		//Sorting string array
		Arrays.sort(arr);
		System.out.println("Sorting way");
		for(String s:arr)
		{
			System.out.println(s);
		}
		
		
		//You cannot add an element in a list that is of array as indices having immutable characteristics 
		//If you want to sort with the list, use collections class collections.sort() binary sort
		//If you want to sort with the set, use treeset class treeset.sort() binary sort
		//If you want to sort with the array, use arrays class arrays.sort() binary sort
		//If you want to sort with the queue, use list/set class list/set.sort() binary sort
		//If you want to sort with the map, use treemap class list/set.sort() binary sort
		
		List<String> data= Arrays.asList(arr);
		
		System.out.println(data);
		
		data.set(1, "JAVA");
		
		System.out.println(data);
		
		for(String s:arr)
		{
			System.out.println(s);
		}
		
		
		System.out.println(Arrays.binarySearch(arr, "Ten"));
		
		//Sorting with List
		
		List<Integer> data1 = new ArrayList<>();
		
		data1.add(123);
		data1.add(456);
		data1.add(789);
		data1.add(123);
		Collections.sort(data);
		System.out.println(data1);
		
		Set<Integer> data2 = new TreeSet<Integer>(data1);
		System.out.println(data2);
		
		
		

	}

}
