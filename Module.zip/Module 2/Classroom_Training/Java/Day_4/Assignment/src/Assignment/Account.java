package Assignment;

public class Account {
	
	final float MIN_BAL;

}

