package exceptions;
import com.igate.service.InvalidAmountException;

class Parent{
	public void test() throws NullPointerException,InvalidAmountException
	{
	System.out.println("Parent");	
	}
}

class child extends Parent{
	public void test() throws ArithmeticException
	{
	System.out.println("Child");	
	}
}

public class InheritanceException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parent p = new child();
		try {
			p.test();
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAmountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
