package RegExp;

public class ExceptionD {

	public static void main(String[] args) throws ArithmeticException {
		// TODO Auto-generated method stub
		int x = 0;
		try{
			 x = 10/0;
			 throw new ArithmeticException("Ahaan");
		}
		catch (ArithmeticException e)
		{
			System.out.println(e.getMessage() + x);
		}
		System.out.println("Division error might occur");

	}

}
