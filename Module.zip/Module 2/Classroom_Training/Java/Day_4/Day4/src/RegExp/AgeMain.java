package RegExp;

import java.util.Scanner;

public class AgeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Age:");
		int age = scan.nextInt();
		if(age <= 0)
		{
			try {
				throw new AgeException("Age cannot be 0 or less");
			} catch (AgeException e) {
				// TODO Auto-generated catch block
					System.out.println(e.getMessage());
			}
		}
		
		scan.close();
		
	}

}
