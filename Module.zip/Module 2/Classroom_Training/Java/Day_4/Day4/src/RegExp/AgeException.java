package RegExp;

//Generating custom checked exception
public class AgeException extends Exception{
	
	public AgeException(String msg)
	{
		super(msg); //calling parent class parameterized constructor
	}
	

}
