package com.igate.service;

public class Account {
	double balance;
	String type;
	public static final float SAV_MIN_BAL=0;
	public static final float CUR_BAL=500;
	
	
	public Account(String type,double balance)
	{
		this.type=type;
		this.balance=balance;
	}
	
	public double withdraw(float amount) throws MinimumBalanceException
	{
		if("Savings".equalsIgnoreCase(type))
		{
			if((balance-amount) < SAV_MIN_BAL)
			{
				throw new MinimumBalanceException("Minimum Balance Should be maintained");
			}
		}
		else if("Current".equalsIgnoreCase(type))
		{
			if((balance-amount) < CUR_BAL)
			{
				throw new MinimumBalanceException("Minimum Balance Should be maintained");
			}
		}
		
		balance-=amount;
		return balance;
	}
	
	public double deposit(float amount) throws InvalidAmountException
	{
		if(amount <= 0)
			{
				throw new InvalidAmountException("Amount cannot be zero");
			}
		
			balance+=amount;
			return balance;

}

	public double getBalance() {
		return balance;
		
	}
}
