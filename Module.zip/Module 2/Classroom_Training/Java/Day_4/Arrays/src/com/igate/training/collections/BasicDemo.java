package com.igate.training.collections;

import java.util.ArrayList;
import java.util.Collection;

public class BasicDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Collection data = new ArrayList();
		Collection data1 = new ArrayList();
		
		data1.add(120);
		data1.add('Z');
		data.add("Anything");
		data.add(12);
		data.add('A');
		data.addAll(data1);
		System.out.println(data);
		data.remove('Z');
		System.out.println(data);
		data.clear();
		System.out.println(data);
		
		print(data);


	}

	private static void print(Collection data) {
		// TODO Auto-generated method stub
		for(Object c:data){
			System.out.println(c);
		}
		
	}

}
