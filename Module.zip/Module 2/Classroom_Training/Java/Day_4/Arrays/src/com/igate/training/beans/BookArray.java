package com.igate.training.beans;

public class BookArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	/*	int[] arr = new int[2];
		
		for(int i:arr)
		{
			System.out.println(i);
		}*/
		
		Book[] books = new Book[3];
		books[0]= new Book(12345,"Core Java",123.5f);
		books[1]= new Book(12347,"Advanced Java",12.5f);
		books[2]= new Book(12346,"Extremely Advanced Java",13.5f);

		for(Book bk:books)
		{
			System.out.println(bk);
		}
	}

}


//list is nothing but list of things to do (Repeatable) - Index based {Array list/Vector/LinkedList}
//treeset - sorted & ordered collection
//hashset unordered and unsorted
//linkedhashset - unsorted but ordered
/*
 * Set
 * Hashtable - thread safe (accessible to only one thread) - unsorted and unordered - no null values
 * Hashmap - no thread safe -unsorted and unordered - null values(both key and value)
 * Linked Hashap - same as hashmap but ordered
 * Sorted Map
 * TreeMap - sorted and ordered
 * 
 * 
 * Enumeration/Vector (legacy) thread safe - loop the collections
 * Iterator
 * 
 * for custom sorting & ordering, following classes used
 * Arrays 
 * Collections
 * */

