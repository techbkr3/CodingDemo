package com.igate.lesson6.casting;

public class Executor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Base b=new Base(); //allowed
		System.out.println(" ");
		Derived d=new Derived(); //allowed
		System.out.println(" ");
		Base b1=new Derived(); //allowed
		System.out.println(" ");
		//Derived d1=new Base(); //Not allowed
		Base b2=d; //Upcasting is allowed
		System.out.println(" ");
		//Derived d2=b1; direct Downcasting not allowed
		//Derived d3=b; direct Downcasting not allowed
		Derived d2=(Derived)b1;//allowed as reference is base and object is derived
		System.out.println(" ");
		/*
		 * Derived d3=(Derived)b;
		 * Not allowed as object b is of base class
		 * No compilation error, but will produce
		 * java.lang.ClassCastException 
		 */
		b.methodX(); //valid
		System.out.println(" ");
		//b.methodY(); invalid
		
		d.methodX(); //valid
		d.methodY(); //valid
		System.out.println(" ");
			
		
		b2.methodX(); //valid
		//b2.methodY(); invalid
		System.out.println(" ");
	
		d2.methodX(); //valid
		d2.methodY(); //valid
		System.out.println(" ");
		
	}

}
