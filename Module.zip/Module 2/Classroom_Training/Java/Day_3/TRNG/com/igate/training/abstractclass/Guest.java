package com.igate.training.abstractclass;

public class Guest implements InterfaceA {

	@Override
	public void saySomehting() {
		System.out.println("I will visit today");
	}
	
	public static void main(String[] args) {
		InterfaceA obj = new Guest();
		obj.sayHI();
		obj.sayBye();
		obj.saySomehting();
	}

}
