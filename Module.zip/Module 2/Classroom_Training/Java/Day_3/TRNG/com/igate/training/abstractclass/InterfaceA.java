package com.igate.training.abstractclass;

public interface InterfaceA {

	public void saySomehting();
	
	default public void sayHI(){
		System.out.println("Hi from interface");
	}
	
	default public void sayBye(){
		System.out.println("Bye from interface");
	}
	
}
