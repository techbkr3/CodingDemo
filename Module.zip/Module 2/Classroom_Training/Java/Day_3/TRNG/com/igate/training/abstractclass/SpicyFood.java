package com.igate.training.abstractclass;

public abstract class SpicyFood implements Food{
	
	abstract String cookFood();

}
