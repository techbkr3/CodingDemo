package com.igate.training.p1;

public class PackageDemo {
	
	public static void main(String[] args) {
		Parent p = new Parent();
		Sample s = new Sample();
		Child c = new Child();
		
	}

}
