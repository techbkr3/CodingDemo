package com.igate.training.abstractclass;

public interface Food {
	
	public static final String  GUEST="ANON";

}
