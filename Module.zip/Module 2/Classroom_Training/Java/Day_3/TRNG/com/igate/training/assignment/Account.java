package com.igate.training.assignment;

public class Account {
	
	long accNum;
	double balance;
	Person accHolder;
	static double totals;
	
	public Account(long accNum, double balance, Person accHolder) {
		super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = accHolder;
	}

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public  void deposit(long accNum2, double d,double d1){
		 totals = d+d1;
		System.out.println("Amount deposited:"+d1+" to Account No "+accNum2+" and the updated balance is "+totals);
	}
	
	private void withdraw(long accNum2, double d,double d1) {
		totals =d-d1;
		System.out.println("Amount withdrawn:"+d+" from Account No "+accNum2+" and the updated balance is "+totals);
	}
	
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}

	public Account() {
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int randomNo = (int) Math.round((Math.random() * 10000)); 
		Person s = new Person("Smith",21);
		Person k = new Person("Kathy",19);
		Account d = new Account();
		Account ac = new Account();
		Account ac1 = new Account(randomNo+1,3000,k);
		ac.setAccNum(randomNo);
		ac.setBalance(2000);		
		System.out.println("Number\t"+"Balance\t"+"Age\t"+"Name\t");
		System.out.println(ac.accNum+"\t"+ac.balance+"\t"+s.getAge()+"\t"+s.getName());
		System.out.println(ac1.accNum+"\t"+ac1.balance+"\t"+k.getAge()+"\t"+k.getName());
		d.deposit(ac.accNum,ac.balance,5000);
		d.withdraw(ac1.accNum,ac1.balance,1);
		/*
		System.out.println("Updated Balance for Smith: \t"+ac.balance);
		System.out.println("Updated Balance for Kathy: \t"+ac1.balance);
		*/
	}

	


}
