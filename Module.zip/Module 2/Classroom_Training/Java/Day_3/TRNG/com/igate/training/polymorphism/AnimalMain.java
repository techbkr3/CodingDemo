package com.igate.training.polymorphism;

public class AnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Upcasting or dynamic polymorphism
		Animal obj = new Horse("GRASS");
		obj.eat();//parent method called
		
		System.out.println(obj.eat);
		
		/*Horse h = (Horse) new Animal();
		h.eat();
		//Class cast exception (Animal cannot cast to horse)
*/
	}

}
