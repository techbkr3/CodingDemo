package com.igate.training.abstractclass;

public class AbstractMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Shape s = new Shape();
		s.draw();
		Polygon p = new Polygon();
		p.draw();
		p.show();
		s.show();
		
	}

}
