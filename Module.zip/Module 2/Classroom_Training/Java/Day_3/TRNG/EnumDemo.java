import static java.lang.Math.*;
class Demo{
enum TrafficSignal{
	GREEN,AMBER,RED
};
}
public class EnumDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Demo.TrafficSignal.AMBER);
//		EnumVariable
		Demo.TrafficSignal ts = Demo.TrafficSignal.GREEN;
		System.out.println(ts);
		char gen;
		gen=Gender.FEMALE.toString().charAt(0);
		System.out.println(gen);
		
		System.out.println(Months.AUG.getMon());
		
		Months.NOV.setMon(31);
		
		System.out.println(Months.NOV.getMon());
		
		String[] mont = {"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
		
		int nu = mont.length;
		
		for(String str:mont)
			
		{
			System.out.println(str);
		}
		
		m1(99);
		m1(99,"Ahaan","Yelo");
		m1(1.2f,3.4f,5.6f,7.8f,9.0f);
		
		System.out.println(sqrt(564));
		System.out.println(PI);
		
		System.out.println(pow(2,4));
		
	}

	static void m1(int x,String...s){
		System.out.println(x);;
		if(s.length>0)
		{
			for(String s1:s)
			{
				System.out.println(s1);
			}
		}
	}
	
	static void m1(float...f){
		if(f.length>0)
		{
			for(float f1:f)
			{
				System.out.println(f1);
			}
		}
	}

}

//enums can be public or default
//enums can't be used in methods