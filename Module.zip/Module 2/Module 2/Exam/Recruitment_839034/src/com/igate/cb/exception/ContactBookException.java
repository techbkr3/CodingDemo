package com.igate.cb.exception;

public class ContactBookException extends Exception {

	/**
	 * @author balmurug
	 * @class ContactBookException
	 * @App ContactBook
	 * @version 1.0
	 */
	private static final long serialVersionUID = 1L;

	public ContactBookException(String msg) {
		super(msg);
	}

}
