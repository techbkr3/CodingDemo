package com.igate.cb.service;

import java.util.regex.Pattern;

import com.igate.cb.dao.ContactBookDao;
import com.igate.cb.dao.ContactBookDaoImpl;
import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;


/**
 * @author balmurug
 * @class ContactBookServiceImpl
 * @App ContactBook
 * @version 1.0
 */

public class ContactBookServiceImpl implements ContactBookService {

	
	ContactBookDao dao = new ContactBookDaoImpl(); //Instance Creation of DAO Impl in DAOInterface Type

	/**
	 * @Method Name: addEnquiry
	 * @Parameters: EnquiryBean (Bean/DTO)
	 * @Output:	int EnquiryID
	 */
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {

		return dao.addEnquiry(enqry);
	}

	
	/**
	 * @Method Name: getEnquiryDetails
	 * @Parameters: int EnquiryID
	 * @Output:	EnquiryBean (Bean/DTO)
	 */
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {

		return dao.getEnquiryDetails(EnquiryID);
	}
	
	/**
	 * @Method Name: validateContactNo
	 * @Parameters: String contactNo
	 * @Output:	boolean
	 */

	@Override
	public boolean validateContactNo(String contactNo)
			throws ContactBookException {
		String contactPattern = "^^[7-9][0-9]{9}$";
		boolean validCNo = Pattern.matches(contactPattern, contactNo);
		return validCNo;
	}
	
	/**
	 * @Method Name: validateFirstName
	 * @Parameters: String fName
	 * @Output:	boolean
	 */

	@Override
	public boolean validateFirstName(String fName) throws ContactBookException {
		String fNamePattern = "^[A-Z][a-z]{3,12}$";
		boolean validFName = Pattern.matches(fNamePattern, fName);
		return validFName;
	}

	/**
	 * @Method Name: validateLastName
	 * @Parameters: String lName
	 * @Output:	boolean
	 */
	@Override
	public boolean validateLastName(String lName) throws ContactBookException {
		String lNamePattern = "^[A-Z][a-z]{3,20}$";
		boolean validLName = Pattern.matches(lNamePattern, lName);
		return validLName;
	}

	/**
	 * @Method Name: validatePLocation
	 * @Parameters: String pLocation
	 * @Output:	boolean
	 */
	@Override
	public boolean validatePLocation(String pLocation)
			throws ContactBookException {
		String locPattern = "^[A-Za-z ]{3,15}$";
		boolean validLoc = Pattern.matches(locPattern, pLocation);
		return validLoc;
	}
	
	/**
	 * @Method Name: validatePDomain
	 * @Parameters: String pDomain
	 * @Output:	boolean
	 */
	@Override
	public boolean validatePDomain(String pDomain) throws ContactBookException {
		String domainPattern = "^[A-Za-z ]{2,18}$";
		boolean validDomain = Pattern.matches(domainPattern, pDomain);
		return validDomain;
	}

}
