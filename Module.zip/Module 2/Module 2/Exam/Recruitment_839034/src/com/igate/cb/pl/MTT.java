package com.igate.cb.pl;

import java.util.HashMap;

enum enums
{
	MONDAY,TUESDAY,WEDNESDAY;
}

public class MTT {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		helloT();
		
		/*enums e = enums.MONDAY;
		
		switch(e)
		{
			case MONDAY: System.out.println("MONDAY");
			case TUESDAY: System.out.println("TUESDAY"); break;
			default: System.out.println("It's not a working day. Go home and sleep high");
		}*/
		
		
		

	}

	/*public static void helloT() {
		// TODO Auto-generated method stub
		try{
			throw new NullPointerException();			
		}
		catch(Exception e)
		{
			System.out.println("I'm in exception");
			System.exit(0);
}
		finally
		{
			System.out.println("I'm in final method");
		}
		
	}*/

}
