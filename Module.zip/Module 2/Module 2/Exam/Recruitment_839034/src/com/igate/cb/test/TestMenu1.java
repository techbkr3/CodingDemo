package com.igate.cb.test;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.igate.cb.dao.ContactBookDao;
import com.igate.cb.dao.ContactBookDaoImpl;
import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;
import com.igate.cb.util.DBUtility;

/**
 * @author balmurug
 * @test Add Enquiry Details (Menu 1)
 * @App ContactBook
 * @version 1.0
 */

public class TestMenu1 {
	
	static ContactBookDao test;
	
	int expected = 0;
	int result = 0;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		test = new ContactBookDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		test=null;
	}

	/**
	 * @author balmurug
	 * @testcase Add Enquiry Details (Menu 1)
	 * @expected int 0 if failed else unique id integer
	 * @App ContactBook
	 * @version 1.0
	 */
	@Test
	public void test() throws ContactBookException {
		
		EnquiryBean eb = new EnquiryBean("Ramji", "G", 9843819889L,
				"Los Angels", "Business Inteligence");
		result = test.addEnquiry(eb);
		assertEquals(expected,result);
	}

}
