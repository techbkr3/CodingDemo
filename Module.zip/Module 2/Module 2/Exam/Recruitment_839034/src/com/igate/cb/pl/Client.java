package com.igate.cb.pl;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;
import com.igate.cb.service.ContactBookService;
import com.igate.cb.service.ContactBookServiceImpl;


/**
 * @author balmurug
 * @class Client
 * @App ContactBook
 * @version 1.0
 */

public class Client {

	static {
		PropertyConfigurator.configure("log4j.properties");

	}

	static Logger log = Logger.getLogger(Client.class);

	
	public static void main(String[] args) {
		ContactBookService service = new ContactBookServiceImpl(); // Creating
																	// Service
																	// Instance
																	// with
																	// ServiceImpl
																	// in its
																	// Interface
																	// type
		System.out
				.println("*********************Global Recruitments*********************");
		System.out.println("Choose an operation");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquiry Details on Id");
		System.out.println("0.Exit");
		System.out
				.println("*************************************************************");
		Scanner scan = new Scanner(System.in);
		log.info("User Choice Fetched");
		int userChoice = scan.nextInt(); //User Choice
		switch (userChoice) {
		case 1: {
			long cNo = 0;
			try {
						/**
						 * User Inputs Started
						 */
						log.info("Case 1 Selected");
						System.out.println("Enter First Name:");
						System.out.println("Example: Balaji (Initial Caps)");
						String fName = scan.next();
						boolean validfName = service.validateFirstName(fName);
						while (!validfName) {
							System.out.println("Enter First Name:");
							System.out.println("Example: Balaji (Initial Caps)");
							fName = scan.next();
							validfName = service.validateFirstName(fName);
							log.warn("Invalid First Name");
						}
						log.info("Valid First Name");
								System.out.println("Enter Last Name:");
								System.out.println("Example: Balaji (Initial Caps)");
								String lName = scan.next();
								boolean validlName = service.validateLastName(lName);
								while (!validlName) {
									System.out.println("Enter Last Name:");
									System.out.println("Example: Balaji (Initial Caps)");
									lName = scan.next();
									validlName = service.validateFirstName(lName);
									log.warn("Invalid First Name");
								}
						log.info("Valid Last Name");
								System.out.println("Enter Contact Number:");
								System.out.println("Example: 9042235465 (10 Digit Valid Indian Number)");
								String contactNo = scan.next();
								boolean validcNo = service.validateContactNo(contactNo);
								if (validcNo) {
									cNo = Long.parseLong(contactNo);
								}
							while (!validcNo) {
								System.out.println("Enter Contact Number:");
								System.out.println("Example: 9042235465 (10 Digit Valid Indian Number)");
								contactNo = scan.next();
								validcNo = service.validateContactNo(contactNo);
								if (validcNo) {
									cNo = Long.parseLong(contactNo);
									log.warn("Invalid Contact Number");
								}
							}
						log.info("Valid Contact Number");
								System.out.println("Enter Preferred Location:");
								System.out.println("Example: Bangalore (Initial Caps)");
								String prefLoc = scan.next();
								boolean validPrefLoc = service.validatePLocation(prefLoc);
								while (!validPrefLoc) {
									System.out.println("Enter Preferred Location:");
									System.out.println("Example: Bangalore (Initial Caps)");
									prefLoc = scan.next();
									validPrefLoc = service.validatePLocation(prefLoc);
									log.warn("Invalid Preferred Location");
								}
						log.info("Valid Preferred Location");
								System.out.println("Enter Preferred Domain:");
								System.out.println("Example: Java (Initial Caps)");
								String prefDomain = scan.next();
								boolean validPrefDom = service.validatePDomain(prefDomain);
								while (!validPrefDom) {
									System.out.println("Enter Preferred Domain:");
									System.out.println("Example: Java (Initial Caps)");
									prefDomain = scan.next();
									validPrefDom = service.validatePDomain(prefDomain);
									log.warn("Invalid Preferred Domain");
								}
						log.info("Valid Preferred Domain");
						/**
						 * User Inputs Completed
						 */
				if (!validfName || !validlName || !validcNo || !validPrefLoc
						|| !validPrefDom || fName.isEmpty() || lName.isEmpty()
						|| contactNo.isEmpty() || prefLoc.isEmpty()
						|| prefDomain.isEmpty()) {
					System.out
							.println("Invalid User Input/User Input Cannot be empty");
				} else {
					EnquiryBean eb = new EnquiryBean(fName, lName, cNo,
							prefLoc, prefDomain);
					log.info("Calling Method");
						int result = service.addEnquiry(eb);
					log.info("Method Return Successful");
						if (result != 0) {
							log.info("Output Successful");
							System.out.println("Thank you " + fName
									+ " your Unique Id is " + result
									+ " we will contact you shortly");
							} else {
								log.error("Internal Error");
								System.out
										.println("Sorry, We could not make the entry right now. Try again");
							}
				}

			} catch (ContactBookException | InputMismatchException e) {
				// TODO Auto-generated catch block
				log.error("Internal Error");
				System.err.println("Incorrect Inputs " + e.getMessage());
			}
			break;
		}
		case 2: {
			log.info("Case 2 Selected");
			try {
				System.out.println("Enter the Enquiry Number/Unique ID");
				int uniqueId = scan.nextInt();
				log.info("User's Unique ID " + uniqueId);
				EnquiryBean eb = service.getEnquiryDetails(uniqueId);
						System.out.println("ID: " + eb.getEnqryId());
						System.out.println("First Name: " + eb.getfName());
						System.out.println("Last Name: " + eb.getlName());
						System.out.println("Contact No: " + eb.getContactNo());
						System.out.println("Preferred Domain: " + eb.getpDomain());
						System.out.println("Preferred Location: " + eb.getpLocation());
				log.info("Output Successful for " + uniqueId);
			} catch (ContactBookException | InputMismatchException e) {
				log.error("Fetching Details error Menu 2");
				System.out.println("Incorrect Inputs on Option 2 "
						+ e.getMessage());

			}
			break;
		}
		case 0: {
			log.info("Case 3 Selected");
			log.info("Exiting Application");
			System.out.println("Thank you for selecting us!!");
			System.exit(0);
		}
		default: {
			System.out.println("Invalid Operation");
		}
		}
		scan.close(); //Scanner Resource Closing
	}

}
