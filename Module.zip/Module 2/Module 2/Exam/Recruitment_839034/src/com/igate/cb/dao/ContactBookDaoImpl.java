package com.igate.cb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;
import com.igate.cb.pl.Client;
import com.igate.cb.util.DBUtility;


public class ContactBookDaoImpl implements ContactBookDao {
	static Logger log = Logger.getLogger(ContactBookDaoImpl.class);
	static {
		PropertyConfigurator.configure("log4j.properties");
	}
	
	/**
	 * @author balmurug
	 * @Method Name: addEnquiry
	 * @Parameters: EnquiryBean (Bean/DTO)
	 * @Output:	int EnquiryID
	 * @App ContactBook
	 * @version 1.0
	 */
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		String seqQ = "SELECT enquirySeq.nextval from dual";
		String insQ = "INSERT INTO enquiry values(?,?,?,?,?,?)";
		Connection con = null;
		Statement st = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int enqId;

		try {
			log.info("Obtaining Connection");
			con = DBUtility.obtainConnection();
			con.setAutoCommit(false);
			log.info("Generating Unique ID");
			st = con.createStatement();
			rs = st.executeQuery(seqQ);
			rs.next();
			enqId = rs.getInt(1);
			log.info("Generating Unique ID");
			pst = con.prepareStatement(insQ);
			pst.setInt(1, enqId);
			pst.setString(2, enqry.getfName());
			pst.setString(3, enqry.getlName());
			pst.setLong(4, enqry.getContactNo());
			pst.setString(5, enqry.getpLocation());
			pst.setString(6, enqry.getpDomain());
			log.info("Attempting to insert data");
			int rows = pst.executeUpdate();

			if (rows != 0) {
				log.info("Data Insertion Successful");
				return enqId;
			}
			else
			{
				log.info("Data Insertion Failed");
			}

		}

		catch (SQLException e) {
			log.error("Error in Insertion Module");
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
			System.out.println(e1.getMessage()+" Error while closing connection");		
			}
			throw new ContactBookException("Sorry,Unable to entry the record "
					+ e.getMessage());	
		}

		finally {
			try {
				log.info("Releasing DB Connectivity");
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new ContactBookException("Closing connection error");
			}
		}

		return 0;
	}
	
	
	/**
	 * @author balmurug
	 * @method: getEnquiryDetails
	 * @param: int EnquiryID
	 * @return:	EnquiryBean (Bean/DTO)
	 */
	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException {

		String selQ = "SELECT * from enquiry where enqryid = ?";
		Connection con = null;
		PreparedStatement pst = null;
		ResultSet output = null;
		EnquiryBean eb = null;
		try {
			
			con = DBUtility.obtainConnection();
			con.setAutoCommit(false);
			pst = con.prepareStatement(selQ);
			pst.setInt(1, EnquiryID);
			log.info("Attempting to fire the query");
			output = pst.executeQuery();
			output.next();
			log.info("Query running successful");
			eb = new EnquiryBean(output.getInt(1), output.getString(2),
					output.getString(3), output.getLong(4),
					output.getString(5), output.getString(6));

		} catch (SQLException e) {
			log.error("Query firing Failed");
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
			System.out.println(e1.getMessage()+" Error while closing connection");		
			}
			System.out.println("Details Fetching Error Occured "
					+ e.getMessage());
		}

		finally {
			try {
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				throw new ContactBookException("Closing connection error");
			}
		}

		return eb;
	}

}
