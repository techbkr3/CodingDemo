package com.igate.cb.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.igate.cb.dao.ContactBookDao;
import com.igate.cb.dao.ContactBookDaoImpl;
import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;

/**
 * @author balmurug
 * @test View Enquiry Details on ID (Menu 2)
 * @App ContactBook
 * @version 1.0
 */

public class Menu2Test {

	static ContactBookDao test;
	
	//Setting Invalid Inputs that user entered in database
	EnquiryBean expected = new EnquiryBean(1001,"Balaji","Murugesaraja",9042235465L,"Bangalore","Java");
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		test = new ContactBookDaoImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		test=null;
	}

	/**
	 * @author balmurug
	 * @testcase View Enquiry Details on ID (Menu 2)
	 * @expected Object of EnquiryBean
	 * @App ContactBook
	 * @version 1.0
	 */
	@Test
	public void test() throws ContactBookException {
		EnquiryBean actuals = test.getEnquiryDetails(1001); //Calling method to fetch the details
		assertEquals(expected,actuals);
	}

}
