package com.igate.cb.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



/**
 * @author balmurug
 * @Class: DBUtility
 * @Function: Database Connection
 */
public class DBUtility {

	static String driverName;
	static String url;
	static String userName;
	static String password;
	static Connection connection;

	static {
		Properties prop = new Properties();
		try {
			FileInputStream fis = new FileInputStream("jdbc.properties");
			prop.load(fis);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		driverName = prop.getProperty("db.drivername");
		url = prop.getProperty("db.url");
		userName = prop.getProperty("db.username");
		password = prop.getProperty("db.password");
	}

	public static Connection obtainConnection() throws SQLException {
		connection = DriverManager.getConnection(url, userName, password);
		return connection;
	}

	public static void releaseConnection() throws SQLException {
		if (connection != null)
			connection.close();
	}

}