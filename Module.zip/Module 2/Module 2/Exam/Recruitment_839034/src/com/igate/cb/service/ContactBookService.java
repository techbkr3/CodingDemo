package com.igate.cb.service;

import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;

/**
 * @author balmurug
 * @interface ContactBookService
 * @App ContactBook
 * @version 1.0
 */

public interface ContactBookService {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;

	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException;

	boolean validateContactNo(String contactNo) throws ContactBookException;

	public boolean validateFirstName(String fName) throws ContactBookException;

	public boolean validateLastName(String lName) throws ContactBookException;

	public boolean validatePLocation(String pLocation)
			throws ContactBookException;

	public boolean validatePDomain(String pDomain) throws ContactBookException;

}
