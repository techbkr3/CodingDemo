package com.igate.cb.dao;

import com.igate.cb.dto.EnquiryBean;
import com.igate.cb.exception.ContactBookException;



/**
 * @author balmurug
 * @interface ContactBookDao
 * @App ContactBook
 * @version 1.0
 */
public interface ContactBookDao {

	public int addEnquiry(EnquiryBean enqry) throws ContactBookException;

	public EnquiryBean getEnquiryDetails(int EnquiryID)
			throws ContactBookException;

}
