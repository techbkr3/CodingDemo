CREATE OR REPLACE PROCEDURE UPDATENAME
(
V_SCODE NUMBER
)
IS
V_SNAME STAFF_MASTERS.STAFF_NAME%TYPE;
CURSOR UENAME IS SELECT UPPER(STAFF_NAME) FROM STAFF_MASTERS WHERE STAFF_NAME = V_SCODE;
NONAME_EXCEPTION EXCEPTION;
BEGIN
OPEN UENAME;
  IF UENAME%ISOPEN THEN
      IF UENAME%FOUND THEN
          FETCH UENAME INTO V_SNAME;
        IF V_SNAME IS NULL THEN
          RAISE NONAME_EXCEPTION;
        ELSE
          UPDATE STAFF_MASTERS SET STAFF_NAME = UPPER(V_SNAME) WHERE STAFF_CODE = V_SCODE;
          COMMIT;
        END IF;
        END IF;
        CLOSE UENAME;
  END IF;
  EXCEPTION
  WHEN NONAME_EXCEPTION THEN
  DBMS_OUTPUT.PUT_LINE('NO STAFF NAME VALUE PROVIDED!');
END UPDATENAME;
SELECT STAFF_CODE,STAFF_NAME FROM STAFF_MASTERS;
SHOW ERRORS;
--Write a procedure that accept staff code and update staff name to Upper case. If the staff
--name is null raise a user defined exception.

Create or REPLACE PROCEDURE update_name(v_staff_code staff_masters.staff_code%TYPE) 
IS
	
	CURSOR c_staff IS SELECT * from staff_masters where staff_code=v_staff_code;
	NAME_NULL EXCEPTION; 
	staff_rec staff_masters%ROWTYPE;

BEGIN
	
	OPEN c_staff;
	IF c_staff%ISOPEN THEN
		IF c_staff%FOUND THEN
			FETCH c_staff INTO staff_rec;
				
			IF staff_rec.staff_name IS NOT NULL THEN
				
				update staff_masters set staff_name = UPPER(staff_rec.staff_name) where staff_code = staff_rec.staff_code ;
			END IF;
		ELSE
			RAISE NAME_NULL;
		END IF;
	END IF;
EXCEPTION
	WHEN NAME_NULL THEN 
		DBMS_OUTPUT.PUT_LINE('staff name is null.');
END;

