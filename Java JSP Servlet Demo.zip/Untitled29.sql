--create table mobilesj(mobileid number primary key,name varchar2(20),price number(10,2),quantity varchar2(20));
--insert into mobilesj values(1001,'nokia lumia 520',8000,20);
--insert into mobilesj values(1002,'nokia lumia 620',8000,20);
--insert into mobilesj values(1004,'nokia lumia 1020',1000,20);
--create sequence purseq start with 5000;
--create table purchases(purchaseid number,cname varchar(20),mailid varchar(30),phoneno varchar(20),purchasedate date,mobileid references mobilesj(mobileid));
--commit;

--select * from mobilesj;
alter table purchases disable reference mobileid;