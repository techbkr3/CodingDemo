package com.igate.orders.testcase;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.igate.orders.dao.IOrderProduct;
import com.igate.orders.dao.OrderProductImpl;
import com.igate.orders.dto.Customer;
import com.igate.orders.dto.Product;
import com.igate.orders.exception.InvalidCategoryException;

public class TestOrderProductImpl {
	
	static IOrderProduct testDao; 

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		testDao = new OrderProductImpl(); //dao class object
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		testDao = null;
	}

	@Test
	public void testGetProductDetails() {
		try {
			ArrayList<Product> details = testDao.getProductDetails("food");
			if(!details.isEmpty())
			{
			assertTrue(true);
			}
			else
			{
			assertTrue(false);
			}
		} catch (InvalidCategoryException e) {
			// TODO Auto-generated catch block
			fail("Error "+e.getMessage());
		}
		
	}
	
	
	public void testOrderProduct() throws IOException
	{
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter Product Name:");
			String pname = br.readLine();
			System.out.println("Enter Quantity:");
			int qty = Integer.parseInt(br.readLine());
			System.out.println("Enter cust name:");
			String custName = br.readLine();
			System.out.println("Enter cust add:");
			String custAdd = br.readLine();
			System.out.println("Enter Phone");
			Long cPhone = Long.parseLong(br.readLine());
			Customer obj = new Customer();
			obj.setcAdd(custAdd);
			obj.setcName(custName);
			obj.setcPhone(cPhone);
			assertEquals(2006,testDao.orderProduct(obj, qty, pname));
		} catch (InvalidCategoryException e) {
			// TODO Auto-generated catch block
			fail("Error "+ e.getMessage());
		}
	}

}
