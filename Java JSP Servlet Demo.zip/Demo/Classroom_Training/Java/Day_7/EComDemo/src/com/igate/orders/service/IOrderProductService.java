package com.igate.orders.service;

import java.util.ArrayList;

import com.igate.orders.dto.Customer;
import com.igate.orders.dto.Product;
import com.igate.orders.exception.InvalidCategoryException;

public interface IOrderProductService {
	
		public ArrayList<Product> getProductDetails(String category) throws InvalidCategoryException;
		public int orderProduct(Customer obj,int qty,String pname) throws InvalidCategoryException;

}