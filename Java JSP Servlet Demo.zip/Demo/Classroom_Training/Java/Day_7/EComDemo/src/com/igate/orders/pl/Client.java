package com.igate.orders.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import com.igate.orders.dto.Customer;
import com.igate.orders.dto.Product;
import com.igate.orders.exception.InvalidCategoryException;
import com.igate.orders.service.IOrderProductService;
import com.igate.orders.service.OrderProductServiceImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int choice;
		System.out.println("Menu");
		System.out.println("1.Fetch product details");
		System.out.println("2.Order Product");
		System.out.println("3.Exit");
		IOrderProductService service = new OrderProductServiceImpl(); 
		try
		(BufferedReader br = new BufferedReader(new InputStreamReader(System.in));			
		)
		{
			System.out.println("Enter choice");
			choice = Integer.parseInt(br.readLine());
			switch(choice)
			{
			case 1:
				try{
					System.out.println("Enter the category choice");
					String cat = br.readLine();
					ArrayList<Product> details = service.getProductDetails(cat);
					if(!details.isEmpty())
					{
						Iterator<Product> it = details.iterator();
						while(it.hasNext())
						{
							System.out.println(it.next());
						}

					}
					else
					{
						throw new InvalidCategoryException(" Category does not exist");
					}
				}
				catch(InvalidCategoryException e)
				{
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter product name to purchase");
				String pname = br.readLine();
				System.out.println("Enter Qty");
				int qty = Integer.parseInt(br.readLine());
				System.out.println("Enter your name");
				String cName = br.readLine();
				System.out.println("Enter Address");
				String cAdd = br.readLine();
				System.out.println("Enter Phone");
/*				String vPhone = br.readLine();
				String pattern ="^[7-9][0-9]{9}$";
				boolean ptest = Pattern.matches(pattern, cPhone);
				
*/
				Long cPhone = Long.parseLong(br.readLine());
				Customer obj = new Customer();
				obj.setcAdd(cAdd);
				obj.setcName(cName);
				obj.setcPhone(cPhone);

				int order;
				try 
				{					
					order = service.orderProduct(obj, qty, pname);
					if(order==0)
					{
						System.out.println("Order not placed");
					}
					else
					{
						System.out.println(order + " Order placed successfully");
					}
				} 
				catch (InvalidCategoryException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
					
				break;
			case 3:
				System.exit(0);
			}
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}

	}

}
