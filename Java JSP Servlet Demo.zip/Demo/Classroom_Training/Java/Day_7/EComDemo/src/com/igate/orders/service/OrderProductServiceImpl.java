package com.igate.orders.service;

import java.util.ArrayList;

import com.igate.orders.dao.IOrderProduct;
import com.igate.orders.dao.OrderProductImpl;
import com.igate.orders.dto.Customer;
import com.igate.orders.dto.Product;
import com.igate.orders.exception.InvalidCategoryException;

public class OrderProductServiceImpl implements IOrderProductService {
	
	IOrderProduct dao = new OrderProductImpl();

	@Override
	public ArrayList<Product> getProductDetails(String category)
			throws InvalidCategoryException {
		// TODO Auto-generated method stub
		return dao.getProductDetails(category);
	}

	@Override
	public int orderProduct(Customer obj, int qty, String pname) throws InvalidCategoryException {
		// TODO Auto-generated method stub
		return dao.orderProduct(obj, qty, pname);
	}

}
