import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;


public class FileCopying {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileReader fr = new FileReader("D:\\Java\\Day_5\\Collections\\src\\read.txt");
				FileWriter fw = new FileWriter("newwrite.txt",true);
				PrintWriter pw = new PrintWriter(fw);
				BufferedReader br = new BufferedReader(fr);
			)
			{
				String str;
				while((str = br.readLine())!=null)
				{
					pw.println(str); //reading till end of file
				}
			}
			catch(IOException e)
			{
				System.out.println(e.getMessage());
			}
		

	}

}
