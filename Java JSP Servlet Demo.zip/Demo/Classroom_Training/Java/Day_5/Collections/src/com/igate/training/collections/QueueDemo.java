package com.igate.training.collections;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Linkedlist - FIFO, PriorityQueue - Random ordering
		Queue<Float> data = new PriorityQueue<>();
		data.offer(122.34f); //add
		data.offer(3.14f);
		data.offer(13.14f);
		data.offer(23.14f);
		data.offer(33.14f);
		
		System.out.println(data);
		data.poll();//remove the topmost element
		System.out.println(data);

		System.out.println("Current topmost element"+data.peek()); //displays the topmost element
		
		if(!data.isEmpty())
		{
			Iterator<Float> it = data.iterator();
			while(it.hasNext())
			{
				System.out.println(it.next());
			}
		}

	}

}
