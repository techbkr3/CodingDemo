package com.igate.training.collections;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList<Integer> nums = new LinkedList<Integer>();
		
		nums.add(12);
		nums.add(13);
		nums.add(15);
		nums.add(14);
		nums.addFirst(40);
		nums.addLast(20);
		nums.addFirst(30);
		
		System.out.println("Checking contents"+nums.contains(18));
		nums.remove();
		Iterator<Integer> it = nums.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}

	}

}
