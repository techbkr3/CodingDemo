package com.igate.training.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.igate.beans.Customer;

public class CustomSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Customer> names = new ArrayList<Customer>();
		names.add(new Customer(101,"Kathy",4,"San Diego"));
		names.add(new Customer(102,"Arnold",44,"San Jose"));
		names.add(new Customer(103,"Jackie Chan",34,"San Francisco"));
		names.add(new Customer(104,"Karol",54,"Houston"));
		names.add(new Customer(105,"Max Karol",54,"California"));
		
		Collections.sort(names);
		System.out.println(names);
		
		AgeSorting ag = new AgeSorting();
		Collections.sort(names,ag);
		System.out.println(names);
		
	
	}

}
