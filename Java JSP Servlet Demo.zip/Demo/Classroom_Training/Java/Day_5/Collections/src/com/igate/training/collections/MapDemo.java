package com.igate.training.collections;

import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Treemap sorts based on the key
		
		Map<String,Integer>mp=new TreeMap<>();
		mp.put("A", new Integer(5));
		mp.put("B", new Integer(10));
		mp.put("C", null); //Cannot add null values in Hashtable (threadsafe)
		mp.put("A", new Integer(1));
		mp.put("A", new Integer(1));
		mp.put("A", new Integer(1));

		System.out.println(mp);
		
		System.out.println(mp.containsKey("A"));
		System.out.println(mp.containsValue("A"));
		System.out.println(mp.size());
		System.out.println(mp.get("B").getClass());
//		System.out.println(mp.get("C").getClass());
		
		mp.putAll(mp);
		
		System.out.println(mp);
		
		Set<String> keys = mp.keySet();
		System.out.println(keys);
		
		Collection<Integer> values = mp.values();
		System.out.println(values);
		
		Set<Entry<String,Integer>> both = mp.entrySet();
		Iterator<Entry<String,Integer>> it = both.iterator();
		while(it.hasNext())
		{
			Entry<String,Integer> data = it.next();
			System.out.println(data.getKey()+" "+data.getValue());
		}
		
	}

}
