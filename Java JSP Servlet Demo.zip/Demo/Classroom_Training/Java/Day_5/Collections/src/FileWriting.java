import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;


public class FileWriting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileWriter fw = new FileWriter("write.txt",true);
			PrintWriter pw = new PrintWriter(fw);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			String str;
			while(!(str=br.readLine()).equalsIgnoreCase("Stop")){
				pw.println(str);
			}
		}
		catch(IOException e)
		{
			System.out.println(e.getMessage());
		}

	}

}
