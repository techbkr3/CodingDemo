import java.util.Scanner;
public class ScannerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		String name = sc.nextLine();
		System.out.println("Enter age:");
		int ip = sc.nextInt();
		System.out.println("Enter weight");
		float fp = sc.nextFloat();
		System.out.println("Enter Percentage");
		double dp = sc.nextDouble();
		System.out.println("Enter Aadhar Card Availability With You  (True/False");
		boolean av = sc.nextBoolean();

		
		
		System.out.println(ip+"\n"+fp+"\n"+dp+"\n"+av+"\n"+name);
		sc.close();*/
		
		Scanner sc = new Scanner("1,2,3,4,5,6,7,8,9").useDelimiter(",");
		while(sc.hasNextInt())
		{
			int i= sc.nextInt();
			if (i%2 == 0)
					System.out.println("Even Number"+i);
			else
				System.out.println("Odd Number"+i);
		}
	}

}
