
public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String objects are immutable
		String str = "Java";
		String str1 = "Java";
//		str = str.concat("JEE");
		System.out.println(str);
		
		
		System.out.println(str.equals(str1));
		System.out.println(str==str1);
		System.out.println(str.hashCode() + "\t" +str1.hashCode());
		
		String s2 = "Converts the character (Unicode code point) argument to lowercase using case mapping information from the UnicodeData file.";
		System.out.println("Length"+s2.length());
		char[] charas = s2.toCharArray();
		for(int i=0; i<charas.length;i++)
		{
			System.out.print(charas[i] + "     ");
		}
		
		System.out.println("\nUpperCase \t"+s2.toUpperCase());
		
		System.out.println("Char at certain position: "+s2.charAt(0));
		
		System.out.println("Index of "+s2.indexOf("the",10));
		
		System.out.println(s2.substring(0,8));
		
		String[] ahaan =s2.split("_");
		
		for(int i=0;i<ahaan.length;i++)
		System.out.println(ahaan[i]);
		String chk = String.join(",");
		System.out.println(chk);
		System.out.println("ASCII: "+s2.codePointAt(0));
		
		

	}

}
