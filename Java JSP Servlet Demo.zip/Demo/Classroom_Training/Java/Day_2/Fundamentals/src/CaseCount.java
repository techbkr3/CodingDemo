
public class CaseCount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String input ="iGaTe GlObAL SoLuTiOnS"; //11 uppercase
		
//		boolean test = Character.isUpperCase( input.charAt(2));
		int count = 0;
		for (int i=0;i<input.length();i++)
		{
			 if(Character.isUpperCase(input.charAt(i)))
			 {
				 count++;
			 }
		}
		
		System.out.println(count);

	}

}