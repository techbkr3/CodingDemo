
public class Overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		m1((byte)(4),(byte)(9));

	}
	
	static void m1(int x,int y)
	{
		System.out.println("Integer");
	}
	static void m1(byte b1,byte b2)
	{
		System.out.println("Byte");
	}
	static void m1(String s1,String s2)
	{
		System.out.println("String");
	}

	
	
}
