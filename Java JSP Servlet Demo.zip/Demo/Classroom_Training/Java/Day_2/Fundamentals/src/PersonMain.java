import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Phone Number:");
		long phone = s.nextLong();
		PersonClass p = new PersonClass("Divya","Bharti",'F',20,85.55,phone);
		
		System.out.println("First Name:\t"+p.getFirstName());
		System.out.println("Last Name:\t"+p.getLastName());
		System.out.println("Gender:\t"+p.getGender());
		System.out.println("Age:\t"+p.getAge());
		System.out.println("Weight\t"+p.getWeight());
		System.out.println("Phone:\t"+p.getPhone());

	} 

}
