class Employee {
	int eNo;
	String eName;
	float eSalary;

	public Employee(int eNo, String eName, float eSalary) {
		super();
		this.eNo = eNo;
		this.eName = eName;
		this.eSalary = eSalary;
	}

	@Override
	public String toString() {
		return "Employee [eNo=" + eNo + ", eName=" + eName + ", eSalary="
				+ eSalary + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eName == null) ? 0 : eName.hashCode());
		result = prime * result + eNo;
		result = prime * result + Float.floatToIntBits(eSalary);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (eName == null) {
			if (other.eName != null)
				return false;
		} else if (!eName.equals(other.eName))
			return false;
		if (eNo != other.eNo)
			return false;
		if (Float.floatToIntBits(eSalary) != Float
				.floatToIntBits(other.eSalary))
			return false;
		return true;
	}

}

public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1 = new Employee(1, "Balji", 299);
		Employee e2 = new Employee(1, "Ahaan", 299);
		Employee e3 = e1;

		System.out.println(e1.hashCode());
		System.out.println(e2.hashCode());
		System.out.println(e3.hashCode());

		System.out.println(e1.equals(e2));
		System.out.println(e1);
	}

}
