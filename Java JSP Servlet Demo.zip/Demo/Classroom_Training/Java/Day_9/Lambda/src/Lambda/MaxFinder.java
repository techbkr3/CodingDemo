package Lambda;

@FunctionalInterface
public interface MaxFinder {
	
	public int max(int n1,int n2);

}
