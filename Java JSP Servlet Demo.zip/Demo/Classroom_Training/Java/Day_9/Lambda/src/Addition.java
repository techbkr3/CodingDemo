
public class Addition {

	public int add(int first, int second) {
		// TODO Auto-generated method stub
		return first+second;
	}
	
	

}
