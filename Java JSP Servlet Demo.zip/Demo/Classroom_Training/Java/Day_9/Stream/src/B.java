class A
{
private void print()
{
	System.out.println("A Method");
}
public void test()
{
	this.print();
}
}
public class B extends A{
	private void print()
	{
		System.out.println("B Method");
	}
	
	public static void main(String args[])
	{
		A a= new B();
		a.test();
		
		String str = new String("PACE");
		String str1= str;
		str=null;
		System.out.println(str1.length());
	}
	
	
	

}
