import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;


public class StringBasicDemo {
	
	
	
	@Override
	public String toString() {
		return "Hello World";
	}

	public static void main(String[] args) {
		
		Stream<String> st = Stream.of("I","am","the","basic","stream");
		st.forEach(System.out::println);
		String[] srr = {"Streams","with","array"};
		List<String> data = Arrays.asList(srr);
		data.stream().forEach(System.out::println);
		
		List<String> names = new ArrayList<>();
		names.add("Tina");
		names.add("Arvind");
		names.add("Adira");  
		names.add("Carol");  
		names.add("Adidev");
		names.add("Mahadev");
		System.out.println("Stream Operation with Collections {Starting with A}");
		names.stream().filter(name->name.startsWith("A")).forEach(System.out::println);
		
		System.out.println("Length of names in the collection");
		names.stream().filter(name->name.startsWith("A")).map(name->name.length()).forEach(System.out::println);
		
		//limit size of collection
		
		System.out.println("Limiting size of collection");
		names.stream().limit(3).forEach(System.out::println);
		
	}

}