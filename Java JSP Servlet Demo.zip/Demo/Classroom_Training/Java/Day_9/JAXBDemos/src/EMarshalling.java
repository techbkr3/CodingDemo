import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;


public class EMarshalling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj = new Employee();
		obj.setEmpId(120);
		obj.setEmpName("Karthick");
		obj.setJoinDate("15/04/2014");
		obj.setLevel(8);
		obj.setRole("Manager");
		
		try
		{
			JAXBContext con = JAXBContext.newInstance(Employee.class);
			FileWriter fw = new FileWriter(new File("emp.xml"));
			Marshaller m = con.createMarshaller();
			m.marshal(obj, fw);
			System.out.println("Marshalling Successful");
		}
		catch(JAXBException | IOException e)
		{
			System.err.println(e.getMessage());
		}
		{
			
		}

	}

}
