import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.igate.training.beans.Book;


public class ListDemo {

	public static void main(String[] args) {
		// for primitive declartions, use Wrapper Classes
		//Generic type definition (i.e anything)
		List<String> data = new ArrayList<String>();

		data.add(0,"JAVA");
		data.add("Hibernate");
		data.add("Spring");
		data.add("Struts");
		System.out.println(data.size());
		
		data.set(2, "Capgemini");
		String st = data.get(0);
		String st1 = data.get(2);
		System.out.println(st);
		System.out.println(st1);
		
		
		for(String str : data)
		{
			System.out.println(str);
		}
		
		List<Book> books = new ArrayList<Book>();
		books.add(new Book(12345,"Core Java",123.5f));
		books.add(new Book(2347,"Advanced Java",12.5f));
		books.add(new Book(46,"Extremely Advanced Java",13.5f));
		
//		String str = books[0][1];
		
		System.out.println(books.get(2));
		
		System.out.println(books.size());
		
		Iterator<Book> it = books.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
	}

}
