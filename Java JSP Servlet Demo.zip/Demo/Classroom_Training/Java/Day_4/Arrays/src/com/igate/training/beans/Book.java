package com.igate.training.beans;

//Bean POJO
public class Book {
	
	private long isbn;
	private String bname;
	private float bprive;
	
	
	public Book(long isbn, String bname, float bprive) {
		super();
		this.isbn = isbn;
		this.bname = bname;
		this.bprive = bprive;
	}
	public long getIsbn() {
		return isbn;
	}
	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}
	public String getBname() {
		return bname;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", bname=" + bname + ", bprive=" + bprive
				+ "]";
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public float getBprive() {
		return bprive;
	}
	public void setBprive(float bprive) {
		this.bprive = bprive;
	}

}
