package com.igate.service;

import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Account Type: ");
	String type = scan.next();
	System.out.println("Account Balance: ");
	int bal = scan.nextInt();
		if("Current".equalsIgnoreCase(type))
		{
			if(bal<=500){
				try{
					throw new InvalidAmountException("Current balance should greater than 500");
				}
				catch(InvalidAmountException e)
				{
					System.out.println(e.getMessage());
				}
			}
		}
		Account ac = new Account(type,bal);
		System.out.println("Enter amount to deposit");
		float amount = scan.nextFloat();
		try{
			ac.deposit(amount);
			System.out.println(ac.getBalance());
		}
		catch(InvalidAmountException e)
		{
			System.out.println(e.getMessage());
		}
		
		
		System.out.println("Enter amount to withdraw");
		float wamount = scan.nextFloat();
		try{
			ac.withdraw(wamount);
			System.out.println(ac.getBalance());
		}
		catch(MinimumBalanceException e)
		{
			System.out.println(e.getMessage());
		}
		

	}

}

//If a parent class method throws a checked exception, child can throw the same or subclass of the parent class exception
//Child cannot throw more broader exception