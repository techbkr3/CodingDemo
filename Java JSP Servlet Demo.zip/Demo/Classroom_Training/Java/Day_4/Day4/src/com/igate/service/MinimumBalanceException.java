package com.igate.service;

public class MinimumBalanceException extends Exception {

	public MinimumBalanceException (String msg){
		super(msg);
	}
	
}
