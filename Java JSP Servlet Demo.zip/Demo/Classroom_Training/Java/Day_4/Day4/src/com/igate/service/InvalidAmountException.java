package com.igate.service;

public class InvalidAmountException extends Exception {

	public InvalidAmountException (String msg){
		super(msg);
	}
	
}
