package RegExp;

class Raiser{
	void raise()
	{
		String s = "null";
		int x=0;
		try{
			System.out.println("Length of String \t" + s.length());
			x= Integer.parseInt("two");
		}
		catch (NullPointerException e)
		{
			System.out.println("Message raised is "+e.getMessage());
		}
		catch (NumberFormatException e)
		{
			System.out.println("Number format exception");
		}
		catch (Exception e)
		{
			System.out.println("Message raised is "+e.getMessage());
		}
	}
}

public class ExceptionDemo2 {

	public static void main(String[] args) throws ArithmeticException {

		new Raiser().raise();

	}

}
