package RegExp;

public class FinallyDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		test();

	}

	static String test() {
		// TODO Auto-generated method stub
		int[] arr = new int[2];
		
		try{
			arr[2] = 100;
//			return "Hello World";
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Index out of bounds\t"+e.getMessage());
		}
		finally
		{
			System.out.println("I always execute");
			try
			{
				int x=10/0;
				
			}
			
			catch(ArithmeticException e){
				System.out.println(e.getLocalizedMessage());
			}
			finally{
				System.out.println("Nest finally");
			}
		}
		return null;
		
	}

}