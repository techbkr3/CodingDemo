package RegExp;

import java.util.regex.Pattern;

public class MobileNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String phonePattern = "^[7-9][0-9]{9}$";
		
		String fName = "^[A-Z][a-z]{5,15}$";
		
		String phone = "3042235465";
		
		boolean p = Pattern.matches(phonePattern, phone);
		int counts =0;
		while(p)
		{
			System.out.println("Re enter phone num "+counts);
		counts++;
		}

	}

}
