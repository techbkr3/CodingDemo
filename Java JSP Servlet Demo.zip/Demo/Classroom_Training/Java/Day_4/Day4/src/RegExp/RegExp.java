package RegExp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pattern p = Pattern.compile("a*b"); //RegExp Object is compiled
		Matcher m = p.matcher("b"); //creates an input sequence(User entered string)
		boolean result = m.matches();
		boolean res1 = m.find();
		System.out.println(res1);
		System.out.println("Result"+result);
		
		boolean res = Pattern.matches("[A-Za-z ]+","123");
		System.out.println(res);
		
		String input = "Hop,Shop,Mop,Shopping,Chopping";
		Pattern p1= Pattern.compile("hop");
		Matcher m1 = p1.matcher(input);
		System.out.println(m1.matches());
		
		while(m1.find())
		{
			System.out.println(m1.group() + m1.start() +m1.end());
		}

	}

}
