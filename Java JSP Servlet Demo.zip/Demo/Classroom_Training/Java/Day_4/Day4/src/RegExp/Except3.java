package RegExp;

public class Except3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
		m1();
		//generic / (parent) classes should be defined last
		}
		catch(NullPointerException e)
		{
			System.out.println("Message");
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
		}
	

	}

	private static void m1() throws NullPointerException, Exception {
		// TODO Auto-generated method stub
		m2();
	}

	private static void m2() throws NullPointerException, Exception {
		// TODO Auto-generated method stub
		m3();
	}

	private static void m3() throws NullPointerException, Exception {
		// TODO Auto-generated method stub
		throw new NullPointerException("Null Point");
		
	}

}

//20,00,00,00,000