package Assignment;

public class CurrentAccount extends Account {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
