
public class Department {
	
	int deptId;
	String deptName;
	String deptLoc;
	Employee emp; //dept has a employee (has a relationship)
	
	
	public Department(int deptId, String deptName, String deptLoc,Employee emp) {
		this();
		this.deptId = deptId;
		this.deptName = deptName;
		this.deptLoc = deptLoc;
		this.emp = emp;
	}

	public Department() {
		super();
		System.out.println("I'm a default version");
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}


}

