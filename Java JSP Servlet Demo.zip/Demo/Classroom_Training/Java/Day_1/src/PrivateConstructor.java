
public class PrivateConstructor {
	
	int x;
	String s;
	

	private PrivateConstructor(int x, String s) {
		this.x = x;
		this.s = s;
	}

	static PrivateConstructor display()
	{
	PrivateConstructor pc = new PrivateConstructor(9,"Balaji");
	return pc;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PrivateConstructor hello = PrivateConstructor.display();
		System.out.println(hello.x+hello.s);


	}

}
