class Employee {

	int empID;
	String empName;
	int empSalary;
	int deptId;

	public Employee() {
		this(102);
		empID = 100;
		empName = "John";
		empSalary = 45000;
		deptId = 10;
	}

	protected Employee(int eno) {
		
		empID = eno;
	}

}

public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1 = new Employee();

		System.out.println(e1.empID);

		Employee e2 = new Employee(500);

		System.out.println(e2.empID);
		
		Department d1 = new Department(90,"HR","Pune",e1); //EMPLOYEE OBJECT TO THE DEPARTMENT CONSTRUCTOR 
		System.out.println(d1.deptId+ "\t" + d1.deptName + "\t" + d1.emp.empName + "\t" + d1.emp.empID);
		

	}

}

try{
}
catch{
}
final{
}


Re enter phone num 10,09,40,640