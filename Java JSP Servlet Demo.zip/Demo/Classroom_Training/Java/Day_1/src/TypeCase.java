
public class TypeCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = (int)10.34;
		System.out.println(x);
		float f= 23.45f;
		long l = 99999999999999999L;
		byte b =20;
		b=(byte)(b+20);
		System.out.println("Value after addition is"+b);
		
		
		byte b1=30;
		b1+=30;
		System.out.println(b1);
		
	}

}
//byte (8 bit) auto promoted to int
//short (16-bit) auto promoted to int
//float (32-bit) auto promoted to double