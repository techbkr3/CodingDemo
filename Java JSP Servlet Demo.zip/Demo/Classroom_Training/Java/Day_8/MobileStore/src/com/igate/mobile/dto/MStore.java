package com.igate.mobile.dto;

public class MStore {
	
	private int mobileId;
	private String mobileName;
	private int mobilePrice;
	private int mobileQty;
	
	@Override
	public String toString() {
		return "Mobile ID:" + mobileId + ", Mobile Name:" + mobileName
				+ ", Mobile Price:" + mobilePrice + ", Mobile Quantity:" + mobileQty
				+ "";
	}
	public MStore() {
		super();
	}
	public MStore(int mobileId, String mobileName, int mobilePrice,
			int mobileQty) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
		this.mobileQty = mobileQty;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public int getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(int mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public int getMobileQty() {
		return mobileQty;
	}
	public void setMobileQty(int mobileQty) {
		this.mobileQty = mobileQty;
	}

}
