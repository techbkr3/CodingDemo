package com.igate.mobile.dto;

public class MCustomer {
	
	private String cName;
	private String cMail;
	private long cPhone;
	public MCustomer(String cName, String cMail, long cPhone) {
		super();
		this.cName = cName;
		this.cMail = cMail;
		this.cPhone = cPhone;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcMail() {
		return cMail;
	}
	public void setcMail(String cMail) {
		this.cMail = cMail;
	}
	public long getcPhone() {
		return cPhone;
	}
	public void setcPhone(long cPhone) {
		this.cPhone = cPhone;
	}
	@Override
	public String toString() {
		return "MCustomer [cName=" + cName + ", cMail=" + cMail + ", cPhone="
				+ cPhone + "]";
	}
	
	

}
