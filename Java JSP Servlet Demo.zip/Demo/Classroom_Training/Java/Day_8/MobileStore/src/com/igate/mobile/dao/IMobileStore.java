package com.igate.mobile.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.igate.mobile.dto.MStore;
import com.igate.mobile.exception.InvalidMobileException;

public interface IMobileStore {

	public ArrayList<MStore> getModels() throws InvalidMobileException;

	public int deletePhoneModel(int delPhone) throws InvalidMobileException;

	public ArrayList<MStore> searchPhoneModel(int sRange, int eRange) throws InvalidMobileException;

	public int buyMobile(String cName, String cMail, Long cPhone, int cMobile) throws InvalidMobileException;
	
	

}
