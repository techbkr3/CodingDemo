package com.igate.mobile.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.igate.mobile.dto.MStore;
import com.igate.mobile.exception.InvalidMobileException;

public interface ISMobileStore {

	public ArrayList<MStore> displayModels() throws InvalidMobileException;

	public int deletePhoneModel(int delPhone) throws InvalidMobileException;

	public ArrayList<MStore> searchPhoneModel(int sRange, int eRange) throws InvalidMobileException;

	public int buyMobile(String cName, String cMail, Long cPhone, int cMobile) throws InvalidMobileException;

}
