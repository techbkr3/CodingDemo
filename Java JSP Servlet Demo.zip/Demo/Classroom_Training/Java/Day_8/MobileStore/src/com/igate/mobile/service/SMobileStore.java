package com.igate.mobile.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.igate.mobile.dao.IMobileStore;
import com.igate.mobile.dao.MobileStore;
import com.igate.mobile.dto.MStore;
import com.igate.mobile.exception.InvalidMobileException;

public class SMobileStore implements ISMobileStore {
	
	IMobileStore ms = new MobileStore();

	@Override
	public ArrayList<MStore> displayModels() throws InvalidMobileException {
		// TODO Auto-generated method stub
		return ms.getModels();
	}

	@Override
	public int deletePhoneModel(int delPhone) throws InvalidMobileException {
		// TODO Auto-generated method stub
		return ms.deletePhoneModel(delPhone);
	}

	@Override
	public ArrayList<MStore> searchPhoneModel(int sRange, int eRange) throws InvalidMobileException {
		// TODO Auto-generated method stub
		return ms.searchPhoneModel(sRange,eRange);
	}

	@Override
	public int buyMobile(String cName, String cMail, Long cPhone, int cMobile) throws InvalidMobileException {
		// TODO Auto-generated method stub
		return ms.buyMobile(cName,cMail,cPhone,cMobile);
	}

}
