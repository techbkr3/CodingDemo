package service;

import java.util.ArrayList;

import dto.Employee;
import exception.InvalidEmp;

public interface ISEmpService {
	
	public Employee getEmpbyID(int empid) throws InvalidEmp;

	public ArrayList<Employee> getEmpbyDept(String empdept) throws InvalidEmp;


}
