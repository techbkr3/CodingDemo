package dto;

import java.time.LocalDate;

public class Employee {
	
	private int empNum;
	private String empName;
	private String job;
	private int mgrId;
	private LocalDate hireDate;
	private float empSal;
	public Employee() {
		super();
	}
	private float comm;
	
	public Employee(int empNum, String empName, String job, int mgrId,
			LocalDate hireDate, float empSal, float comm, int deptId) {
		super();
		this.empNum = empNum;
		this.empName = empName;
		this.job = job;
		this.mgrId = mgrId;
		this.hireDate = hireDate;
		this.empSal = empSal;
		this.comm = comm;
		this.deptId = deptId;
	}
		
	@Override
	public String toString() {
		return "Employee [empNum=" + empNum + ", empName=" + empName + ", job="
				+ job + ", mgrId=" + mgrId + ", hireDate=" + hireDate
				+ ", empSal=" + empSal + ", comm=" + comm + ", deptId="
				+ deptId + "]";
	}



	public int getEmpNum() {
		return empNum;
	}
	public void setEmpNum(int empNum) {
		this.empNum = empNum;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgrId() {
		return mgrId;
	}
	public void setMgrId(int mgrId) {
		this.mgrId = mgrId;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public float getComm() {
		return comm;
	}
	public void setComm(float comm) {
		this.comm = comm;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	private int deptId;

}
