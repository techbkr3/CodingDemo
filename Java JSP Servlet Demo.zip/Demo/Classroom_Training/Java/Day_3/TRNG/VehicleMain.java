
public class VehicleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car ob = new Car("4 Wheeler","Blue","SUV",1700000);
		System.out.println(ob.toString());

	}

}
/* Layered Architecture 
 * Presentation Layer //User/Client's input
 * Service/Business //Business Rules & Validation thru RegEx (Eg.Credit Card 1234-XXXX-XXXX-XXXX-6789
 * Bean/DTO (Data Transfer Object) //Transfers data from one layer to another layer i.e Getters & Setters/POJO/toString
 * DAO Data Access Objects (Only Database Queries)
 * Exceptions (Custom Exception Classes)
 * JUnit - 6 Unit Test Cases
 * */


//Parent p = new Child(); //Dynamic / Run_Time Polymorphism aka Upcasting
//If we have a polymorephic rule, method only in parent, not in child - parent called
//If we have a polymorephic rule, method both in parent & child - child called
//If we have a polymorephic rule, method only in child, not in parent - error called
