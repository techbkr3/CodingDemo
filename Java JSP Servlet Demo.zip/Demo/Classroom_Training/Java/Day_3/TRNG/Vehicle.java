class Vehicle{
	String type;

	public Vehicle(String type) {
		super();
		this.type = type;
	}
	
	
	
}
class Car extends Vehicle {
String color;
String model;
double price;

public Car(String type, String color, String model, double price) {
	super(type);
	this.color = color;
	this.model = model;
	this.price = price;
}

@Override
public String toString() {
	return "Car [color=" + color + "\n model=" + model + "\n price=" + price
			+ "\n type=" + type + "]";
}



}
