package com.igate.training.p2;

public class InstanceOf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object ob = new String("Hello");
		String str = new String("Hello");
		System.out.println(ob instanceof Object);
		System.out.println(ob instanceof String); //new String child string
		
		//Object in Object
		System.out.println(str instanceof Object);
		System.out.println(str instanceof String);

	}

}
