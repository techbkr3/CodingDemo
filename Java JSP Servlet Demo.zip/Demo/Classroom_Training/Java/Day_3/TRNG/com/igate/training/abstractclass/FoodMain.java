package com.igate.training.abstractclass;

public class FoodMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Chinese c = new Chinese();
		SpicyFood c1 = new Chinese();
		String cooked = c.cookFood();
		System.out.println(cooked+"  is for "+Food.GUEST);

	}

}

//Since JDK 8 onwards, we can define the methods within the interface
