package com.igate.training.polymorphism;

public class Animal{
	String eat;
	
	public Animal(String eat) {
		super();
		this.eat = eat;
	}
	
	

	public Animal() {
		eat="Ahaan!";
	}



	void eat(){
		System.out.println("I'm  generic eat");
	}
}

 class Horse extends Animal{
	
	String eat;

	public Horse(String eat) {
		super();
		this.eat = eat;
	}
	
	void eat()
	{
		System.out.println("I'm a horse eat "+eat);
	}
	
}