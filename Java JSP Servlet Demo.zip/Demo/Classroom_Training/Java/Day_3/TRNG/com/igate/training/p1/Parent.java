package com.igate.training.p1;

public class Parent {
	private int pri;
	protected int def;
	protected int pro;
	public int pub;
	
	
	
	public Parent() {
		System.out.println("I'm default parent constructor");
		this.pri = 10;
		this.def = 20;
		this.pro = 30;
		this.pub = 40;
	}
	
	

}
