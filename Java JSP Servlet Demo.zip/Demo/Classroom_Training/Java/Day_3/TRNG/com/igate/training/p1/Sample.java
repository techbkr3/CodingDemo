package com.igate.training.p1;

public class Sample {
	
	public Sample(){
		Parent p = new Parent();
		System.out.println("default "+p.def);
		System.out.println("protected in sample "+p.pro);
		System.out.println("public in sample "+p.pub);
	}

}
