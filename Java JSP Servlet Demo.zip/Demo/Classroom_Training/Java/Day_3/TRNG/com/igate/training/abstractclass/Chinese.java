package com.igate.training.abstractclass;

public  class Chinese extends SpicyFood implements Food {

	@Override
	String cookFood() {
		// TODO Auto-generated method stub
		return "I am from Chinese";
	}

	
}
