package com.igate.training.p1;

public class Child extends Parent {

	public Child(){
		System.out.println("default "+def);
		System.out.println("protected in sample "+pro);
		System.out.println("public in sample "+pub);
	}

}
