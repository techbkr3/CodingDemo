package com.igate.training.interfaces;

public interface Socket {
	
	public static final int PIN = 3;
	
	boolean provideCharging(); //public and abstract
	
	void print();
	
	interface Power{
		String noOfHours();
	}
	
}
