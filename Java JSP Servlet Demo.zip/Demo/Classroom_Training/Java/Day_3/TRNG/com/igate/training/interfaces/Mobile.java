package com.igate.training.interfaces;

abstract class AC implements Socket{
	@Override
	public boolean provideCharging()
	{
		return false;
	}
}

class Impl extends AC{
	public void print()
	{
		System.out.println("HWD");
	}
	public void  noOfHours()
	{
		System.out.println("HWD");
	}
}

public abstract class Mobile implements Socket {

	@Override
	public boolean provideCharging()
	{
		return true;
	}
	
	public static void main(String[] args) {
/*		Socket s = new Mobile();
		boolean result = s.provideCharging();
		System.out.println(result);*/
		
		Socket s1 = new Impl();
		boolean result1 = s1.provideCharging();
		System.out.println(result1);
		
		Power p = (Power) new Impl();
		String hrs = p.noOfHours();
		System.out.println(hrs);
		
	}
}
