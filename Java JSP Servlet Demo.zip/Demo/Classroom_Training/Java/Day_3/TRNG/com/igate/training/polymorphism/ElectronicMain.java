package com.igate.training.polymorphism;

public class ElectronicMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseClassElectronics b = new Laptop("32-bit");
		Laptop c = new Laptop("32-bit");
		c.configuration();
		b.configuration();

	}

}
