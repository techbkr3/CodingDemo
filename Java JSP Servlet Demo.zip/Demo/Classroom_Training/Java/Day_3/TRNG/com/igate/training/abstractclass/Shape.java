package com.igate.training.abstractclass;

public abstract class Shape {
    boolean isAvailable;
    
    public Shape(boolean isAvailable)
    {
    	this.isAvailable = isAvailable;
    	System.out.println("I am param of abstract class Shape");
    }
	abstract void draw(); //no definition
	public void show(){
		System.out.println("I'm testing stuff");
	}
	
	
}

abstract class Polygon extends Shape{

	public Polygon(boolean isAvailable) {
		super(false);
		// TODO Auto-generated constructor stub
	}

	
	
}

class fiveSidedPolygon extends Polygon{
	
	
	public fiveSidedPolygon(boolean isAvailable) {
		super(isAvailable);
		// TODO Auto-generated constructor stub
	}

	@Override
	void draw() {
		System.out.println("I'm drawing polygon "+isAvailable);
	}
}