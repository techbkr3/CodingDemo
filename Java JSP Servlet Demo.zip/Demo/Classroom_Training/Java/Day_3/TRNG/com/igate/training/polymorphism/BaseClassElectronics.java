package com.igate.training.polymorphism;

public class BaseClassElectronics {
	
	public static void configuration()
	{
		System.out.println("I'm from base class");
	}
	
}

class Laptop extends BaseClassElectronics{
	static String config;

	Laptop(String config) {
		super();
		this.config = config;
	}
	
	public static void configuration()
	{
		System.out.println("I'm from child class\t"+config);
	}
	
}