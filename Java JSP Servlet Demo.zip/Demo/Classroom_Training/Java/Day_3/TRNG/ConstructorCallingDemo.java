class Super{
	int x;
	
	Super(){
		System.out.println("I'm parent");
	}
	
	Super(int x)
	{
		this.x=x;
		System.out.println(x);
	}
	
	
}
class Sub extends Super{
	
	String str;
	
	Sub(){
		System.out.println("I'm child");
	}
	
	Sub(String str)
	{
		this.str=str;
		System.out.println(str);
	}
	
}
public class ConstructorCallingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//PARENT CLASS CONSTRUCTORS ARE ALWAYS CALLED FIRST
		
		Sub obj = new Sub();
		Sub obj2 = new Sub("A D");

	}

}
