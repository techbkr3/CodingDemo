class Parent{
	void m1(){
		System.out.println("I'm in a parent method!");
	}
}

class Child extends Parent{
	
}

public class InheritanceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Child obj=new Child();
		obj.m1();

	}

}
