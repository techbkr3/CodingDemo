package com.igate.training.jdbc.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			Connection con = DBUtility.obtainConnection();
			String sql = "SELECT * FROM STUDENT WHERE SDOB IS NOT NULL ORDER BY STUDENT_ID ASC";
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while(rs.next())
			{
				System.out.println(rs.getInt("STUDENT_ID")+"\t"+rs.getString("STUDENT_NAME")+" \t"+rs.getFloat("STUDENT_MARKS") +" \t"+rs.getDate("SDOB").toLocalDate());
			}
			DBUtility.releaseConnection();
		}
		catch(SQLException e)
		{
		System.out.println(e.getMessage());	
		}
		finally
		{
			try
			{
				DBUtility.releaseConnection();
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
		}
	}

}
