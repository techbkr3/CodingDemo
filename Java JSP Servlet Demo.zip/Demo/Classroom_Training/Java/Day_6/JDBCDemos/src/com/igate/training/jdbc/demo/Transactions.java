package com.igate.training.jdbc.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Transactions {

	public static void main(String[] args) {
		String sql1 = "SELECT COUNT(*) FROM STUDENT WHERE STUDENT_ID = ?";
		String sql2 = "UPDATE STUDENT SET STUDENT_NAME = ? WHERE STUDENT_ID = ?";
		Connection con = null;
		try {
			con = DBUtility.obtainConnection();
			con.setAutoCommit(false);
			PreparedStatement pst1 = con.prepareStatement(sql1);
			pst1.setInt(1, 1002);
			int count = 0;
			ResultSet rs = pst1.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
			if (count > 0) {
				PreparedStatement pst2 = con.prepareStatement(sql2);
				pst2.setString(1, "Adidev");
				pst2.setInt(2, 1007);
				int rows = pst2.executeUpdate();
				if (rows != 0) {
					System.out.println(rows + " Rows Updated");
				} else {
					System.out.println(rows + " Rows Updated");
				}
			}
			else
			{
				System.out.println("Student does not exist");
			}
			con.commit();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
			System.out.println(e1.getMessage()+" Error while closing connection");		
			}
			} finally {
			try {
				DBUtility.releaseConnection();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

}
