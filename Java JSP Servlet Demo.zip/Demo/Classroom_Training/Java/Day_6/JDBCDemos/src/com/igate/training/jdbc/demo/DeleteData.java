package com.igate.training.jdbc.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
		{
			System.out.println("Enter min Marks criteria to delete records:");
			float marks =  Float.parseFloat(br.readLine());
			Connection con = DBUtility.obtainConnection();
			String sql = "delete student where student_marks > ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setFloat(1, marks);
			
			int rows = ps.executeUpdate();
			if(rows!=0){
				System.out.println(rows+" Records Updated");
			}
			else{
				System.out.println(rows+" Records Updated");
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		
	}

}
