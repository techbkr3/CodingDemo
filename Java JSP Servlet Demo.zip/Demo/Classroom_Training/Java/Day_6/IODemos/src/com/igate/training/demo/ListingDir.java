package com.igate.training.demo;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ListingDir {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//will create a directory stream object which will hold other sb files and other directories
		
		Path javaHome = Paths.get("D:/Exam/Module 1/Module 1");
		DirectoryStream<Path> contents = Files.newDirectoryStream(javaHome);
		
		for(Path content:contents)
		{
			System.out.println(content.getFileName());
		}
		contents.close();
	}

}
