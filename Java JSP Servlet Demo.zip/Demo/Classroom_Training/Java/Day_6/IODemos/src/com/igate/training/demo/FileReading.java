package com.igate.training.demo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileReading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try(FileInputStream fis = new FileInputStream("D:\\read.txt");
			BufferedInputStream bis = new BufferedInputStream(fis);
			FileOutputStream fos = new FileOutputStream("D:\\write.txt",true);
			BufferedOutputStream bos = new BufferedOutputStream(fos);)
		{
			int contents;
			
			while((contents=bis.read()) != -1) //EOF
			{
				bos.write(contents);
			}
			
		}
		catch(Exception e)
		{
			System.out.println("IO Error: "+"\t"+e.getMessage());
		}

	}

}
