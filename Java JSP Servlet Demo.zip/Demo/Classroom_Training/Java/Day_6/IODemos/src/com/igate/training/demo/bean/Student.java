package com.igate.training.demo.bean;

import java.io.Serializable;

public class Student implements Serializable {
	
	
	int sid;
	String sname;
	float smarks;
	transient String saddress; //student address will not be written to the file
	
	public Student(int sid, String sname, float smarks, String saddress) {
		super();
		System.out.println("Hi, I'm called");
		this.sid = sid;
		this.sname = sname;
		this.smarks = smarks;
		this.saddress = saddress;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", smarks="
				+ smarks + ", saddress=" + saddress + "]";
	}
	
	

}
