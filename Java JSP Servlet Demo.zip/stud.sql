drop table student;
drop table course;

create table course(course_id number(3)PRIMARY KEY,
course_name varchar2(20));
insert into course values(1,'java');
insert into course values(2,'c');
insert into course values(3,'c++');

create table student(student_id number(3)PRIMARY KEY,
student_name varchar2(20),
course_id number(3) CONSTRAINT fk_st REFERENCES course(course_id)
);
insert into student values(101,'ram',1);
insert into student values(102,'sham',2);
insert into student values(103,'jam',3);