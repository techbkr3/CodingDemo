DROP TABLE Book_Transactions;
DROP TABLE Student_Marks;
DROP TABLE Book_Masters;
DROP TABLE Student_Masters;
DROP TABLE Staff_Masters;
DROP TABLE Designation_Masters;
DROP TABLE Department_Masters;

CREATE TABLE Designation_Masters(
Design_Code NUMBER(3) PRIMARY KEY,
Design_Name VARCHAR2(50) UNIQUE);
INSERT INTO designation_masters VALUES(101,'HOD');
INSERT INTO designation_masters VALUES(102,'Professor');
INSERT INTO designation_masters VALUES(103,'Reader');
INSERT INTO designation_masters VALUES(104,'Sr.Lecturer');
INSERT INTO designation_masters VALUES(105,'Lecturer');
INSERT INTO designation_masters VALUES(106,'Director');


CREATE TABLE Department_Masters(
Dept_code NUMBER(2) PRIMARY KEY,
Dept_Name VARCHAR2(50) UNIQUE);
INSERT INTO department_masters VALUES(10,'Computer Science');
INSERT INTO department_masters VALUES(20,'Electricals');
INSERT INTO department_masters VALUES(30,'Electronics');
INSERT INTO department_masters VALUES(40,'Mechanics');
INSERT INTO department_masters VALUES(50,'Robotics');


CREATE TABLE Student_Masters(
Student_Code NUMBER(6) PRIMARY KEY,
Student_Name VARCHAR2(50) NOT NULL,
Dept_Code NUMBER(2) REFERENCES Department_Masters(dept_code),
Student_Dob DATE,
Student_Address VARCHAR2(240));

INSERT INTO student_masters VALUES(1001,'Amit',10,'11-Jan-80','chennai');
INSERT INTO student_masters VALUES(1002,'Ravi',10,'1-Nov-81','New Delhi');
INSERT INTO student_masters VALUES(1003,'Ajay',20,'13-Jan-82',null);
INSERT INTO student_masters VALUES(1004,'Raj',30,'14-Jan-79','Mumbai');
INSERT INTO student_masters VALUES(1005,'Arvind',40,'15-Jan-83','Bangalore');
INSERT INTO student_masters VALUES(1006,'Rahul',50,'16-Jan-81','Delhi');
INSERT INTO student_masters VALUES(1007,'Mehul',20,'17-Jan-82','Chennai');
INSERT INTO student_masters VALUES(1008,'Dev',10,'11-Mar-81','Bangalore');
INSERT INTO student_masters VALUES(1009,'Vijay',30,'19-Jan-80','Bangalore');
INSERT INTO student_masters VALUES(1010,'Rajat',40,'20-Jan-80','Bangalore');
INSERT INTO student_masters VALUES(1011,'Sunder',50,'21-Jan-80','Chennai');
INSERT INTO student_masters VALUES(1012,'Rajesh', 30,'22-Jan-80',null);
INSERT INTO student_masters VALUES(1013,'Anil',20,'23-Jan-80','Chennai');
INSERT INTO student_masters VALUES(1014,'Sunil',10,'15-Feb-85',	null);
INSERT INTO student_masters VALUES(1015,'Kapil',40,'18-Mar-81','Mumbai');
INSERT INTO student_masters VALUES(1016,'Ashok',40,'26-Nov-80',null);
INSERT INTO student_masters VALUES(1017,'Ramesh',30,'27-Dec-80',null);
INSERT INTO student_masters VALUES(1018,'Amit Raj',50,'28-Sep-80','New Delhi');
INSERT INTO student_masters VALUES(1019,'Ravi Raj',50,'29-May-81','New Delhi');
INSERT INTO student_masters VALUES(1020,'Amrit',10,'11-Nov-80',null);
INSERT INTO student_masters VALUES(1021,'Sumit',20,'1-Jan-80','Chennai');

CREATE TABLE Student_Marks(
Student_Code NUMBER (6) REFERENCES student_Masters(student_code),
Student_Year NUMBER not null,
Subject1 NUMBER (3),
Subject2 NUMBER (3),
Subject3 NUMBER (3));
INSERT INTO student_marks VALUES(1001,	2010,	55,45,78);
INSERT INTO student_marks VALUES(1002,	2010,	66,74,88);
INSERT INTO student_marks VALUES(1003,	2010,	87,54,65);
INSERT INTO student_marks VALUES(1004,	2010,	65,64,90);
INSERT INTO student_marks VALUES(1005,	2010,	78,88,65);
INSERT INTO student_marks VALUES(1006,	2010,	65,86,54);
INSERT INTO student_marks VALUES(1007,	2010,	67,79,49);
INSERT INTO student_marks VALUES(1008,	2010,	72,55,55);
INSERT INTO student_marks VALUES(1009,	2010,	71,59,58);
INSERT INTO student_marks VALUES(1010,	2010,	68,44,92);
INSERT INTO student_marks VALUES(1011,	2010,	89,96,78);
INSERT INTO student_marks VALUES(1012,	2010,	78,56,55);
INSERT INTO student_marks VALUES(1013,	2010,	75,58,65);
INSERT INTO student_marks VALUES(1014,	2010,	73,74,65);
INSERT INTO student_marks VALUES(1015,	2010,	66,45,74);
INSERT INTO student_marks VALUES(1016,	2010,	68,78,74);
INSERT INTO student_marks VALUES(1017,	2010,	69,44,52);
INSERT INTO student_marks VALUES(1018,	2010,	65,78,56);
INSERT INTO student_marks VALUES(1019,	2010,	78,58,74);
INSERT INTO student_marks VALUES(1020,	2010,	45,55,65);
INSERT INTO student_marks VALUES(1021,	2010,	78,79,78);
INSERT INTO student_marks VALUES(1001,	2011,	68,44,92);
INSERT INTO student_marks VALUES(1002,	2011,	89,96,78);
INSERT INTO student_marks VALUES(1003,	2011,	78,56,55);
INSERT INTO student_marks VALUES(1004,	2011,	75,58,65);
INSERT INTO student_marks VALUES(1005,	2011,	73,74,65);
INSERT INTO student_marks VALUES(1006,	2011,	66,45,74);
INSERT INTO student_marks VALUES(1007,	2011,	68,78,74);
INSERT INTO student_marks VALUES(1008,	2011,	69,44,52);
INSERT INTO student_marks VALUES(1009,	2011,	65,78,56);
INSERT INTO student_marks VALUES(1010,	2011,	78,58,74);
INSERT INTO student_marks VALUES(1011,	2011,	45,55,65);
INSERT INTO student_marks VALUES(1012,	2011,	78,79,78);
INSERT INTO student_marks VALUES(1013,	2011,	66,74,88);
INSERT INTO student_marks VALUES(1014,	2011,	65,64,90);
INSERT INTO student_marks VALUES(1015,	2011,	78,88,65);
INSERT INTO student_marks VALUES(1016,	2011,	65,86,54);
INSERT INTO student_marks VALUES(1017,	2011,	67,79,49);
INSERT INTO student_marks VALUES(1018,	2011,	72,55,55);
INSERT INTO student_marks VALUES(1019,	2011,	71,59,58);
INSERT INTO student_marks VALUES(1020,	2011,	55,45,78);
INSERT INTO student_marks VALUES(1021,	2011,	87,54,65);



CREATE TABLE staff_Masters(
Staff_Code number(8) PRIMARY KEY,
Staff_Name varchar2(50) NOT NULL,
Design_Code REFERENCES Designation_Masters(design_code),
Dept_Code REFERENCES Department_Masters(dept_code),
Staff_dob DATE,
Hiredate DATE,
Mgr_code NUMBER(8),
Staff_sal NUMBER (10,2),
Staff_address VARCHAR2(240));

INSERT INTO staff_masters 
VALUES(100001,'Arvind',102,30,'15-Jan-80','15-Jan-03',100006,17000,'Bangalore');
INSERT INTO staff_masters 
VALUES(100002,'Shyam',102,20,'18-Feb-80','17-Feb-02',100007,20000,'Chennai');
INSERT INTO staff_masters 
VALUES(100003,'Mohan',102,10,'23-Mar-80','19-Jan-02',100006,24000,'Mumbai');
INSERT INTO staff_masters 
VALUES(100004,'Anil',102,20,'22-Apr-77','11-Mar-01',100006,20000,'Hyderabad');
INSERT INTO staff_masters
VALUES(100005,'John',106,10,'22-May-76','21-Jan-01',100007,32000,'Bangalore');
INSERT INTO staff_masters 
VALUES(100006,'Allen',103,30,'22-Jan-80','23-Apr-01',100005,42000,'Chennai');


INSERT INTO staff_masters 
VALUES(100007,'Smith',103,20,'19-Jul-73','12-Mar-02',100005,62000,'Mumbai');
INSERT INTO staff_masters 
VALUES(100008,'Raviraj',102,40,'17-Jun-80','11-Jan-03',100006,18000,'Bangalore');
INSERT INTO staff_masters
VALUES(100009,'Rahul',102,20,'16-Jan-78','11-Dec-03',100006,22000,'Hyderabad');
INSERT INTO staff_masters 
VALUES(100010,'Ram',103,30,'17-Jan-79','17-Jan-02',100007,32000,'Bangalore');



CREATE TABLE Book_Masters(
Book_code NUMBER(10) PRIMARY KEY,
Book_name VARCHAR2(50) NOT NULL,
Book_pub_year NUMBER,
Book_pub_author VARCHAR2 (50) NOT NULL);


INSERT INTO book_masters VALUES(10000001,'Let Us C++',2000,'Yashavant Kanetkar');

INSERT INTO book_masters VALUES(10000002,'Mastersing VC++',2005,'P.J Allen');

INSERT INTO book_masters VALUES(10000003,'JAVA Complete Reference',2004,'H.Schild');

INSERT INTO book_masters VALUES(10000004,'J2EE Complete Reference',2000,'H. Schild');

INSERT INTO book_masters VALUES(10000005,'Relational DBMS',2000,'B.C. Desai');

INSERT INTO book_masters VALUES(10000006,'Let Us C',2000, 'Yashavant Kanetkar');

INSERT INTO book_masters VALUES(10000007,'Intoduction To Algorithams',2001,'Cormen');

INSERT INTO book_masters VALUES(10000008,'Computer Networks',2000,'Tanenbaum');

INSERT INTO book_masters VALUES(10000009,'Introduction to O/S',2001,'Millan');


CREATE TABLE Book_transactions(
Book_code NUMBER(10) REFERENCES Book_Masters(Book_code),
Student_code NUMBER(6) REFERENCES Student_Masters(student_code),
Staff_code number(8) REFERENCES Staff_Masters(staff_code),
Book_issue_Date date not null,
Book_expected_return_date date not null,
Book_actual_return_date date);

INSERT INTO book_transactions 
VALUES(10000006,1012,NULL,'02-Feb-2011','09-Feb-2011',NULL);

INSERT INTO book_transactions 
VALUES(10000008,NULL,100006,'10-Mar-2011','17-Mar-2011','15-Mar-2011');

INSERT INTO book_transactions 
VALUES(10000009,NULL,100010,'01-Apr-2011','08-Apr-2011','10-Apr-2011');

INSERT INTO book_transactions 
VALUES(10000004,1015,NULL,'12-Feb-2011','19-Feb-2011',NULL);


INSERT INTO book_transactions 
VALUES(10000005,NULL,100007,'14-Mar-2011','21-Mar-2011','21-Mar-2011');

INSERT INTO book_transactions 
VALUES(10000007,NULL,100007,'01-Apr-2011','07-Apr-2011','06-Apr-2011');

INSERT INTO book_transactions 
VALUES(10000007,NULL,100006,'01-Apr-2010','07-Apr-2010','06-Apr-2010');
INSERT INTO book_transactions 
VALUES(10000005,1009,NULL,'31-May-2011','08-JUN-2011','08-JUN-2011');

3.1Write a PL/SQL block to find the maximum salary of the staff in the given department.
Note: Department code should be passed as parameter to the cursor.

ans:

Create or REPLACE PROCEDURE max_sal(v_deptno IN staff_masters.dept_code%TYPE) 
AS
	
	CURSOR c_staff(dno NUMBER) IS SELECT * from staff_masters where staff_sal = (select max(staff_sal) from staff_masters where dept_code = dno) and dept_code=dno;
	
	staff_rec staff_masters%ROWTYPE;
	
BEGIN
	OPEN c_staff(v_deptno);
	FETCH c_staff into staff_rec;
	DBMS_OUTPUT.PUT_LINE('staff name with max salary: ' || staff_rec.staff_name || ' salary: ' || staff_rec.staff_sal);
EXCEPTION 
	WHEN no_data_found THEN
		DBMS_OUTPUT.PUT_LINE('no staff found with given deptno.');
END;

--- client to calling environment
DECLARE
	v_deptno staff_masters.dept_code%TYPE;
BEGIN
	v_deptno := &deptno;
	max_sal(v_deptno);
END;


3.2. Write a function to compute age. The function should accept a date and return age in
years.

ans:

Create or REPLACE FUNCTION find_age(v_date DATE) RETURN NUMBER
AS
	v_age NUMBER;
BEGIN
	v_age := round((sysdate-v_date)/365);
	RETURN v_age;
END;

--- client to calling environment
DECLARE
	v_age NUMBER;
BEGIN
	v_age:=find_age('19-MAR-94');
	DBMS_OUTPUT.PUT_LINE('age is: ' || v_age);
EXCEPTION 
	WHEN invalid_number THEN
		DBMS_OUTPUT.PUT_LINE('invalid value given.');
END;


3.3
Write a procedure that accept staff code and update staff name to Upper case. If the staff
name is null raise a user defined exception.


ans:
Create or REPLACE PROCEDURE update_name(v_staff_code staff_masters.staff_code%TYPE) 
IS
	
	CURSOR c_staff IS SELECT * from staff_masters where staff_code=v_staff_code;
	NAME_NULL EXCEPTION; 
	staff_rec staff_masters%ROWTYPE;

BEGIN
	
	OPEN c_staff;
	IF c_staff%ISOPEN THEN
		IF c_staff%FOUND THEN
			FETCH c_staff INTO staff_rec;
				
			IF staff_rec.staff_name IS NOT NULL THEN
				
				update staff_masters set staff_name = UPPER(staff_rec.staff_name) where staff_code = staff_rec.staff_code ;
			END IF;
		ELSE
			RAISE NAME_NULL;
		END IF;
	END IF;
EXCEPTION
	WHEN NAME_NULL THEN 
		DBMS_OUTPUT.PUT_LINE('staff name is null.');
END;

--- client to calling environment
DECLARE
	v_staffCode staff_masters.staff_code%TYPE;
BEGIN
	v_staffCode := &staff_code;
	update_name(v_staffCode);
END;


3.4
Write a procedure to find the manager of a staff. Procedure should return the following –
Staff_Code, Staff_Name, Dept_Code and Manager Name.

ans:

Create or REPLACE PROCEDURE get_manager(v_staff_code staff_masters.staff_code%TYPE) 
IS
	
	CURSOR c_staff IS SELECT s.staff_code,s.staff_name, s.dept_code,(select staff_name from staff_masters where staff_code=s.mgr_code) from staff_masters s where s.staff_code=v_staff_code;
	
	staff_not_found EXCEPTION; 
	
	TYPE staffrec IS RECORD
	(
		staff_code staff_masters.staff_code%TYPE,
		staff_name staff_masters.staff_name%TYPe,
		dept_code staff_masters.dept_code%TYPE,
		mgr_name staff_masters.staff_name%TYPE
	);
	v_rec staffrec;

BEGIN
	OPEN c_staff;
	IF c_staff%ISOPEN THEN
		FETCH c_staff INTO v_rec;
		
		DBMS_OUTPUT.PUT_LINE(v_rec.staff_code || ' ' || v_rec.staff_name || ' ' || v_rec.dept_code || ' ' || v_rec.mgr_name);
	ELSE
		RAISE staff_not_found;
	END IF;
EXCEPTION
	WHEN staff_not_found THEN 
		DBMS_OUTPUT.PUT_LINE('staff code not found.');
END;

--- client to calling environment
DECLARE
	v_staffCode staff_masters.staff_code%TYPE;
BEGIN
	v_staffCode := &staff_code;
	get_manager(v_staffCode);
END;


3.5
Write a function to compute the following. Function should take Staff_Code and return
the cost to company.
DA = 15% Salary, HRA= 20% of Salary, TA= 8% of Salary.
Special Allowance will be decided based on the service in the company.
< 1 Year 				Nil
>=1 Year< 2 Year	 	10% of Salary
>=2 Year< 4 Year 		20% of Salary
>4 Year 				30% of Salary


ans:

CREATE OR REPLACE FUNCTION emp_cost(v_staff_code staff_masters.staff_code%TYPE) RETURN emp.sal%TYPE
	AS
		CURSOR staff_cursor IS SELECT * FROM staff_masters WHERE staff_code=v_staff_code;
		v_staffRec staff_masters%ROWTYPE;
		
		v_sal staff_masters.staff_sal%TYPE;
		v_da staff_masters.staff_sal%TYPE;
		v_hra staff_masters.staff_sal%TYPE;
		v_ta staff_masters.staff_sal%TYPE;
		v_cost staff_masters.staff_sal%TYPE;
		v_specialAllowance staff_masters.staff_sal%TYPE;
		v_experience NUMBER;
    BEGIN
		OPEN staff_cursor;
		IF(staff_cursor%ISOPEN) THEN 
			FETCH staff_cursor INTO v_staffRec;
			
			v_sal := v_staffRec.staff_sal;
			v_da := v_staffRec.staff_sal * 0.15;
			v_hra := v_staffRec.staff_sal * 0.2;
			v_ta := v_staffRec.staff_sal * 0.08;
			v_experience := round((sysdate-v_staffRec.hiredate)/365);
			
			IF v_experience < 1 THEN
				v_specialAllowance := 0;
			ELSIF v_experience >= 1 AND v_experience < 2 THEN
				v_specialAllowance := v_sal * 0.1 * 0.1;
			ELSIF v_experience >= 2 AND v_experience < 4 THEN
				v_specialAllowance := v_sal * 0.2;
			ELSE
				v_specialAllowance := v_sal * 0.3;
			END IF;
			v_cost := v_sal + v_da + v_hra + v_ta + v_specialAllowance;
			RETURN v_cost;
		END IF;
    END emp_cost;   
	
	
	-------CLIENT
    DECLARE
	    v_staff_code staff_masters.staff_code%TYPE;
		v_cost staff_masters.staff_code%TYPE;
	BEGIN
	    v_staff_code:=&staffno;
	    DBMS_OUTPUT.PUT_LINE('cost of employee: ' || emp_cost(v_staff_code));
	END;

	
3.6

Write a procedure that displays the following information of all staff
Staff_Name Department Name Designation Salary Status
Note: - Status will be (Greater, Lesser or Equal) respective to average salary of their own
department. Display an error message Staff_Master table is empty if there is no matching
record.


ans:


CREATE OR REPLACE FUNCTION get_avgSal(v_deptno staff_masters.dept_code%type) RETURN staff_masters.staff_sal%TYPE
AS
	
	CURSOR s_cursor is SELECT avg(staff_sal) from staff_masters where dept_code=v_deptno;
	
	v_avgSal staff_masters.staff_sal%TYPE :=0;
	
BEGIN
	
	OPEN s_cursor;
	if s_cursor%ISOPEN THEN
		FETCH s_cursor INTO v_avgSal;
	END IF;
	
	RETURN v_avgSal;
END;

CREATE or REPLACE PROCEDURE display_staffInfo
IS
	CURSOR staff_cursor IS SELECT s.staff_code, s.staff_name, s.dept_code, d.dept_name, d1.design_name, s.staff_sal from staff_masters s, department_masters d, designation_masters d1 where  
	s.dept_code=d.dept_code and s.design_code=d1.design_code;
	
	type staff_rec IS RECORD(
	staff_code staff_masters.staff_code%TYPE,
	staff_name staff_masters.staff_name%TYPE,
	dept_code staff_masters.dept_code%TYPE,
	dept_name department_masters.dept_name%TYPE,
	design_name designation_masters.design_name%TYPE,
	staff_sal staff_masters.staff_sal%TYPE
	);
	staffRec staff_rec;
	
	v_avgSal staff_masters.staff_sal%TYPE;
	v_status VARCHAR2(10);
BEGIN
	
	FOR staff_rec in staff_cursor
	LOOP
	
		v_avgSal := get_avgSal(staff_rec.dept_code);
		if v_avgSal < staff_rec.staff_sal THEN
			v_status := 'Greater';
		ELSIF v_avgSal > staff_rec.staff_sal THEN
			v_status := 'Lesser';
		ELSE
			v_status := 'Equal';
		END IF;
		DBMS_OUTPUT.PUT_LINE(staff_rec.staff_name|| ' ' || staff_rec.dept_name || ' ' || staff_rec.design_name || ' ' || staff_rec.staff_sal || ' ' || v_status);

	END LOOP;
	
END;

-----client
DECLARE

BEGIN
	display_staffInfo();
END;





3.7
Write a procedure that accept Staff_Code and update the salary and store the old salary
details in Staff_Master_Back (Staff_Master_Back has the same structure without any
constraint) table.

Exp< 2 then no Update
Exp> 2 and < 5 then 20% of salary
Exp> 5 then 25% of salary

ans:

CREATE or REPLACE TRIGGER after_update_sal AFTER UPDATE OF staff_sal ON staff_masters for each ROW
	BEGIN
		insert INTO Staff_Master_Back values (:OLD.staff_code, :OLD.staff_name, :OLD.design_code, :OLD.dept_code, :OLD.staff_dob, :OLD.hiredate, :OLD.mgr_code, :OLD.staff_sal, :OLD.staff_address);
	END;



Create or REPLACE PROCEDURE old_sal_details(v_staff_code staff_masters.staff_code%TYPE) 
IS
	v_staff_rec Staff_Masters%ROWTYPE;
	v_staff_sal Staff_Masters.staff_sal%TYPE;
BEGIN
	
	select * INTO v_staff_rec from Staff_Masters where staff_code= v_staff_code;
		
	IF (sysdate-v_staff_rec.hiredate) < 2 THEN
		v_staff_sal := v_staff_rec.staff_sal;
	ELSIF (sysdate-v_staff_rec.hiredate) >=2 and (sysdate-v_staff_rec.hiredate) < 5 THEN
		v_staff_sal := v_staff_rec.staff_sal * 1.2;
	ELSE 
		v_staff_sal := v_staff_rec.staff_sal * 1.25;
	END IF;
	update staff_masters SET staff_sal=v_staff_sal where staff_code=v_staff_code;
	
END;

--- client to calling environment
DECLARE
	v_staffCode staff_masters.staff_code%TYPE;
	
BEGIN
	v_staffCode := &staff_code;
	old_sal_details(v_staffCode);
END;



3.8

Create a procedure that accepts the book code as parameter from the user. Display the
details of the students/staff that have borrowed that book and has not returned the same.
The following details should be displayed
Student/Staff Code Student/Staff Name Issue Date Designation Expected Ret_Date


ans:

Create or REPLACE PROCEDURE book_details(v_book_code book_transactions.book_code%TYPE) 
IS
	v_staff_rec Staff_Masters%ROWTYPE;
	v_staff_sal Staff_Masters.staff_sal%TYPE;
	
	CURSOR book_cursor IS select s.staff_code, s.staff_name, s.design_code,s1.book_issue_date, s1.book_expected_return_date from staff_masters s, book_transactions s1 where s1.book_code=v_book_code and s1.staff_code=s.staff_code and s1.book_actual_return_date is NULL 
				UNION 
	select s.student_code, s.student_name, NULL ,s1.book_issue_date, s1.book_expected_return_date from student_masters s, book_transactions s1 where s1.book_code=v_book_code and s1.student_code=s.student_code and s1.book_actual_return_date is NULL;
	
	TYPE bookrec IS RECORD
	(
		staff_code  staff_masters.staff_code%TYPE,
		staff_name  staff_masters.staff_name%TYPe,
		design_code  staff_masters.design_code%TYPE,
		book_issue_date  book_transactions.book_issue_date%TYPE,
		book_expected_return_date book_transactions.book_expected_return_date%TYPE
	);
	v_rec bookrec;

BEGIN
	
	OPEN book_cursor;
	FETCH book_cursor INTO v_rec;
	while(book_cursor%FOUND)
	LOOP
		DBMS_OUTPUT.PUT_LINE(v_rec.staff_code || ' ' || v_rec.staff_name || ' ' || v_rec.design_code|| ' ' ||  v_rec.book_issue_date || ' ' || v_rec.book_expected_return_date);
		
		FETCH book_cursor INTO v_rec;
		EXIT WHEN book_cursor%NOTFOUND;
		
	END LOOP;
	DBMS_OUTPUT.PUT_LINE(book_cursor%ROWCOUNT || ' rows selected.');
	CLOSE book_cursor;
END;

--- client to calling environment
DECLARE
	v_bookCode book_transactions.book_code%TYPE;
	
BEGIN
	v_bookCode := &book_code;
	book_details(v_bookCode);
END;



3.9

Write a package which will contain a procedure and a function.
Function: This function will return years of experience for a staff. This function will take the
hiredate of the staff as an input parameter. The output will be rounded to the nearest year
(1.4 year will be considered as 1 year and 1.5 year will be considered as 2 year).
Procedure: Capture the value returned by the above function to calculate the additional
allowance for the staff based on the experience.
Additional Allowance = Year of experience x 3000
Calculate the additional allowance and store Staff_Code, Date of Joining, and Experience in
years and additional allowance in Staff_Allowance table.


ans:


--------PACKAGE

CREATE PACKAGE staff_package 
AS
	PROCEDURE get_allowance(v_experience IN NUMBER ,v_allowance out NUMBER);
	FUNCTION get_experience(v_hiredate IN staff_masters.hiredate%TYPE) RETURN NUMBER;
END staff_package;


--Package body
CREATE OR REPLACE PACKAGE BODY staff_package
AS
	--- package body procedure
	PROCEDURE get_allowance(v_experience IN NUMBER ,v_allowance out NUMBER) 
	IS
	BEGIN
		
		v_allowance := v_experience * 3000;
		
	END;
	
	---function
	
	FUNCTION get_experience(v_hiredate IN staff_masters.hiredate%TYPE) RETURN NUMBER
	AS
		v_experience NUMBER;
    BEGIN
		v_experience := ROUND((sysdate-v_hiredate)/365);
		RETURN v_experience;
    END get_experience;
END staff_package;


-----client-------

DECLARE
	CURSOR staff_cursor IS SELECT * from staff_masters;
	v_experience NUMBER;
	v_allowance NUMBER;
	v_counter NUMBER :=0;
BEGIN
	
	FOR v_rec in staff_cursor
	LOOP
		
		v_experience := staff_package.get_experience(v_rec.hiredate);
		staff_package.get_allowance(v_experience, v_allowance);
		
		INSERT INTO staff_allowance values (v_rec.staff_code , v_rec.hiredate , v_experience , v_allowance);
		
		v_counter := v_counter +1;
	END LOOP;
	DBMS_OUTPUT.PUT_LINE(v_counter || ' rows inserted.');
END;


3.10
Write a procedure to insert details into Book_Transaction table. Procedure should accept the book code and staff/student code. Date of issue is current date and the expected return date should be 10 days from the current date. If the expected return date falls on Saturday or Sunday, then it should be the next working day.


ans:
CREATE OR REPLACE PROCEDURE insertBookDetails(v_bookCode IN book_transactions.book_code%TYPe , v_staffCode IN book_transactions.staff_code%TYPe, v_studentCode IN book_transactions.student_code%TYPe) 

IS
	v_returnDate DATE;
BEGIN
		
	v_returnDate := SYSDATE + 10;
	if RTRIM(TO_CHAR( v_returnDate , 'DAY')) in ('SATURDAY','SUNDAY') THEN
		v_returnDate := NEXT_DAY(v_returnDate,'MONDAY');
	END IF;
		
	INSERT INTO book_transactions(book_code, staff_code, student_code, book_issue_date, book_expected_return_date) VALUES
	(v_bookCode, v_staffCode, v_studentCode, SYSDATE, v_returnDate);
		
	DBMS_OUTPUT.PUT_LINE(SQL%ROWCOUNT || ' rows inserted.');
		
END;

------client
BEGIN
	insertBookDetails(10000004,NULL,1015);
END;


3.11

Tune the following Oracle Procedure enabling to gain better performance.
Objective:The Procedure should update the salary of an employee and at the same time
retrieve the employee's name and new salary into PL/SQL variables.

ans:

CREATE OR REPLACE PROCEDURE update_salary (emp_id NUMBER) 
IS
	v_name VARCHAR2(15);
	v_newsal NUMBER;
BEGIN
	UPDATE emp_copy SET sal = sal * 1.1 WHERE empno = emp_id;
	
	SELECT ename, sal INTO v_name, v_newsal FROM emp_copy WHERE empno = emp_id;
	DBMS_OUTPUT.PUT_LINE('Emp Name:' || v_name);
	DBMS_OUTPUT.PUT_LINE('Salary:' || v_newsal);
END;


---client

BEGIN
	update_salary(7782);
END;




3.12
Write a procedure which prints the following report using procedure:
The procedure should take deptno as user input and appropriately print the emp details.
Also display :
Number of Employees,TotalSalary,MaximumSalary,Average Salary
Note: The block should achieve the same without using Aggregate Functions.
Sample output for deptno 10 is shown below:
Employee Name : CLARK
Employee Job : MANAGER
Employee Salary : 2450
Employee Comission :
************************************
Employee Name : KING
Employee Job : PRESIDENT
Employee Salary : 5000
Employee Comission :
************************************
Employee Name : MILLER
Employee Job : CLERK
Employee Salary : 1300
Employee Comission :
************************************
Number of Employees : 3
Total Salary : 8750
Maximum Salary : 5000
Average Salary : 2916.67
------------------------------------


ans:

CREATE OR REPLACE PROCEDURE print_details(v_deptno emp.deptno%TYPE )
IS
	CURSOR emp_cursor IS SELECT * from emp where deptno=v_deptno;
	
	DEPT_NOT_FOUND EXCEPTION;
	
	v_rec emp%ROWTYPE;
	v_count NUMBER :=0;
	v_total NUMBER :=0;
	v_maxSal NUMBER :=0;
	v_avgSal NUMBER :=0;
BEGIN
	OPEN emp_cursor;
	IF emp_cursor%ISOPEN THEN
		
		--IF emp_cursor%FOUND THEN	
			FETCH emp_cursor INTO v_rec;
			LOOP
				DBMS_OUTPUT.PUT_LINE('Employee Name: ' ||v_rec.ename);
				DBMS_OUTPUT.PUT_LINE('Employee Job: ' ||v_rec.job);
				DBMS_OUTPUT.PUT_LINE('Employee Salary: ' ||v_rec.sal);
				DBMS_OUTPUT.PUT_LINE('Employee Commission: ' ||v_rec.comm);
				DBMS_OUTPUT.PUT_LINE('****************************************************');
				v_count:= v_count + 1;
				v_total := v_total + v_rec.sal;
				IF v_rec.sal > v_maxSal THEN
					v_maxSal := v_rec.sal;
				END IF;
				
				FETCH emp_cursor INTO v_rec;
				EXIT WHEN emp_cursor%NOTFOUND;
				
			END LOOP;
			
			v_avgSal := v_total / v_count;
			
			DBMS_OUTPUT.PUT_LINE('Number of Employees : ' || v_count);
			DBMS_OUTPUT.PUT_LINE('Total Salary : ' || v_total);
			DBMS_OUTPUT.PUT_LINE('Maximum Salary :' || v_maxSal);
			DBMS_OUTPUT.PUT_LINE('Average Salary : ' || v_avgSal);
		--ELSE	
		--	RAISE DEPT_NOT_FOUND;
		--END IF;
	END IF;
EXCEPTION
	WHEN DEPT_NOT_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('Department not found.');
END;


---client

DECLARE
	v_deptno emp.deptno%TYPE;

BEGIN
	v_deptno := &deptno;
	print_details(v_deptno);
END;


3.13

Write a query to view the list of all procedures ,functions and packages from the Data
Dictionary.

ans:
SELECT object_name, object_type,created, status from user_objects where OBJECT_TYPe IN ('FUNCTION', 'PROCEDURE' ,'PACKAGE');
