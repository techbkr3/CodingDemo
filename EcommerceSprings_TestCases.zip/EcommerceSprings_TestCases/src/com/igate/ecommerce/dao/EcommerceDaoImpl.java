package com.igate.ecommerce.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.igate.ecommerce.controller.EComController;
import com.igate.ecommerce.dto.Product;
import com.igate.ecommerce.dto.fetchAll;
import com.igate.ecommerce.dto.login;
import com.igate.ecommerce.exception.InvalidOrderProductException;
import com.igate.ecommerce.mappings.AllProductListRowMapper;
import com.igate.ecommerce.mappings.AllSalesListRowMapper;
import com.igate.ecommerce.mappings.CategoryRowMapper;
import com.igate.ecommerce.mappings.RoleRowMapper;

@Repository("dao")
public class EcommerceDaoImpl extends JdbcDaoSupport implements IEcommerceDao {

	private static final Logger ecommLogger = Logger
			.getLogger(EComController.class);
	
	@Autowired
	private DataSource dataSource;

	@PostConstruct
	public void initialize() {
		setDataSource(dataSource);
	}

	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Return all orders placed by customers.
	* Method Name            :allSalesList()
	* Return Type            :ArrayList<fetchAll>
	*****************************************************************************************************************************************************/
	@Override
	public ArrayList<fetchAll> allSalesList()
			throws InvalidOrderProductException {
		
		String salesListQuery = "SELECT * FROM ECOMM_ORDERDETAILS ORD , ECOMM_CUSTOMER CUST,  ECOMM_PRODUCTDETAILS PROD WHERE ((CUST.CUSTOMER_ID=ORD.CUSTOMER_ID) AND (PROD.PRODUCT_ID=ORD.PRODUCT_ID))";
		ArrayList<fetchAll> allSalesList = (ArrayList<fetchAll>) getJdbcTemplate()
				.query(salesListQuery, new AllSalesListRowMapper());
		ecommLogger.info("All orders placed by customers");
		return allSalesList;

	}
	
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Return all pending orders from order table.
	* Method Name            :pendingOrdersList()
	* Return Type            :ArrayList<fetchAll>
	*****************************************************************************************************************************************************/

	@Override
	public ArrayList<fetchAll> pendingOrdersList()
			throws InvalidOrderProductException {
		
		String pendingOrdersQuery = "SELECT * FROM ecomm_orderdetails ord , ecomm_customer cust,  ecomm_productdetails prod where ((cust.customer_id=ord.customer_id) and (prod.product_id=ord.product_id) and ord.order_status=0)";
		ArrayList<fetchAll> pendingOrdersList = (ArrayList<fetchAll>) getJdbcTemplate()
				.query(pendingOrdersQuery, new AllSalesListRowMapper());
		ecommLogger.info("All orders placed by customers which are pending");
		return pendingOrdersList;
	}

	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)		
	* Desc			         :Return all orders placed by customers over a specific period of time.
	* Method Name            :orderByTime(String d1, String d2)
	* Return Type            :ArrayList<fetchAll>
	*****************************************************************************************************************************************************/
	@Override
	public ArrayList<fetchAll> orderByTime(String d1, String d2)
			throws InvalidOrderProductException {
		
		Date sqlDate1 = Date.valueOf(d1);
		Date sqlDate2 = Date.valueOf(d2);

		String orderByTimeQuery = "select * from ecomm_orderdetails ord , ecomm_customer cust,  ecomm_productdetails prod where ((cust.customer_id=ord.customer_id) and (prod.product_id=ord.product_id) and (ord.order_date between ? and ?))";
		Object setDate[] = { sqlDate1, sqlDate2 };
		ArrayList<fetchAll> ordersByTimeList = (ArrayList<fetchAll>) getJdbcTemplate()
				.query(orderByTimeQuery, setDate, new AllSalesListRowMapper());
		//System.out.println(ordersByTimeList);
		ecommLogger.info("All orders placed by customers for particular duration ");
		return ordersByTimeList;
	}
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Return all available products.
	* Method Name            :getProductList()
	* Return Type            :List<Product>
	*****************************************************************************************************************************************************/
	
	@Override
	public List<Product> getProductList() throws InvalidOrderProductException {
		String productListQuery = "SELECT product_id,product_name,product_price,product_quantity,product_categoryname,product_specs,product_desc FROM ecomm_productdetails";
		ArrayList<Product> allProductList = (ArrayList<Product>) getJdbcTemplate()
				.query(productListQuery, new AllProductListRowMapper());
		ecommLogger.info("To Display All Product details");
		return allProductList;
	}
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)		
	* Desc			         :Update product details.
	* Method Name            :updateProduct(Product prod)
	* Return Type            :int
	*****************************************************************************************************************************************************/
	@Override
	public int updateProduct(Product prod) throws InvalidOrderProductException {
		// System.out.println(prod);
		String updateQuery = "UPDATE ecomm_productdetails SET product_name=?,product_price=?,product_quantity=?,product_categoryname=?,product_specs=?,product_desc=? WHERE product_id=?";
		Object[] param = new Object[] { prod.getProduct_name(),
				prod.getProduct_price(), prod.getProduct_quantity(),
				prod.getProduct_category(), prod.getProduct_specs(),
				prod.getProduct_desc(), prod.getProduct_id() };

		int updateRow = getJdbcTemplate().update(updateQuery, param);
		// System.out.println("Before ending");
		ecommLogger.info("Updating Product details");
		return updateRow;
	}

	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Fetch product details based on product id.
	* Method Name            :getProductDetail(int id)
	* Return Type            :Product
	*****************************************************************************************************************************************************/
	@Override
	public Product getProductDetail(int id) throws InvalidOrderProductException {
		String query = "SELECT product_id,product_name,product_price,product_quantity,product_categoryname,product_specs,product_desc FROM ecomm_productdetails WHERE product_id="
				+ id;

		List<Product> product = getJdbcTemplate().query(query,
				new AllProductListRowMapper());
		ecommLogger.info("Fetching Product details based on product Id");
		return product.get(0);
	}
	
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Delete product details based on product id.
	* Method Name            :deleteData(int id)
	* Return Type            :int
	*****************************************************************************************************************************************************/

	@Override
	public int deleteData(int id) throws InvalidOrderProductException {
		String sql = "DELETE FROM ecomm_productdetails WHERE product_id=" + id;
		int delete = getJdbcTemplate().update(sql);
		ecommLogger.info("Deleting particular product");
		return delete;

	}
	
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)		
	* Desc			         :Add product details into product table.
	* Method Name            :insertProduct(Product prod)
	* Return Type            :int
	*****************************************************************************************************************************************************/

	@Override
	public int insertProduct(Product prod) throws InvalidOrderProductException {
		String insertQuery = "INSERT INTO ecomm_productdetails VALUES(product_seq.NEXTVAL,?,?,?,?,?,?)";
		Object[] param = new Object[] { prod.getProduct_name(),
				prod.getProduct_price(), prod.getProduct_quantity(),
				prod.getProduct_category(), prod.getProduct_specs(),
				prod.getProduct_desc() };
		int insertRow = getJdbcTemplate().update(insertQuery, param);
		ecommLogger.info("Adding Product to Database");
		return insertRow;
	}

	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)	
	* Desc			         :Return list of categories from category table.
	* Method Name            :getcategory()
	* Return Type            :List<ArrayList<String>>
	*****************************************************************************************************************************************************/
	@Override
	public List<ArrayList<String>> getcategory()
			throws InvalidOrderProductException {
		String selectQuery = "SELECT category_name FROM ecomm_category";
		List<ArrayList<String>> categoryList = getJdbcTemplate().query(
				selectQuery, new CategoryRowMapper());
		ecommLogger.info("Fetching Categories");
		return categoryList;
	}
	
	/*******************************************************************************************************************************************************
	* File				     :EcommerceDaoImpl(Ecommerce Project)		
	* Desc			         :checking whether login credentials are valid or not.
	* Method Name            :loginModule(login loginmod)
	* Return Type            :int
	*****************************************************************************************************************************************************/

	@Override
	public int loginModule(login loginmod) throws InvalidOrderProductException {
		
		String sql = "SELECT USERNAME,PASSWORD,ROLE FROM ECOMM_LOGIN WHERE USERNAME=? AND PASSWORD=?";

		Object param[] = { loginmod.getUserName(), loginmod.getPassword() };
		String un = loginmod.getUserName();
		ArrayList<login> result = (ArrayList<login>) getJdbcTemplate().query(
				sql, param, new RoleRowMapper());
		ecommLogger.info("Checking Login Credentials");
		if(!result.isEmpty()){
		login log = result.get(0);
		String role = log.getRole();
		if(role.equalsIgnoreCase("sales")){
			
			return 1;
		}else if (role.equalsIgnoreCase("admin")){
			return 2;
		}else{
			return 0;
		}
		}else{
			return 0;
		}
	}
}
