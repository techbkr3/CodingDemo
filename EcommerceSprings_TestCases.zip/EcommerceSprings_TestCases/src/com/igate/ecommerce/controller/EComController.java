package com.igate.ecommerce.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.igate.ecommerce.dto.Product;
import com.igate.ecommerce.dto.fetchAll;
import com.igate.ecommerce.dto.login;
import com.igate.ecommerce.exception.InvalidOrderProductException;
import com.igate.ecommerce.service.IEcommerceService;

@Controller
public class EComController {

	@Autowired
	IEcommerceService service;

	private static final Logger ecommLogger = Logger
			.getLogger(EComController.class);

	@RequestMapping(value = "/loginHome", method = RequestMethod.GET)
	public String loginHome(Model model) {

		model.addAttribute("loginModule", new login());
		ecommLogger.info("Redirecting to Login Page");
		return "loginModule";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String loginModule(
			@Valid @ModelAttribute("loginModule") login login,
			BindingResult br, HttpServletRequest request,
			HttpServletResponse response) {
		if (br.hasErrors()) {
			ecommLogger.info("Redirecting to Login Page");
			return "loginModule";
		} else {
			HttpSession session = request.getSession();
			int result;
			try {
				result = service.loginModule(login);
				
				if (result == 1) {
					session.setAttribute("manager", "Sales Manager");
					ecommLogger
							.info("Redirecting to Sales Home Page after Login");
					return "salesHome";
				} else if (result == 2) {
					session.setAttribute("manager", "Admin Manager");
					ecommLogger
							.info("Redirecting to Admin Home Page after Login");
					return "ShowAll";
				} else {
					session.setAttribute("loginError",
							"Invalid Login Username/Password");
					return "index";
				}

			} catch (DataAccessException | InvalidOrderProductException e) {
				ecommLogger.error("Redirecting to Error Page" + e.getMessage());
				return "error";
			}
		}
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutSession(HttpServletRequest request,
			HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		session.invalidate();
		ecommLogger.info("Redirecting to Login Page after Logout");
		return "index";
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String homePage() {
		ecommLogger
				.info("Redirecting to Admin Home Page after clicking on Home");
		return "ShowAll";
	}

	@RequestMapping(value = "/showSalesHome", method = RequestMethod.GET)
	public String salesHomePage() {
		ecommLogger
				.info("Redirecting to Sales Manager Home Page after Clicking on Home");
		return "salesHome";
	}

	@RequestMapping(value = "/fetchAll", method = RequestMethod.GET)
	public ModelAndView fetchAll() {
		ArrayList<fetchAll> allSalesList;
		try {
			allSalesList = service.allSalesList();
			ecommLogger.info("Redirecting to allOrders Page");
			return new ModelAndView("allOrders", "allSalesList", allSalesList);
		} catch (DataAccessException | InvalidOrderProductException e) {
			
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error", "msg",
					"Sorry, NO SALES LIST FOUND");
		}

	}

	@RequestMapping(value = "/pendingOrders", method = RequestMethod.GET)
	public ModelAndView fetchPendingOrders() {
		ArrayList<fetchAll> pendingOrdersList;

		try {
			pendingOrdersList = service.pendingOrdersList();
			ecommLogger.info("Redirecting to pendingOrders Page");
			return new ModelAndView("pendingOrders", "pendingOrders",
					pendingOrdersList);

		} catch (DataAccessException | InvalidOrderProductException e) {
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error", "msg",
					"Sorry, NO SALES LIST FOUND");
		}

	}

	@RequestMapping(value = "/orderByTime", method = RequestMethod.GET)
	public String orderTime() {
		ecommLogger.info("Redirecting to Enter Date Page");
		return "orderByTime";
	}

	@RequestMapping(value = "/orderByTime", method = RequestMethod.POST)
	public ModelAndView orderByTime(@Valid @RequestParam("date1") String date1,
			@RequestParam("date2") String date2) {
		
		ArrayList<fetchAll> orderByTimeList;
		try {
			
			orderByTimeList = service.orderByTime(date1, date2);
		
			ecommLogger.info("Redirecting to orderByTime Page");
			return new ModelAndView("showOrderByTime", "orderByTime",
					orderByTimeList);

		} catch (DataAccessException | InvalidOrderProductException e) {
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error", "msg",
					"Sorry, NO SALES LIST FOUND");
		}

	}

	@RequestMapping(value = "/showAll", method = RequestMethod.GET)
	public String showAll() {
		ecommLogger.info("Redirecting to Admin Home Page");
		return "ShowAll";
	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.GET)
	public String showAddProduct(Model model) {
		try {
			List<ArrayList<String>> categoryList = service.getcategory();
			model.addAttribute("categoryList", categoryList);
			model.addAttribute("productDetail", new Product());
			ecommLogger.info("Redirecting to Add Product Page");
			return "AddProduct";
		} catch (InvalidOrderProductException e) {

			model.addAttribute("msg", "No Category Found");
			ecommLogger.error("Redirecting to Error Page");
			return "error";
		}

	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String insertProduct(
			@Valid @ModelAttribute("productDetail") Product product,
			BindingResult br, Model model) {
		if (br.hasErrors()) {
			List<ArrayList<String>> categoryList;
			try {
				categoryList = service.getcategory();
				model.addAttribute("categoryList", categoryList);
				ecommLogger
						.info("Redirecting to Add Product after checking validations Page");
				return "AddProduct";
			} catch (InvalidOrderProductException e) {
				
				ecommLogger.error("Redirecting to Error Page");
				return "error";
			}

		} else {
			try {
				
				int result = service.insertProduct(product);
				if (result != 0) {
					model.addAttribute("details", "Details Added SuccessFully");
					ecommLogger
							.info("Redirecting to product added successfully Page");
					return "Success";
				} else {
					model.addAttribute("details", "Details Added SuccessFully");
					ecommLogger.info("Redirecting to product not added Page");
					return "failure";
				}
			} catch (DataAccessException | InvalidOrderProductException e) {
			
				ecommLogger.error("Redirecting to Error Page");
				return "error";
			}

		}
	}

	@RequestMapping(value = "/showProductList", method = RequestMethod.GET)
	public ModelAndView fetchAllProduct() {
		List<Product> allProductList;
		try {
			allProductList = service.getProductList();
			ecommLogger.info("Redirecting to Display All Product Page");
			return new ModelAndView("allProducts", "allProductList",
					allProductList);
		} catch (DataAccessException | InvalidOrderProductException e) {
			
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error", "msg",
					"Sorry, NO PRODUCT LIST FOUND");
		}

	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public String getData(@RequestParam("id") int jid, Map<String, Object> model) {
		Product myprod;
		try {
			myprod = service.getProductDetail(jid);
			model.put("productDetail", myprod);
			ecommLogger.info("Redirecting to update Product Details Page");
			return "Update";
		} catch (DataAccessException | InvalidOrderProductException e) {
			
			ecommLogger.error("Redirecting to Error Page");
			return "error";
		}

	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updateData(
			@ModelAttribute("productDetail") Product product, Model model) {
		
		List<Product> allProductList;
		try {
			
			int update = service.updateProduct(product);
			
			if (update != 0) {
				allProductList = service.getProductList();
				ecommLogger
						.info("Redirecting to Display all Product Details Page");
				return new ModelAndView("allProducts", "allProductList",
						allProductList);
			} else {

				return new ModelAndView("failure");
			}
		} catch (DataAccessException | InvalidOrderProductException e) {
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error");
		}

	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView deleteData(@RequestParam("id") int id,
			HttpServletRequest request, HttpServletResponse response) {
		List<Product> allProductList;
		try {
			HttpSession session = request.getSession(false);
			String manager = (String) session.getAttribute("manager");
			if (manager.equals("Admin Manager")) {
				int del = service.deleteData(id);
				if (del != 0) {
					allProductList = service.getProductList();
					ecommLogger
							.info("Redirecting to Dispaly All Product Details Page");
					return new ModelAndView("allProducts", "allProductList",
							allProductList);
				} else {

					return new ModelAndView("failure");
				}
			} else {
				ecommLogger.info("Redirecting to Login Page");
				return new ModelAndView("index");
			}

		} catch (DataAccessException | InvalidOrderProductException e) {
			ecommLogger.error("Redirecting to Error Page");
			return new ModelAndView("error");
		}

	}


}
