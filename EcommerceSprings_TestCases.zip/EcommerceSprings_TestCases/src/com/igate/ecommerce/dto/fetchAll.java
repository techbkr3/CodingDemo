package com.igate.ecommerce.dto;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

@Component
public class fetchAll {
	private int customer_id;
	private String customer_emailid;
	private String customer_address;
	private String customer_city;
	private String customer_state;
	private int customer_pincode;
	
	private int product_id;
	private String product_name;
	private float product_price;
	private String product_category;
	
	private int order_id;
	private LocalDate order_date;
	private int order_quantity;
	private float order_totalAmount;
	private int order_status;
	public int getOrder_status() {
		return order_status;
	}
	public void setOrder_status(int order_status) {
		this.order_status = order_status;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_emailid() {
		return customer_emailid;
	}
	public void setCustomer_emailid(String customer_emailid) {
		this.customer_emailid = customer_emailid;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	public String getCustomer_city() {
		return customer_city;
	}
	public void setCustomer_city(String customer_city) {
		this.customer_city = customer_city;
	}
	public String getCustomer_state() {
		return customer_state;
	}
	public void setCustomer_state(String customer_state) {
		this.customer_state = customer_state;
	}
	public int getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(int customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public float getProduct_price() {
		return product_price;
	}
	public void setProduct_price(float product_price) {
		this.product_price = product_price;
	}
	public String getProduct_category() {
		return product_category;
	}
	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public LocalDate getOrder_date() {
		return order_date;
	}
	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}
	public int getOrder_quantity() {
		return order_quantity;
	}
	public void setOrder_quantity(int order_quantity) {
		this.order_quantity = order_quantity;
	}
	public float getOrder_totalAmount() {
		return order_totalAmount;
	}
	public void setOrder_totalAmount(float order_totalAmount) {
		this.order_totalAmount = order_totalAmount;
	}
	@Override
	public String toString() {
		return "fetchAll [customer_id=" + customer_id + ", customer_emailid="
				+ customer_emailid + ", customer_address=" + customer_address
				+ ", customer_city=" + customer_city + ", customer_state="
				+ customer_state + ", customer_pincode=" + customer_pincode
				+ ", product_id=" + product_id + ", product_name="
				+ product_name + ", product_price=" + product_price
				+ ", product_category=" + product_category + ", order_id="
				+ order_id + ", order_date=" + order_date + ", order_quantity="
				+ order_quantity + ", order_totalAmount=" + order_totalAmount
				+ ", order_status=" + order_status + "]";
	}
	
	
	
	
	
}
