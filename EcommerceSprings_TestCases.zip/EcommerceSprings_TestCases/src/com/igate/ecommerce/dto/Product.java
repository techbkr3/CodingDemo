package com.igate.ecommerce.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class Product {
	private int product_id;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "Enter only characters")
	private String product_name;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[1-9][0-9]{0,6}$", message = "enter 7 figure price")
	private String product_price;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[1-9][0-9]*$", message = "enter only digits")
	private String product_quantity;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Enter only characters")
	private String product_category;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "Enter only characters")
	private String product_specs;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[a-zA-Z0-9 ]+$", message = "Enter only characters")
	private String product_desc;

	public Product() {
		super();
	}

	public Product(int product_id, String product_name, String product_price,
			String product_quantity, String product_category,
			String product_specs, String product_desc) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_quantity = product_quantity;
		this.product_category = product_category;
		this.product_specs = product_specs;
		this.product_desc = product_desc;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_price() {
		return product_price;
	}

	public void setProduct_price(String product_price) {
		this.product_price = product_price;
	}

	public String getProduct_quantity() {
		return product_quantity;
	}

	public void setProduct_quantity(String product_quantity) {
		this.product_quantity = product_quantity;
	}

	public String getProduct_category() {
		return product_category;
	}

	public void setProduct_category(String product_category) {
		this.product_category = product_category;
	}

	public String getProduct_specs() {
		return product_specs;
	}

	public void setProduct_specs(String product_specs) {
		this.product_specs = product_specs;
	}

	public String getProduct_desc() {
		return product_desc;
	}

	public void setProduct_desc(String product_desc) {
		this.product_desc = product_desc;
	}

	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name="
				+ product_name + ", product_price=" + product_price
				+ ", product_quantity=" + product_quantity
				+ ", product_category=" + product_category + ", product_specs="
				+ product_specs + ", product_desc=" + product_desc + "]";
	}

}
