package com.igate.ecommerce.dto;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class Customer {
	private int customer_id;
	@NotEmpty(message = "field cannot be left blank")
	@Email(message="Enter Valid Email Id")
	private String customer_emailid;
	@NotEmpty(message = "field cannot be left blank")
	private String customer_password;
	@NotEmpty(message = "field cannot be left blank")
	private String customer_address;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp="^[a-zA_Z]+$",message="Enter only characters")
	private String customer_city;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp="^[a-zA_Z]+$",message="Enter only characters")
	private String customer_state;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp="^[1-9][0-9]{6,7}$",message="Enter valid Pincode")
	private String customer_pincode;
	@NotEmpty(message = "field cannot be left blank")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Enter only characters")
	private String customer_name;
	
	private String customer_accountStatus;
	
	
	
	public Customer(String customer_emailid, String customer_password,
			String customer_address, String customer_city,
			String customer_state, String customer_pincode, String customer_name) {
		super();
		this.customer_emailid = customer_emailid;
		this.customer_password = customer_password;
		this.customer_address = customer_address;
		this.customer_city = customer_city;
		this.customer_state = customer_state;
		this.customer_pincode = customer_pincode;
		this.customer_name = customer_name;
	}
	
	
	
	public Customer(String customer_emailid, String customer_password) {
		super();
		this.customer_emailid = customer_emailid;
		this.customer_password = customer_password;
	}



	public Customer() {
		// TODO Auto-generated constructor stub
		super();
	}

	public String getCustomer_accountStatus() {
		return customer_accountStatus;
	}

	public void setCustomer_accountStatus(String customer_accountStatus) {
		this.customer_accountStatus = customer_accountStatus;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_emailid() {
		return customer_emailid;
	}
	public void setCustomer_emailid(String customer_emailid) {
		this.customer_emailid = customer_emailid;
	}
	public String getCustomer_password() {
		return customer_password;
	}
	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	public String getCustomer_city() {
		return customer_city;
	}
	public void setCustomer_city(String customer_city) {
		this.customer_city = customer_city;
	}
	public String getCustomer_state() {
		return customer_state;
	}
	public void setCustomer_state(String customer_state) {
		this.customer_state = customer_state;
	}
	public String getCustomer_pincode() {
		return customer_pincode;
	}
	public void setCustomer_pincode(String customer_pincode) {
		this.customer_pincode = customer_pincode;
	}
	
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_emailid="
				+ customer_emailid + ", customer_password=" + customer_password
				+ ", customer_address=" + customer_address + ", customer_city="
				+ customer_city + ", customer_state=" + customer_state
				+ ", customer_pincode=" + customer_pincode
				 + "]";
	}	

}
