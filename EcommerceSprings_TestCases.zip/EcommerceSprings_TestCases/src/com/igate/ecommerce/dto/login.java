package com.igate.ecommerce.dto;


import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class login {
	@NotEmpty(message = "field cannot be left blank")
	@Email(message="Enter Valid Email Id")
	private String userName;
	@NotEmpty(message = "field cannot be left blank")
	private String password;
	private String role;
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "login [userName=" + userName + ", password=" + password
				+ ", role=" + role + "]";
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public login() {
		super();
		
	}
	public login(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	
}
