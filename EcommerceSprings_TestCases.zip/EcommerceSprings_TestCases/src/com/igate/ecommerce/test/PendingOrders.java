package com.igate.ecommerce.test;

import static org.junit.Assert.*;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.constraints.AssertTrue;

import jdk.nashorn.internal.ir.annotations.Ignore;






import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

 
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.igate.ecommerce.dao.IEcommerceDao;
import com.igate.ecommerce.dto.Product;
import com.igate.ecommerce.dto.fetchAll;
import com.igate.ecommerce.exception.InvalidOrderProductException;
import com.igate.ecommerce.service.IEcommerceService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("dao.xml")
public class PendingOrders {
	
	@Autowired
	IEcommerceDao dao;

	@Test
	@Ignore
	public void test() throws InvalidOrderProductException {

		ArrayList<fetchAll> pendingOrdersList = null;
		try {
			pendingOrdersList = dao.pendingOrdersList();
			int expected=pendingOrdersList.get(1).getOrder_status();
			
			if(expected==0){
				assertTrue(true);
			}
			else
			{
				assertTrue(false);
			}
			System.out.println(pendingOrdersList);

		} catch (DataAccessException | InvalidOrderProductException e) {
			System.out.println(e.getMessage());
		}

	}
	
	@Test
	@Ignore
	public void deleteProduct() throws SQLException {
		try{
			
			assertNotNull(dao.deleteData(9091));
			}catch(InvalidOrderProductException e){
				fail("failure");
			}
	}
	@Test
	@Ignore
	public void addproduct() throws SQLException{
		Product productObj=new Product();
		try{
			productObj.setProduct_id(10001);
			productObj.setProduct_name("Nokia 1100");
			productObj.setProduct_category("Mobile");
			productObj.setProduct_price("1000");
			productObj.setProduct_quantity("2");
			productObj.setProduct_specs("Octacore Processor");
			productObj.setProduct_desc("Best Phone in Market");
			assertNotNull(dao.insertProduct(productObj));
			
		}catch(InvalidOrderProductException e){
			fail("failure");
		}
	}
	@Test
	@Ignore
	public void updateProduct() throws SQLException{
		Product productObj=new Product();
		try{
			productObj.setProduct_id(9123);
			productObj.setProduct_name("Nokia 1100");
			productObj.setProduct_category("Mobile");
			productObj.setProduct_price("1000");
			productObj.setProduct_quantity("2");
			productObj.setProduct_specs("dual Processor");
			productObj.setProduct_desc("Pooraanaa Phone in Market");
			assertNotNull(dao.updateProduct(productObj));
			
		}catch(InvalidOrderProductException e){
			fail("failure");
		}
	}
	@Test
	@Ignore
	public void allOrders() throws InvalidOrderProductException {

		ArrayList<fetchAll> allOrders = null;
		try {
			allOrders = dao.allSalesList();
				
			if(allOrders!=null){
				assertTrue(true);
			}
			else
			{
				assertTrue(false);
			}
			System.out.println(allOrders);

		} catch (DataAccessException | InvalidOrderProductException e) {
			System.out.println(e.getMessage());
		}

	}
	@Test
	public void orderByTime()throws InvalidOrderProductException {

		ArrayList<fetchAll> timeOrder = null;
		try {
			String date1= "2016-01-01";
			String date2= "2016-01-20";
			
			timeOrder= dao.orderByTime(date1,date2);
				
			if(timeOrder!=null){
				assertTrue(true);
			}
			else
			{
				assertTrue(false);
			}
			System.out.println(timeOrder);

		} catch (DataAccessException | InvalidOrderProductException e) {
			System.out.println(e.getMessage());
		}

	}


}
