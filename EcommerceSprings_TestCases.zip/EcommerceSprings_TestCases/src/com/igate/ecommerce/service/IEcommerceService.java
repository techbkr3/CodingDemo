package com.igate.ecommerce.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.igate.ecommerce.dto.Product;
import com.igate.ecommerce.dto.fetchAll;
import com.igate.ecommerce.dto.login;
import com.igate.ecommerce.exception.InvalidOrderProductException;

public interface IEcommerceService {

	public ArrayList<fetchAll> allSalesList()
			throws InvalidOrderProductException;

	public ArrayList<fetchAll> pendingOrdersList()
			throws InvalidOrderProductException;
	
	public ArrayList<fetchAll> orderByTime(String d1,String d2)
			throws InvalidOrderProductException;

	public int insertProduct(Product prod) throws InvalidOrderProductException;

	public List<Product> getProductList() throws InvalidOrderProductException;

	public Product getProductDetail(int id) throws InvalidOrderProductException;

	public int updateProduct(Product prod) throws InvalidOrderProductException;

	public int deleteData(int id) throws InvalidOrderProductException;

	public List<ArrayList<String>> getcategory()
			throws InvalidOrderProductException;
	public int loginModule(login loginmod)throws InvalidOrderProductException;
}
