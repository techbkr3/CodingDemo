package com.igate.ecommerce.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.ecommerce.dao.IEcommerceDao;
import com.igate.ecommerce.dto.Product;
import com.igate.ecommerce.dto.fetchAll;
import com.igate.ecommerce.dto.login;
import com.igate.ecommerce.exception.InvalidOrderProductException;

@Service
public class EcommerceServiceImpl implements IEcommerceService {
	
	@Autowired
	IEcommerceDao dao;

	@Override
	public ArrayList<fetchAll> allSalesList()
			throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.allSalesList();
	}

	@Override
	public ArrayList<fetchAll> pendingOrdersList()
			throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.pendingOrdersList();
	}
	@Override
	public List<Product> getProductList() throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.getProductList();
	}

	@Override
	public int updateProduct(Product prod) throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.updateProduct(prod);
	}

	@Override
	public Product getProductDetail(int id) throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.getProductDetail(id);
	}

	@Override
	public int deleteData(int id) throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.deleteData(id);
	}

	@Override
	public int insertProduct(Product prod) throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.insertProduct(prod);
	}

	@Override
	public List<ArrayList<String>> getcategory()
			throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.getcategory();
	}

	@Override
	public ArrayList<fetchAll> orderByTime(String d1, String d2)
			throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.orderByTime(d1, d2);
	}

	@Override
	public int loginModule(login loginmod) throws InvalidOrderProductException {
		// TODO Auto-generated method stub
		return dao.loginModule(loginmod);
	}


}
