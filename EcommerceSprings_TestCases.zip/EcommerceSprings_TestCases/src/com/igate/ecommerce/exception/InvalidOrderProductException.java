package com.igate.ecommerce.exception;

public class InvalidOrderProductException extends Exception {
	public InvalidOrderProductException(String msg) {
		super(msg);
	}

}
