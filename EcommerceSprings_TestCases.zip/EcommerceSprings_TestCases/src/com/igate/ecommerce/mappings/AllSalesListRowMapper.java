package com.igate.ecommerce.mappings;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import org.springframework.jdbc.core.RowMapper;

import com.igate.ecommerce.dto.fetchAll;

public class AllSalesListRowMapper implements RowMapper<fetchAll> {

	@Override
	public fetchAll mapRow(ResultSet rs, int count) throws SQLException {
		fetchAll salesList = new fetchAll();
		salesList.setCustomer_id(rs.getInt("customer_id"));
		salesList.setCustomer_emailid(rs.getString("customer_emailid"));
		salesList.setCustomer_address(rs.getString("customer_address"));
		salesList.setCustomer_city(rs.getString("customer_city"));
		salesList.setCustomer_state(rs.getString("customer_state"));
		salesList.setCustomer_pincode(rs.getInt("customer_pincode"));
		salesList.setOrder_id(rs.getInt("order_id"));
		salesList.setOrder_quantity(rs.getInt("order_quantity"));
		salesList.setOrder_totalAmount(rs.getFloat("order_totalamount"));
		salesList.setOrder_status(rs.getInt("order_status"));
		Date d = rs.getDate("order_date");
		LocalDate l = d.toLocalDate();
		salesList.setOrder_date(l);
		salesList.setProduct_id(rs.getInt("product_id"));
		salesList.setProduct_name(rs.getString("product_name"));
		salesList.setProduct_category(rs.getString("product_categoryname"));
		salesList.setProduct_price(rs.getInt("product_price"));
		return salesList;		
	}

}
