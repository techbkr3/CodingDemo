package com.igate.ecommerce.mappings;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;

import com.igate.ecommerce.dto.login;

public class RoleRowMapper  implements RowMapper<login> {

	@Override
	public login mapRow(ResultSet res, int count) throws SQLException {
		//System.out.println("sdfsdagf");
		login loginObj=new login();
		loginObj.setUserName(res.getString("username"));
		loginObj.setPassword(res.getString("password"));
		loginObj.setRole(res.getString("role"));
		//System.out.println("sdfsdagf"+loginObj);
		return loginObj;
	}

}
