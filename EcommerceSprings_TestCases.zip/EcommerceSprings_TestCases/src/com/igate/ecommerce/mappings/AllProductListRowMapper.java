package com.igate.ecommerce.mappings;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.ecommerce.dto.Product;


public class AllProductListRowMapper implements RowMapper<Product> {

	@Override
	public Product mapRow(ResultSet res, int count) throws SQLException {
		Product product=new Product();
		product.setProduct_id(res.getInt("product_id"));
		product.setProduct_name(res.getString("product_name"));
		product.setProduct_price(res.getString("product_price"));
		product.setProduct_quantity(res.getString("product_quantity"));
		product.setProduct_category(res.getString("product_categoryname"));
		product.setProduct_specs(res.getString("product_specs"));
		product.setProduct_desc(res.getString("product_desc"));
		return product;
	}

	
}
