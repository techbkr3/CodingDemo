package com.igate.employee.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.employee.dao.IEmployeeDao;
import com.igate.employee.dto.Employee;
@Service("ser")
public class EmployeeServiceImpl implements IEmployeeService {
@Autowired
IEmployeeDao dao;
	
	@Override
	public int insertEmp(Employee emp) {
		// TODO Auto-generated method stub
		return dao.insertEmp(emp);
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return dao.getEmployees();
	}

}
