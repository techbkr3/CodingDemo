package com.igate.employee.dto;

import java.util.Date;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class Employee {
	@NotEmpty(message="Enter your Name")
	@Pattern(regexp="^[a-zA-Z]+$",message="Enter only Characters")
	String empName;
	@NotEmpty(message="Enter your Email Id")
	@Pattern(regexp="^[a-zA-Z]+\\.[a-zA-Z]+\\@[a-zA-Z]+\\.[a-zA-Z]{2,3}$",message="Enter Valid Email Id")
	String empmail;
	@NotEmpty(message="Enter your Date of birth")
	
	String dob;
	@NotEmpty(message="Enter your salary")
	String empsal;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpmail() {
		return empmail;
	}
	public void setEmpmail(String empmail) {
		this.empmail = empmail;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmpsal() {
		return empsal;
	}
	public void setEmpsal(String empsal) {
		this.empsal = empsal;
	}
	
}
