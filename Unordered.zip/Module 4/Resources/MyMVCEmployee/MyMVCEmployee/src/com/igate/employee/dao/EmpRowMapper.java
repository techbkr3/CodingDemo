package com.igate.employee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.igate.employee.dto.Employee;

public class EmpRowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet res, int count) throws SQLException {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.setEmpName(res.getString("EMPNAME"));
		emp.setEmpmail(res.getString("EMPMAIL"));
		emp.setDob(res.getString("EMPDOB"));
		emp.setEmpsal(res.getString("EMPSAL"));
		return emp;
	}

}
