package com.igate.employee.service;

import java.util.ArrayList;

import com.igate.employee.dto.Employee;

public interface IEmployeeService {
	public int insertEmp(Employee emp);
	
	public ArrayList<Employee> getEmployees();
}
