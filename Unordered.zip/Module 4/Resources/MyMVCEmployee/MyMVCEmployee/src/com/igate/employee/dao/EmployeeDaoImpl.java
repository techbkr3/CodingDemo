package com.igate.employee.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.igate.employee.dto.Employee;
@Repository("dao")
public class EmployeeDaoImpl extends JdbcDaoSupport implements IEmployeeDao {
	
	@Autowired
	DataSource dataSource;
	@PostConstruct
	public void initialize(){
		setDataSource(dataSource);
	}
	
	@Override
	public int insertEmp(Employee emp) {
		String query="insert into emp23 values(?,?,?,?) ";
		String dob=emp.getDob();
		DateTimeFormatter d=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate l=LocalDate.parse(dob,d);
		Date d1=Date.valueOf(l);
		Object params[]={emp.getEmpName(),emp.getEmpmail(),d1,Float.parseFloat(emp.getEmpsal())};
		int result=getJdbcTemplate().update(query,params);
		return result;
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		String fetchSql="select * from emp23";
		ArrayList<Employee> details=(ArrayList<Employee>) getJdbcTemplate().query(fetchSql,new EmpRowMapper());
		
		return details;
	}
}
