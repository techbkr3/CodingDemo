package com.igate.employee.controller;

import java.util.ArrayList;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.employee.dto.Employee;
import com.igate.employee.service.IEmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	IEmployeeService service;

	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String homePage(){
		return "homePage";
	}
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String register(@ModelAttribute("employeeForm") Employee emp){
		return "Register";
	}
	
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public String myRegister(@Valid@ModelAttribute("employeeForm") Employee emp,BindingResult result)
	{
		if(result.hasErrors())
		{
			return "Register";
		}
		else
		{
			int res=service.insertEmp(emp);
			if(res!=0)
			{
				return "success";
			}
			else
			{
				return "failure";
			}
			
			
		}
	}
	
	@RequestMapping(value="/showall",method=RequestMethod.GET)
	public String getDetails(Model model){
		try{
			
		ArrayList<Employee> emp=service.getEmployees();
		if(emp!=null){
			model.addAttribute("emps", emp);
			return "showAll";
		}
		else{
			model.addAttribute("details", "no details are fetched");
			return "error";
		}
		
		
		}catch(DataAccessException e){
			model.addAttribute("details", e.getMessage());
			return "error";
		}
		
	}
	
	
	
	
}
