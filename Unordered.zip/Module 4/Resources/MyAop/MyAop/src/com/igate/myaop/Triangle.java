package com.igate.myaop;

public class Triangle {
	String name;

	public String getName() {
		throw new RuntimeException();
		
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
