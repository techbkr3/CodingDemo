package com.igate.myaop;

public class MyMain {
		
}
