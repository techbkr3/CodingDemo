package com.igate.myaop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoginService {
	
	@Before("getPoint()")
	//@Before("execution(* * get*())")
	public void getLogin(){
		System.out.println("Login before........");
	}
	@Pointcut("execution(public String getName())")
	public void getPoint(){
		System.out.println("Point Cut......");
	}
	
}
