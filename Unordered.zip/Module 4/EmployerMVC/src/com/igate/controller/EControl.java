package com.igate.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.dto.Employee;
import com.igate.service.IEmployeeService;

@Controller
public class EControl {
	
	@Autowired
	IEmployeeService service;
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("eDetails") Employee eDetails)
	{
		return "add";
	}
	
	@RequestMapping(value={"/addEmp"},method=RequestMethod.POST)
	public String addEmployees(@ModelAttribute("eDetails") Employee eDetails)
	{
		int rows = service.addEmployee(eDetails);
		if (rows>0)
		{
		return "success";
		}
		else
		{
			return "failure";	
		}
	}
	
	@RequestMapping(value="/showEmployee",method=RequestMethod.GET)
	public String getDetails(Model model){
		try{
			
		ArrayList<Employee> emp=service.getEmployees();
		if(emp!=null){
			model.addAttribute("emps", emp);
			return "list";
		}
		else{
			model.addAttribute("details", "no details are fetched");
			return "error";
		}
		
		
		}catch(DataAccessException e){
			model.addAttribute("details", e.getMessage());
			return "error";
		}
		
	}


}
