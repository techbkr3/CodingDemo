package com.igate.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.dao.IEmployeeDAO;
import com.igate.dto.Employee;

@Service("service")
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	IEmployeeDAO dao;

	@Override
	public int addEmployee(Employee eDetails) {
		// TODO Auto-generated method stub
		return dao.addEmployee(eDetails);
	}

	@Override
	public ArrayList<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return dao.getEmployees();
	}

}
