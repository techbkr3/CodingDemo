package com.igate.app.controller;

public class AppController {

}
