package com.igate.app.service;

public interface IAppService {

}
