package com.igate.app.dao;

public class AppDAOImpl implements IAppDAO {

}
