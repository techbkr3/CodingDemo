package com.igate.app.service;

public class AppServiceImpl implements IAppService {

}
