package com.igate.app.dto;

public class User {

}
