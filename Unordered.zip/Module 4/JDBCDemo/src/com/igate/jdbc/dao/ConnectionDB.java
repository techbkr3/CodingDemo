package com.igate.jdbc.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.igate.jdbc.dto.Employee;


@Component("conn")
public class ConnectionDB implements IConnectionDB {
	@Autowired
	DataSource datas;

	public DataSource getDatas() {
		return datas;
	}

	public void setDatas(DataSource datas) {
		this.datas = datas;
	}

	@Override
	public int addDate(Employee emp) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO MYEMP VALUES (?,?,?)";
		JdbcTemplate jd = new JdbcTemplate(datas);	
		Object param[] = new Object[]{emp.getEmpId(),emp.getEmpName(),emp.getEmpSalary()};
		return jd.update(query, param);
	}

	@Override
	public List<Employee> getDate() {
		// TODO Auto-generated method stub
		String queryo = "Select * from myemp";
		JdbcTemplate jd = new JdbcTemplate(datas);
		List<Employee> empList = jd.query(queryo, new EmployeeRowMapper());
		return empList;
	}
	
	

}
