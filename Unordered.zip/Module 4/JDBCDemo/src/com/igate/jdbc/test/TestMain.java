package com.igate.jdbc.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.igate.jdbc.controller.EmployeeController;
import com.igate.jdbc.dto.Employee;

public class TestMain {
	
	public static void main(String[] args) {
		
		ApplicationContext a = new ClassPathXmlApplicationContext("springjdbc.xml");
		
		EmployeeController e = (EmployeeController) a.getBean("cont");
//		int check = e.addDataEmployee(1001,"IGATE",23105);
//		System.out.println(check);
		List<Employee> eo = e.getDate();
		for(Employee emp:eo)
		{
			System.out.println(emp.getEmpId());
			System.out.println(emp.getEmpName());
		}
	}
}