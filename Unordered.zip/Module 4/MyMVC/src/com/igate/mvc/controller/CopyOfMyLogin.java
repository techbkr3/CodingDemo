package com.igate.mvc.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.igate.mvc.dto.User;

@Controller
public class CopyOfMyLogin {
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String myLogin(@ModelAttribute("userForm")User user)
	{
		return "login";
		
	}
	
	@RequestMapping(value="/myLogin",method=RequestMethod.POST)
	public String myValidation(@Valid@ModelAttribute("userForm")User user, BindingResult res)
	{
		if(res.hasErrors())
		{
			return "login";
		}
		System.out.println(user.getUserName());
		System.out.println(user.getUserPass());
		return "success";
	}

}
