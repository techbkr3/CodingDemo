package com.igate.mvc.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.igate.mvc.dto.Library;

@Repository("dao")
public class LibraryDAOImpl implements ILibraryDAO {

	@Autowired
	DataSource datas;

	public DataSource getDatas() {
		return datas;
	}

	public void setDatas(DataSource datas) {
		this.datas = datas;
	}

	@Override
	public List<Library> getBooks() {
		String query = "SELECT * FROM LIB";
		JdbcTemplate jd = new JdbcTemplate(datas);
		List<Library> myLib = jd.query(query, new LibraryRowMapper());
		return myLib;
	}

	@Override
	public Library getBookDetails(String id) {
		String query = "Select * from lib where id="+id;
		JdbcTemplate jd = new JdbcTemplate(datas);
		List<Library> empo = jd.query(query, new LibraryRowMapper());
		// TODO Auto-generated method stub
		return empo.get(0);
	}

	@Override
	public int updateBookDetails(Library obj) {
		// TODO Auto-generated method stub
		String query = "update lib set name = ?,duration=?,author=?,typ=? where id="+obj.getBookId();
		Object params[] = {obj.getBookName(),obj.getDuration(),obj.getAuthor(),obj.getType()};
		JdbcTemplate jd = new JdbcTemplate(datas);
		int result = jd.update(query,params);
		return result;
	}

	@Override
	public int deleteBookDetails(int bookId) {
		// TODO Auto-generated method stub
		String query = "delete lib where id="+bookId;
		JdbcTemplate jd = new JdbcTemplate(datas);
		int result = jd.update(query);
		System.out.println(result);
		return result;
	}
	
	

}
