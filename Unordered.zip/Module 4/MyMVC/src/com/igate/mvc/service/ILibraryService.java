package com.igate.mvc.service;

import java.util.List;

import com.igate.mvc.dto.Library;

public interface ILibraryService {
	
	public List<Library> getBooks();

	public Library getBookDetails(String id);

	public int updateBookDetails(Library obj);

	public int deleteBookDetails(int bookId);

}
