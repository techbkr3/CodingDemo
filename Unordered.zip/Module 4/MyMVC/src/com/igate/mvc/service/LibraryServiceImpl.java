package com.igate.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.mvc.dao.ILibraryDAO;
import com.igate.mvc.dto.Library;

@Service("service")
public class LibraryServiceImpl implements ILibraryService{
	
	@Autowired
	ILibraryDAO dao;

	@Override
	public List<Library> getBooks() {
		// TODO Auto-generated method stub
		return dao.getBooks();
	}

	@Override
	public Library getBookDetails(String id) {
		// TODO Auto-generated method stub
		return dao.getBookDetails(id);
	}

	@Override
	public int updateBookDetails(Library obj) {
		// TODO Auto-generated method stub
		return dao.updateBookDetails(obj);
	}

	@Override
	public int deleteBookDetails(int bookId) {
		// TODO Auto-generated method stub
		return dao.deleteBookDetails(bookId);
	}

}
