package com.igate.four;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ap = new ClassPathXmlApplicationContext("prop.xml");
		
		Employee emp = (Employee) ap.getBean("user");
	/*	emp.setUsername("Helo");
		emp.setPassword("Pass");*/
		System.out.println(emp.getUsername());
		System.out.println(emp.getPassword());
		
	}

}
