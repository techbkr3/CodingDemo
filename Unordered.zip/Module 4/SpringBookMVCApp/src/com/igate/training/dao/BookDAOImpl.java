package com.igate.training.dao;

import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import com.igate.training.dto.Book;

@Repository("dao")
public class BookDAOImpl extends JdbcDaoSupport implements IBookDAO{
	
	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	public void initialize()
	{
		setDataSource(dataSource);
	}
	
	@Override
	public int addBook(Book book) {
		String sql = "INSERT INTO BOOKS VALUES(?,?,?)";
		Object params[] = {book.getBookName(),book.getBookPrice(),book.getBokCategory()};
		int result = getJdbcTemplate().update(sql,params);
		return result;
	}

	@Override
	public ArrayList<Book> getAllDetails() {
		// TODO Auto-generated method stub
		String queryo = "Select * from books";
		ArrayList<Book> bookList = (ArrayList<Book>) getJdbcTemplate().query(queryo, new BookRowMapper());
		return bookList;
	}

}