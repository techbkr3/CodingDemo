package com.igate.training.dao;

import java.util.ArrayList;

import com.igate.training.dto.Book;

public interface IBookDAO {

	public int addBook(Book book);

	public ArrayList<Book> getAllDetails();

}
