package com.igate.training.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.igate.training.dao.IBookDAO;
import com.igate.training.dto.Book;
@Service("service")
public class BookServiceImpl implements IBookService{
	
	@Autowired
	IBookDAO dao;

	@Override
	public int addBook(Book book) {
		// TODO Auto-generated method stub
		return dao.addBook(book);
	}
	
	@Override
	public ArrayList<Book>getAllDetails()
	{
		return dao.getAllDetails();
		
	}

}
