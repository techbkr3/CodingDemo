package com.igate.Three.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.igate.Three.Service.Triangle;

public class TEST {
	
	ApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
	Triangle tri = (Triangle) app.getBean("tran");
//	tri.
	
}
