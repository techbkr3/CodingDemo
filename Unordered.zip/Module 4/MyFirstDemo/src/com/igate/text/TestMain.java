package com.igate.text;

import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Dependent or tight coupling+++
		
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Shape");
		String shape = scan.nextLine();
		
		//Loose coupling.. FLOW OF SPRING
		
		Shape sh = TestInfo.drawShape(shape);
		sh.draw();

	}

}
