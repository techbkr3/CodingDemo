package com.igate.text;

public interface Shape {
	
	public void draw();

}
