package com.igate.text;

public class triangle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("In triangle");
	}

}
