package com.igate.text;

//Factory Design Pattern

public class TestInfo {
	
	public static Shape drawShape(String shape)
	{
		if(shape.equals("tran"))
		{
			return new triangle();
		}
		else if(shape.equals("squr"))
		{
			return new Square();
		}
		else
		{
			return new Rectangle();
		}
	}

}
