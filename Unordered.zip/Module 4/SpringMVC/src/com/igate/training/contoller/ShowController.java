package com.igate.training.contoller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ShowController {
	
	@RequestMapping("show")
	public ModelAndView showHello()
	{
		return new ModelAndView("welcome","msg","Hello from Spring");
	}
	
	@RequestMapping(value="test",method=RequestMethod.POST)
	public String validate(@RequestParam("username") String name, @RequestParam("password") String pwd,Model model)
	{
		if(name.equalsIgnoreCase("admin") && "admin123".equalsIgnoreCase(pwd))
		{
			model.addAttribute("msg", "User Valid");
			return "success";
		}
		else
		{
			model.addAttribute("msg", "User Invalid");
			return "failure";
		}
	}
	

}
