package com.igate.dao;

public class TraineeDAOImpl implements ITraineeDAO {

}
