package com.igate.dao;

public interface ITraineeDAO {

}
