package com.igate.bean;

public class Student {
	
	private int rollNo;
	private String studName;
	private int marks;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Student(int rollNo, String studName, int marks) {
		super();
		this.rollNo = rollNo;
		this.studName = studName;
		this.marks = marks;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", studName=" + studName
				+ ", marks=" + marks + "]";
	}
	
	
	public String getGrade()
	{
		if(marks<40)
		{
		return "U R FAIL";
		}
		else if((marks>=40) && (marks<60))
		{
			return "SECOND CLASS";
		}
		else if((marks>=60) && (marks<75))
		{
			return "FIRST CLASS";
		}
		else
		{
			return "DISTINCTION";
		}
	}

}
