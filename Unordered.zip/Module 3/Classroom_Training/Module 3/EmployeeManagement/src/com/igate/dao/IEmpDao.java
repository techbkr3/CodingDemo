package com.igate.dao;

import java.util.ArrayList;

import com.igate.dto.Employee;
import com.igate.exception.EmpException;

public interface IEmpDao {
	
	public int getEmpId() throws EmpException;
	public int insertEmp(Employee emp) throws EmpException;
	public ArrayList<Employee> getAllEmp() throws EmpException;

}
