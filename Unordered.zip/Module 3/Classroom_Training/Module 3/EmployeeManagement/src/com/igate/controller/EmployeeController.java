package com.igate.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.dto.Employee;
import com.igate.exception.EmpException;
import com.igate.service.EmpService;
import com.igate.service.IEmpService;

/**
 * Servlet implementation class EmployeeController
 */
@WebServlet("/EmployeeController")
public class EmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	ServletConfig config;
    public EmployeeController() {
        super();
        System.out.println("Employee Controller Constructor");    
        }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		this.config = config;
		System.out.println("Init function");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("Destory Function");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IEmpService service = new EmpService();
		String action = request.getParameter("action");
		PrintWriter out = response.getWriter();
		out.print(action);
		if(action!=null)
		{
			if(action.equals("DisplayLoginPage"))
			{
				RequestDispatcher rd = request.getRequestDispatcher("/pages/login.jsp");
				rd.forward(request, response);
			}
			if(action.equals("ValidateUser"))
			{
				
				RequestDispatcher rd = request.getRequestDispatcher("/pages/ValidateLogin.jsp");
				rd.forward(request, response);
			}
			//Display add emp page action
			if(action.equals("DisplayAddEmpPage"))
			{	int empID = 0;
				try {
					empID = service.getEmpId();
					System.out.println(empID);
				} catch (EmpException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				request.setAttribute("EmpId", empID);
				RequestDispatcher res = request.getRequestDispatcher("/pages/AddEmp.jsp");
				res.forward(request, response);
			}
			
			//insertion
			if(action.equals("InsertEmp"))
			{
				int eID = Integer.parseInt(request.getParameter("txtID"));
				String ename = request.getParameter("txtNAME");
				int sal = Integer.parseInt(request.getParameter("txtSAL"));
				Employee emp = new Employee(eID,ename,sal);
				
				try
				{
					int inserted = service.insertEmp(emp);
					System.out.println(inserted);
					if(inserted==1)
					{
						RequestDispatcher rs = request.getRequestDispatcher("/pages/EmpOp.jsp");
						rs.forward(request, response);
					}
					else
					{
						RequestDispatcher rs = request.getRequestDispatcher("/pages/ErrorPage.jsp");
						rs.forward(request, response);
					}
				}
				catch(EmpException e)
				{
					e.printStackTrace();
				}
			}
			//list all employee
			if(action.equals("ListAllEmp"))
			{
				try {
					ArrayList<Employee> emplist = service.getAllEmp();
					request.setAttribute("EmpList", emplist);
					RequestDispatcher rd = request.getRequestDispatcher("/pages/ListAllEmp.jsp");
					rd.forward(request, response);
				} catch (EmpException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		else
		{
			out.print("No action defined");
		}
		
	}

}
