package com.igate.service;

import java.util.ArrayList;

import com.igate.dao.EmpDaoImpl;
import com.igate.dao.IEmpDao;
import com.igate.dto.Employee;
import com.igate.exception.EmpException;

public class EmpService implements IEmpService {
	
	IEmpDao dao = new EmpDaoImpl();

	@Override
	public int getEmpId() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpId();
	}

	@Override
	public int insertEmp(Employee emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.insertEmp(emp);
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getAllEmp();
	}

}
