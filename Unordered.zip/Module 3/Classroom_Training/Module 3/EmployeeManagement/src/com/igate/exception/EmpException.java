package com.igate.exception;

public class EmpException extends Exception {
	
	public EmpException(String msg)
	{
		super(msg);
	}
	

}
