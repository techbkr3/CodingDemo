package com.igate.service;

import java.util.ArrayList;

import com.igate.dto.Employee;
import com.igate.exception.EmpException;

public interface IEmpService {

	public int getEmpId() throws EmpException;
	public int insertEmp(Employee emp) throws EmpException;
	public ArrayList<Employee> getAllEmp() throws EmpException;
	
}
