package com.igate.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.igate.dto.Employee;
import com.igate.exception.EmpException;
import com.igate.util.db;

public class EmpDaoImpl implements IEmpDao{

	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	
	@Override
	public int getEmpId() throws EmpException {
		// TODO Auto-generated method stub
		try {
			con= db.getConnection();
			String seqQuery ="select empts.nextval from dual";
			st=con.createStatement();
			rs=st.executeQuery(seqQuery);
			if(rs.next())
			{
			int getEmpId = rs.getInt(1);
			return getEmpId;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new EmpException(e.getMessage());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			
			try {
				rs.close();
				st.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return 0;
	}

	@Override
	public int insertEmp(Employee emp) throws EmpException {
		// TODO Auto-generated method stub
		try {
			con= db.getConnection();
			String insQuery ="INSERT INTO EMPT VALUES(?,?,?)";
			pst=con.prepareStatement(insQuery);
			pst.setInt(1, emp.getEid());
			pst.setString(2, emp.getEname());
			pst.setInt(3, emp.getEsal());
			int inserted = pst.executeUpdate();
			if(inserted!=0)
			{
				return inserted;
			}
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			throw new EmpException(e.getMessage());
		}
		finally
		{
			
			
			
		}
		return 0;
	}

	@Override
	public ArrayList<Employee> getAllEmp() throws EmpException {
		// TODO Auto-generated method stub
		ArrayList<Employee> empList = new ArrayList<Employee>();
		try {
			con= db.getConnection();
			String listEmpQ = "select * from empt"; 
			st=con.createStatement();
			rs=st.executeQuery(listEmpQ);
			while(rs.next())
			{
				Employee emp=new Employee(
				rs.getInt(1),
				rs.getString(2),
				rs.getInt(3));
				empList.add(emp);
			}
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return empList;
	}

}
