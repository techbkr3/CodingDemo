package com.igate.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.pojo.Issue;
import com.igate.service.IService;
import com.igate.service.ServiceImpl;

/**
 * Servlet implementation class OptionController
 */
@WebServlet("/OptionController")
public class OptionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OptionController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session;
		PrintWriter out = response.getWriter();
		IService service = new ServiceImpl();
		String options = request.getParameter("opt");
		if(options.equals("issue"))
		{
			ArrayList<Issue> list = service.getBooksList(); 
			out.print("<html>");
			out.print("<form method='post' action='IssueController'>");				
			out.print("<table border=1>");
			for(Issue issue:list)
			{	System.out.println(issue);
				out.print("<tr>");
				out.print("<td>");
				out.print(issue.getBookId());
				out.print("<td>");
				out.print(issue.getBookName());
				out.print("<td>");
				out.print(issue.getAvailable());
				out.print("<td>");
				out.print(issue.getType());
				out.print("<td>");
				out.print(issue.getPrice());
				out.print("<input type='radio' value='"+issue.getBookName()+"'name='issue'");
				out.print("</tr>");
				out.print("<br>");
			}
			out.print("</table>");
			out.print("<input type='submit'>");
			out.print("</form>");				
			out.print("</html>");
		out.print("Thank you");
		}
		else
			out.print("Return");
		
	}

}
