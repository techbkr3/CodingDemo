package com.igate.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.igate.pojo.Issue;
import com.igate.util.db;

public class DaoImpl implements IDao {

	@Override
	public ArrayList<Issue> getBookList() {
		// TODO Auto-generated method stub
		Issue iss = new Issue();
		ArrayList<Issue> issue = new ArrayList<Issue>();
		Connection con = null;
		Statement st = null;
		ResultSet rs=null;
		String sql = "select * from Library";
		try {
			con = db.getConnection();
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next())
			{
				iss = new Issue();
				iss.setBookId(rs.getInt(1));
				iss.setBookName(rs.getString(2));
				iss.setAvailable(rs.getInt(3));
				iss.setType(rs.getString(4));
				iss.setPrice(rs.getInt(5));
				issue.add(iss);
			}
			
		} catch (SQLException | NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return issue;
	}

}
