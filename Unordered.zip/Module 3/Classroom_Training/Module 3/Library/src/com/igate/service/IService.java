package com.igate.service;

import java.util.ArrayList;

import com.igate.pojo.Issue;

public interface IService {

	public ArrayList<Issue> getBooksList();

}
