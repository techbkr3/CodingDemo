package com.igate.dao;

import java.util.ArrayList;

import com.igate.pojo.Issue;

public interface IDao {

	public ArrayList<Issue> getBookList();
	
	 

}
