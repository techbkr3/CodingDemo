package com.igate.service;

import java.util.ArrayList;

import com.igate.dao.DaoImpl;
import com.igate.dao.IDao;
import com.igate.pojo.Issue;

public class ServiceImpl implements IService {
	
	IDao dao = new DaoImpl();

	@Override
	public ArrayList<Issue> getBooksList() {
		// TODO Auto-generated method stub
		return dao.getBookList();
	}

}
