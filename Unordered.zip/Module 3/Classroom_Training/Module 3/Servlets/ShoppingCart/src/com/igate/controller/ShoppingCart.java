package com.igate.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShoppingCart
 */
@WebServlet("/shop")
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session = request.getSession();
		ArrayList<String> shopCart = new ArrayList<>();
		String items = request.getParameter("item");
		String operation = request.getParameter("operation");		
		switch(operation)
		{
		case "AddItem":
			if(session.isNew())
			{
				shopCart.add(items);
				session.setAttribute("ii", shopCart);
				System.out.println(shopCart);
			}
			else
			{
				shopCart=(ArrayList<String>) session.getAttribute("ii");
				shopCart.add(items);
				System.out.println(shopCart);
				session.setAttribute("ii", shopCart);
			}
			break;
		case "RemoveItem":
			shopCart=(ArrayList<String>) session.getAttribute("ii");
			shopCart.remove(items);
			session.setAttribute("ii", shopCart);
			break;
		case "EmptyCart":
			shopCart=(ArrayList<String>) session.getAttribute("ii");
			shopCart.clear();
			session.setAttribute("ii", shopCart);
			break;
		}
		
		getServletContext().getRequestDispatcher("/show").forward(request, response);
	}

}
