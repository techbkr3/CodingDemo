package com.igate.demofour;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.igate.demofour.dto.Product;

/**
 * Servlet implementation class MyServletOne
 */
@WebServlet("/login")
public class MyServletOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServletOne() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//key is name & mail & pr
		request.setAttribute("name", "ABC");
		request.setAttribute("mail", "ABC@IGATE.COM");
		Product p = new Product();
		p.setpId(1001);
		p.setpName("Halwa");
		p.setpCost(50);
		p.setpQuantity(100);
		request.setAttribute("pr", p);
		RequestDispatcher reqD = request.getRequestDispatcher("/ServletTwo");
		reqD.forward(request, response);
	}

}