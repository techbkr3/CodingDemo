package com.igate.db;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class db {
	
	static Connection con = null;

	public static Connection getConnection() throws NamingException
	{
		InitialContext init  = new InitialContext();
		DataSource data = (DataSource) init.lookup("java:/jdbc/TrackDS");
		
		return con;
		
	}
	
}
