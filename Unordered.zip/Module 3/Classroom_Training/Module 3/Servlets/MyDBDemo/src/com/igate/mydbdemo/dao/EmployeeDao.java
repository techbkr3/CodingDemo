package com.igate.mydbdemo.dao;

import java.util.List;

import com.igate.mydbdemo.dto.Employee;

public interface EmployeeDao {
	
	public List<Employee> getData();

}
