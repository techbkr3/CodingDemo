package com.igate.service;

import java.util.List;

import com.igate.mydbdemo.dao.EmployeeDao;
import com.igate.mydbdemo.dao.EmployeeDaoImpl;
import com.igate.mydbdemo.dto.Employee;

public class EService implements IService {
	
	public List<Employee> getD(){
		
		EmployeeDao dao = new EmployeeDaoImpl();
		List<Employee> e = dao.getData();
		return e;
		
	}

}
