package com.igate.mydbdemo.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.igate.mydbdemo.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	Employee e = new Employee();
	
	
	@Override
	public List<Employee> getData() {
		List<Employee> mylist = new ArrayList<Employee>();;

		// TODO Auto-generated method stub
		Connection con = ConnectionDB.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet res = stmt.executeQuery("select empno,ename,job,sal from emp");
			while(res.next())
			{
				Employee e = new Employee();
				e.setEmpId(res.getInt("empno"));
				e.seteDept(res.getString("job"));
				e.seteName(res.getString("eName"));
				mylist.add(e);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mylist;
		
	}

}
