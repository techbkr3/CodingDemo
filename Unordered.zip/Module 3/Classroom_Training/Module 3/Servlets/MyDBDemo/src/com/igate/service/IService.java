package com.igate.service;

import java.util.List;

import com.igate.mydbdemo.dto.Employee;

public interface IService {
	
	public List<Employee> getD();

}
