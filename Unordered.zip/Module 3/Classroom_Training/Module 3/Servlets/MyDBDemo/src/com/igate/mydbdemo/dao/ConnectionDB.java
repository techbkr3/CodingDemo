package com.igate.mydbdemo.dao;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class ConnectionDB {
	
	static Connection conn = null;
	
	public static Connection getConnection()
	{
		try {
			InitialContext init = new InitialContext();
			DataSource data = (DataSource) init.lookup("java:/jdbc/myDS");
			conn = data.getConnection();
			System.out.println("Done....");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
		
	}

}
