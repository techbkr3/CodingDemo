package com.igate.MyDemoDB.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.mydbdemo.dto.Employee;
import com.igate.service.EService;
import com.igate.service.IService;

/**
 * Servlet implementation class EContoller
 */
@WebServlet("/emp")
public class EContoller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EContoller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		IService e = new EService();
		PrintWriter p = response.getWriter();
		
		List<Employee> em = e.getD();
//		p.println(em);
		for(Employee eno:em)
		{
			p.println(eno.geteName());
			p.println(eno.getEmpId());
		}
	}

}
