package com.igate.ds.dao;

import com.igate.ds.dto.Login;

public class LoginDb implements LoginDbImpl {

	@Override
	public boolean checklogin(Login log) {
		// TODO Auto-generated method stub
		 if(log.getUname().equals("igate") && log.getUpass().equals("igate"))
		 {
			 return true;
		 }
		 else
		return false;
	}

}
