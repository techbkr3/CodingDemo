package com.igate.ds.service;

import com.igate.ds.dao.LoginDb;
import com.igate.ds.dao.LoginDbImpl;
import com.igate.ds.dto.Login;

public class LoginService implements LoginServiceImpl {
	
	LoginDbImpl lo = new LoginDb();

	@Override
	public boolean validateData(Login log) {
		// TODO Auto-generated method stub
		return lo.checklogin(log);
	}

}
