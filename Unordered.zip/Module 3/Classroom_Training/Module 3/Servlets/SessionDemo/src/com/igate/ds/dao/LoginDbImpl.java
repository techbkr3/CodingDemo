package com.igate.ds.dao;

import com.igate.ds.dto.Login;

public interface LoginDbImpl {

	boolean checklogin(Login log);

}
