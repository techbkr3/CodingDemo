package com.igate.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.ds.dto.Login;
import com.igate.ds.service.LoginService;
import com.igate.ds.service.LoginServiceImpl;

/**
 * Servlet implementation class SessionDemo
 */
@WebServlet("/session")
public class SessionDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SessionDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		LoginServiceImpl logg = new LoginService();
		PrintWriter out = response.getWriter();
		String name = request.getParameter("jname");
		String pass = request.getParameter("jpass");
		Login log =new Login();
		
		log.setUname(name); 
		log.setUpass(pass); 
		
		boolean check = logg.validateData(log);
		
		if(check)
		{
			HttpSession session = request.getSession(true);
			session.setAttribute("my", name);
			getServletContext().getRequestDispatcher("mypage").forward(request, response);
		}
		
		
		// TODO Auto-generated method stub
		/*try
		{
		HttpSession mysession = request.getSession();
		
		Integer count = (Integer) mysession.getAttribute("tracker");
		
		 
		 if(count==null)
		 {
			 count = new Integer(1);
		 }
		 else
		 {
			 count=count.intValue()+1;
		 }
		
		System.out.println(mysession.isNew());
		
		 mysession.setAttribute("tracker", count);
		
		PrintWriter p = response.getWriter();
		
		p.println("Count "+count);
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
