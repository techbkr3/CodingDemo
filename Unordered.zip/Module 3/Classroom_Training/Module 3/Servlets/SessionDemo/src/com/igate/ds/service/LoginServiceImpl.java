package com.igate.ds.service;

import com.igate.ds.dto.Login;

public interface LoginServiceImpl {
	
	public boolean validateData(Login log);

}
