package com.igate.demotwo.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyContextConfig
 */
@WebServlet(name="demo",urlPatterns="/demo",
initParams={
		@WebInitParam(name="name",value="ABC"),
		@WebInitParam(name="mail",value="abc@igate.com"),
		@WebInitParam(name="mobileno",value="123456")
})
public class MyContextConfig extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String host = "http://localhost:8080/DemoTwo/second";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyContextConfig() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		response.setHeader("Refresh", "5; url="+host);
//		out.println(new Date().toString());
		
		/*Enumeration<String>header = request.getHeaderNames();
		
		while(header.hasMoreElements())
		{
			String headerName = header.nextElement();
			String value = request.getHeader(headerName);
			out.println("Name is "+headerName+" value is "+value+"<br>");
		}
		
		out.println("Requesting Headers");
		String headerName = request.getPathInfo();
		String headerNames = request.getPathTranslated();
		out.print(headerName);
		out.print(headerNames);
		String name= request.getParameter("jname");
		String password= request.getParameter("jpass");
		out.println("<HTML>");
		out.println("<HEAD><TITLE>Hello "+name+"</TITLE></HEAD>");
		out.println("<BODY>");
		out.println("<BIG>Hello "+name+"</BIG>");
		out.println("Your password is "+password);
		out.println("</BODY></HTML>");*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletContext con = getServletContext();
		PrintWriter out = response.getWriter();
		ServletConfig config = getServletConfig();
		out.println(config.getInitParameter("name"));
		out.println(config.getInitParameter("mail"));
		out.println(config.getInitParameter("mobileno"));
		out.println(con.getInitParameter("nameone"));
		out.println(con.getInitParameter("age"));
		
	}

}
