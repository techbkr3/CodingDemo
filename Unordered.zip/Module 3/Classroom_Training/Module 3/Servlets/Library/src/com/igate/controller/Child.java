package com.igate.controller;

public class Child extends Parent {
	
	public void add()
	{
		System.out.println("Child");
	}
	
	public static void main(String[] args) {
		Parent p = new Parent();
		Child d = new Child();
		p.add();
		d.add();
	}

}
