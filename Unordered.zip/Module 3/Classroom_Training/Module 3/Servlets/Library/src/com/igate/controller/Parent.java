package com.igate.controller;

public class Parent {
	
	public void add()
	{
		System.out.println("Parent");
	}
}
