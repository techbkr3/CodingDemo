package com.igate.MyDemoThreeLogin.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/myLogin")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		String name=request.getParameter("jname");
		String password=request.getParameter("jpass");
		
		if(name.equals("abc") && password.equals("abc@123"))
		{
			RequestDispatcher reqD = request.getRequestDispatcher("/success.html");
			reqD.forward(request, response);
		}
		else
		{
			RequestDispatcher reqD = request.getRequestDispatcher("/Failure.html");
			reqD.forward(request, response);
//			response.sendError(HttpServletResponse.SC_FORBIDDEN,"NOT enter Correct User Name & Password");
		}
	}

}
