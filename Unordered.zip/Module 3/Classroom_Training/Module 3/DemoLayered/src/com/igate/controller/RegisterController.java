package com.igate.controller;

import java.io.IOException;
import java.util.Random;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.dto.Employee;
import com.igate.service.EmpService;
import com.igate.service.IEmpService;

/**
 * Servlet implementation class RegisterController
 */
@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     * 
     */
    public RegisterController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String $action = request.getParameter("action");
		RequestDispatcher req;
		if($action.equals("register"))
		{
			req = request.getRequestDispatcher("register.html");
			req.forward(request, response);
		}
		else
		{
			req = request.getRequestDispatcher("activate.html");
			req.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String operation = request.getParameter("reg");
		Employee emp = new Employee();
		IEmpService abc = new EmpService();
		switch(operation)
		{
		case "register":
			String empName = request.getParameter("empname");
			String empDep = request.getParameter("empdep");
			String empMail = request.getParameter("empmail");
			String empMob = request.getParameter("empmobile");
			emp.setEmpName(empName);
			emp.setEmpDept(empDep);
			emp.setEmpMail(empMail);
			emp.setEmpMob(empMob);
			emp.setIsActive("N");
			Random r = new Random();
			int actCode = r.nextInt(10000)+4;
			HttpSession sess = request.getSession();
			sess.setAttribute("actcode", actCode);
			sess.setAttribute("mail", empMail);
			getServletContext().getRequestDispatcher("/showpage").forward(request, response);
			try {
				abc.insertData(emp);
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "activatepage":
			String empAMail = request.getParameter("empmail");
			String empAct = request.getParameter("actcode");
			HttpSession ses = request.getSession(false);
			String mymail = (String) ses.getAttribute("mail");
			Integer actCodes = (Integer) ses.getAttribute("actcode");
			
			if(Integer.parseInt(empAct)==actCodes && empAMail.equals(mymail))
			{
				System.out.println("Matched");
				emp.setEmpMail(empAMail);
				emp.setIsActive("Y");
				try {
					abc.activateData(emp);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
			{
				System.out.println("Not matched");
			}
			System.out.println(empAct);
			break;
		}
	}

}
