package com.igate.service;

import javax.naming.NamingException;

import com.igate.dto.Employee;

public interface IEmpService {
	
	public void insertData(Employee emp) throws NamingException;
	public void activateData(Employee emp) throws NamingException;

}
