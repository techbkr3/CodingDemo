package com.igate.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.igate.db.db;
import com.igate.dto.Employee;

public class EmpDao implements IEmpDao {
	
	Connection con = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	@Override
	public void DataInsert(Employee emp) throws NamingException {
		// TODO Auto-generated method stub
		con=db.getConnection();
		int a =0;
		String query = "insert into employeeinfo (emp_id,emp_name,dep_name,email,mobile_no,isactive) values(empid_seq.nextval,?,?,?,?,?)";

		try {
						PreparedStatement ps = con.prepareStatement(query);
						System.out.println(emp.getEmpName());
						System.out.println(emp.getEmpDept());
						System.out.println(emp.getEmpMail());
						System.out.println(emp.getEmpMob());
						System.out.println(emp.getIsActive());
			ps.setString(1, emp.getEmpName());
			ps.setString(2, emp.getEmpDept());
			ps.setString(3, emp.getEmpMail());
			ps.setString(4, emp.getEmpMob());
			ps.setString(5, emp.getIsActive());
			a= ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void DataActivate(Employee emp) throws NamingException {
		// TODO Auto-generated method stub
		con=db.getConnection();
		int a =0;
		String queryp = "update employeeinfo set isactive=? where email=?";
		try {
			
			PreparedStatement ps = con.prepareStatement(queryp);
			System.out.println(emp.getIsActive());
			System.out.println(emp.getEmpMail());
			ps.setString(1, emp.getIsActive());
			ps.setString(2, emp.getEmpMail());
			a = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
