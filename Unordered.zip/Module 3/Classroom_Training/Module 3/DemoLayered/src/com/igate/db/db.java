package com.igate.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class db {
	
	static Connection con = null;

	public static Connection getConnection() throws NamingException
	{
		InitialContext init  = new InitialContext();
		DataSource data = (DataSource) init.lookup("java:/jdbc/TrackDS");
		try {
			con=data.getConnection();
			System.out.println("**********Done****************");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
		
	}
	
}
