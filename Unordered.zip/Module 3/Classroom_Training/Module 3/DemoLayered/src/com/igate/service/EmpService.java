package com.igate.service;

import javax.naming.NamingException;

import com.igate.dao.EmpDao;
import com.igate.dao.IEmpDao;
import com.igate.dto.Employee;

public class EmpService implements IEmpService {
	IEmpDao e = new EmpDao();

	@Override
	public void insertData(Employee emp) throws NamingException {
		// TODO Auto-generated method stub
		e.DataInsert(emp);
	}

	@Override
	public void activateData(Employee emp) throws NamingException {
		// TODO Auto-generated method stub
		e.DataActivate(emp);
	}

}
