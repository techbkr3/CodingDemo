package com.igate.dao;

import javax.naming.NamingException;

import com.igate.dto.Employee;

public interface IEmpDao {
	
	public void DataInsert(Employee emp) throws NamingException;
	public void DataActivate(Employee emp) throws NamingException;

}
