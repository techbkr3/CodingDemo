package com.igate.bean;

public class Student {
	
	private String name;
	private String lang;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getpreflang()
	{
		if(lang.equalsIgnoreCase("C"))
			return "Procedure Lang";
		else if(lang.equalsIgnoreCase("Java"))
		{
			return "Pure OOP Lang";
		}
		else
		{
			return "Invalid Lang";
		}
	}
}
